
#include <stdio.h>
#include <stdlib.h>

void sem_take(int sem){printf("taking semaphore %d\n",sem);}
void sem_give(int sem){printf("giving semaphore %d\n",sem);}

int  alloc_page(){printf("allocate new page\n");return 19;} 
void free_page(int page){printf("free page %d\n",page);}
void update_entry(int page,int pos,int data){printf("update entry %d-%d-%d\n",page,pos,data);}
void update_header(int page,char *header){printf("update header %d:%s\n",page,header);}

void send_page(int page){printf("send page %d\n",page);}

main() {
  int page;
  sem_take(1);
  page = alloc_page(); 
  update_header(page,"status report");
  update_entry(page,1,1);
  update_entry(page,2,0);
  sem_give(1);
  send_page(page);
  free_page(page);
  sem_give(1);
}
