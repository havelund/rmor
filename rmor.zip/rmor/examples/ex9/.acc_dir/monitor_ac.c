
struct JoinPoint { 
	void** (*fp) (struct JoinPoint *);
	void ** args;
	void ** retValue;
	const char * funcName ;
	const char * targetName ;
	const char * fileName ;
	const char * kind ;
	void * excep_return ;
};

 struct __UTAC__EXCEPTION {
	void * jumpbuf ;
	unsigned long long int prtValue ;
	int pops;
	struct __UTAC__CFLOW_FUNC {
		int (*func)(int,int) ;
		int val ;
		struct __UTAC__CFLOW_FUNC * next; 
	} * cflowfuncs; 
}; 

extern void __utac__exception__cf_handler_set(void * exception, int (*cflow_func)(int, int), int val) ; 
extern void __utac__exception__cf_handler_free(void * exception);
extern void __utac__exception__cf_handler_reset(void * exception) ; 
extern void * __utac__error_stack_mgt(void * env , int mode, int count) ;

#line 31 "/usr/include/i386/_types.h"
typedef signed char __int8_t; 
#line 35 "/usr/include/i386/_types.h"
typedef unsigned char __uint8_t; 
#line 36 "/usr/include/i386/_types.h"
typedef short __int16_t; 
#line 37 "/usr/include/i386/_types.h"
typedef unsigned short __uint16_t; 
#line 38 "/usr/include/i386/_types.h"
typedef int __int32_t; 
#line 39 "/usr/include/i386/_types.h"
typedef unsigned int __uint32_t; 
#line 40 "/usr/include/i386/_types.h"
typedef long long __int64_t; 
#line 41 "/usr/include/i386/_types.h"
typedef unsigned long long __uint64_t; 
#line 43 "/usr/include/i386/_types.h"
typedef long __darwin_intptr_t; 
#line 44 "/usr/include/i386/_types.h"
typedef unsigned int __darwin_natural_t; 
#line 64 "/usr/include/i386/_types.h"
typedef int __darwin_ct_rune_t; 
#line 73 "/usr/include/i386/_types.h"
typedef union {char __mbstate8[128]; long long _mbstateL; 
}__mbstate_t; 
#line 75 "/usr/include/i386/_types.h"
typedef  __mbstate_t __darwin_mbstate_t; 
#line 78 "/usr/include/i386/_types.h"
typedef int __darwin_ptrdiff_t; 
#line 84 "/usr/include/i386/_types.h"
typedef long unsigned int __darwin_size_t; 
#line 90 "/usr/include/i386/_types.h"
typedef __builtin_va_list __darwin_va_list; 
#line 96 "/usr/include/i386/_types.h"
typedef int __darwin_wchar_t; 
#line 101 "/usr/include/i386/_types.h"
typedef  __darwin_wchar_t __darwin_rune_t; 
#line 104 "/usr/include/i386/_types.h"
typedef int __darwin_wint_t; 
#line 109 "/usr/include/i386/_types.h"
typedef unsigned long __darwin_clock_t; 
#line 110 "/usr/include/i386/_types.h"
typedef  __uint32_t __darwin_socklen_t; 
#line 111 "/usr/include/i386/_types.h"
typedef long __darwin_ssize_t; 
#line 112 "/usr/include/i386/_types.h"
typedef long __darwin_time_t; 
#line 31 "/usr/include/sys/_types.h"
struct mcontext ; 
#line 32 "/usr/include/sys/_types.h"
struct mcontext64 ; 
#line 65 "/usr/include/sys/_types.h"
struct __darwin_pthread_handler_rec {void (*__routine)(void *); void *__arg; struct __darwin_pthread_handler_rec *__next; 
}; 
#line 66 "/usr/include/sys/_types.h"
struct _opaque_pthread_attr_t {long __sig; char __opaque[36]; 
}; 
#line 67 "/usr/include/sys/_types.h"
struct _opaque_pthread_cond_t {long __sig; char __opaque[24]; 
}; 
#line 68 "/usr/include/sys/_types.h"
struct _opaque_pthread_condattr_t {long __sig; char __opaque[4]; 
}; 
#line 69 "/usr/include/sys/_types.h"
struct _opaque_pthread_mutex_t {long __sig; char __opaque[40]; 
}; 
#line 70 "/usr/include/sys/_types.h"
struct _opaque_pthread_mutexattr_t {long __sig; char __opaque[8]; 
}; 
#line 71 "/usr/include/sys/_types.h"
struct _opaque_pthread_once_t {long __sig; char __opaque[4]; 
}; 
#line 72 "/usr/include/sys/_types.h"
struct _opaque_pthread_rwlock_t {long __sig; char __opaque[124]; 
}; 
#line 73 "/usr/include/sys/_types.h"
struct _opaque_pthread_rwlockattr_t {long __sig; char __opaque[12]; 
}; 
#line 74 "/usr/include/sys/_types.h"
struct _opaque_pthread_t {long __sig; struct __darwin_pthread_handler_rec *__cleanup_stack; char __opaque[596]; 
}; 
#line 96 "/usr/include/sys/_types.h"
typedef  __int64_t __darwin_blkcnt_t; 
#line 97 "/usr/include/sys/_types.h"
typedef  __int32_t __darwin_blksize_t; 
#line 98 "/usr/include/sys/_types.h"
typedef  __int32_t __darwin_dev_t; 
#line 99 "/usr/include/sys/_types.h"
typedef unsigned int __darwin_fsblkcnt_t; 
#line 100 "/usr/include/sys/_types.h"
typedef unsigned int __darwin_fsfilcnt_t; 
#line 101 "/usr/include/sys/_types.h"
typedef  __uint32_t __darwin_gid_t; 
#line 102 "/usr/include/sys/_types.h"
typedef  __uint32_t __darwin_id_t; 
#line 103 "/usr/include/sys/_types.h"
typedef  __uint32_t __darwin_ino_t; 
#line 104 "/usr/include/sys/_types.h"
typedef  __darwin_natural_t __darwin_mach_port_name_t; 
#line 105 "/usr/include/sys/_types.h"
typedef  __darwin_mach_port_name_t __darwin_mach_port_t; 
#line 107 "/usr/include/sys/_types.h"
typedef struct mcontext *__darwin_mcontext_t; 
#line 108 "/usr/include/sys/_types.h"
typedef struct mcontext64 *__darwin_mcontext64_t; 
#line 112 "/usr/include/sys/_types.h"
typedef  __uint16_t __darwin_mode_t; 
#line 113 "/usr/include/sys/_types.h"
typedef  __int64_t __darwin_off_t; 
#line 114 "/usr/include/sys/_types.h"
typedef  __int32_t __darwin_pid_t; 
#line 116 "/usr/include/sys/_types.h"
typedef struct _opaque_pthread_attr_t __darwin_pthread_attr_t; 
#line 118 "/usr/include/sys/_types.h"
typedef struct _opaque_pthread_cond_t __darwin_pthread_cond_t; 
#line 120 "/usr/include/sys/_types.h"
typedef struct _opaque_pthread_condattr_t __darwin_pthread_condattr_t; 
#line 121 "/usr/include/sys/_types.h"
typedef unsigned long __darwin_pthread_key_t; 
#line 123 "/usr/include/sys/_types.h"
typedef struct _opaque_pthread_mutex_t __darwin_pthread_mutex_t; 
#line 125 "/usr/include/sys/_types.h"
typedef struct _opaque_pthread_mutexattr_t __darwin_pthread_mutexattr_t; 
#line 127 "/usr/include/sys/_types.h"
typedef struct _opaque_pthread_once_t __darwin_pthread_once_t; 
#line 129 "/usr/include/sys/_types.h"
typedef struct _opaque_pthread_rwlock_t __darwin_pthread_rwlock_t; 
#line 131 "/usr/include/sys/_types.h"
typedef struct _opaque_pthread_rwlockattr_t __darwin_pthread_rwlockattr_t; 
#line 133 "/usr/include/sys/_types.h"
typedef struct _opaque_pthread_t *__darwin_pthread_t; 
#line 134 "/usr/include/sys/_types.h"
typedef  __uint32_t __darwin_sigset_t; 
#line 135 "/usr/include/sys/_types.h"
typedef  __int32_t __darwin_suseconds_t; 
#line 136 "/usr/include/sys/_types.h"
typedef  __uint32_t __darwin_uid_t; 
#line 137 "/usr/include/sys/_types.h"
typedef  __uint32_t __darwin_useconds_t; 
#line 138 "/usr/include/sys/_types.h"
typedef unsigned char __darwin_uuid_t[16]; 
#line 150 "/usr/include/sys/_types.h"
struct sigaltstack {void *ss_sp;  __darwin_size_t ss_size; int ss_flags; 
}; 
#line 152 "/usr/include/sys/_types.h"
typedef struct sigaltstack __darwin_stack_t; 
#line 174 "/usr/include/sys/_types.h"
struct ucontext {int uc_onstack;  __darwin_sigset_t uc_sigmask;  __darwin_stack_t uc_stack; struct ucontext *uc_link;  __darwin_size_t uc_mcsize;  __darwin_mcontext_t uc_mcontext; 
}; 
#line 176 "/usr/include/sys/_types.h"
typedef struct ucontext __darwin_ucontext_t; 
#line 189 "/usr/include/sys/_types.h"
struct ucontext64 {int uc_onstack;  __darwin_sigset_t uc_sigmask;  __darwin_stack_t uc_stack; struct ucontext64 *uc_link;  __darwin_size_t uc_mcsize;  __darwin_mcontext64_t uc_mcontext64; 
}; 
#line 190 "/usr/include/sys/_types.h"
typedef struct ucontext64 __darwin_ucontext64_t; 
#line 29 "/usr/include/_types.h"
typedef int __darwin_nl_item; 
#line 30 "/usr/include/_types.h"
typedef int __darwin_wctrans_t; 
#line 34 "/usr/include/_types.h"
typedef unsigned long __darwin_wctype_t; 
#line 71 "/usr/include/stdio.h"
typedef  __darwin_va_list va_list; 
#line 76 "/usr/include/stdio.h"
typedef  __darwin_size_t size_t; 
#line 84 "/usr/include/stdio.h"
typedef  __darwin_off_t fpos_t; 
#line 101 "/usr/include/stdio.h"
struct __sbuf {unsigned char *_base; int _size; 
}; 
#line 104 "/usr/include/stdio.h"
struct __sFILEX ; 
#line 163 "/usr/include/stdio.h"
typedef struct __sFILE {unsigned char *_p; int _r; int _w; short _flags; short _file; struct __sbuf _bf; int _lbfsize; void *_cookie; int (*_close)(void *); int (*_read)(void *, char *, int );  fpos_t (*_seek)(void *,  fpos_t , int ); int (*_write)(void *, const char *, int ); struct __sbuf _ub; struct __sFILEX *_extra; int _ur; unsigned char _ubuf[3]; unsigned char _nbuf[1]; struct __sbuf _lb; int _blksize;  fpos_t _offset; 
}FILE; 
#line 171 "/usr/include/stdio.h"
extern  FILE __sF[]; 
#line 249 "/usr/include/stdio.h"
void clearerr( FILE *); 
#line 250 "/usr/include/stdio.h"
int fclose( FILE *); 
#line 251 "/usr/include/stdio.h"
int feof( FILE *); 
#line 252 "/usr/include/stdio.h"
int ferror( FILE *); 
#line 253 "/usr/include/stdio.h"
int fflush( FILE *); 
#line 254 "/usr/include/stdio.h"
int fgetc( FILE *); 
#line 255 "/usr/include/stdio.h"
int fgetpos( FILE *,  fpos_t *); 
#line 256 "/usr/include/stdio.h"
char *fgets(char *, int ,  FILE *); 
#line 257 "/usr/include/stdio.h"
 FILE *fopen(const char *, const char *); 
#line 258 "/usr/include/stdio.h"
int fprintf( FILE *, const char *, ...); 
#line 259 "/usr/include/stdio.h"
int fputc(int ,  FILE *); 
#line 260 "/usr/include/stdio.h"
int fputs(const char *,  FILE *); 
#line 261 "/usr/include/stdio.h"
 size_t fread(void *,  size_t ,  size_t ,  FILE *); 
#line 263 "/usr/include/stdio.h"
 FILE *freopen(const char *, const char *,  FILE *); 
#line 264 "/usr/include/stdio.h"
int fscanf( FILE *, const char *, ...); 
#line 265 "/usr/include/stdio.h"
int fseek( FILE *, long , int ); 
#line 266 "/usr/include/stdio.h"
int fsetpos( FILE *, const  fpos_t *); 
#line 267 "/usr/include/stdio.h"
long ftell( FILE *); 
#line 268 "/usr/include/stdio.h"
 size_t fwrite(const void *,  size_t ,  size_t ,  FILE *); 
#line 269 "/usr/include/stdio.h"
int getc( FILE *); 
#line 270 "/usr/include/stdio.h"
int getchar(void ); 
#line 271 "/usr/include/stdio.h"
char *gets(char *); 
#line 273 "/usr/include/stdio.h"
extern const int sys_nerr; 
#line 274 "/usr/include/stdio.h"
extern const char *const sys_errlist[]; 
#line 276 "/usr/include/stdio.h"
void perror(const char *); 
#line 277 "/usr/include/stdio.h"
int printf(const char *, ...); 
#line 278 "/usr/include/stdio.h"
int putc(int ,  FILE *); 
#line 279 "/usr/include/stdio.h"
int putchar(int ); 
#line 280 "/usr/include/stdio.h"
int puts(const char *); 
#line 281 "/usr/include/stdio.h"
int remove(const char *); 
#line 282 "/usr/include/stdio.h"
int rename(const char *, const char *); 
#line 283 "/usr/include/stdio.h"
void rewind( FILE *); 
#line 284 "/usr/include/stdio.h"
int scanf(const char *, ...); 
#line 285 "/usr/include/stdio.h"
void setbuf( FILE *, char *); 
#line 286 "/usr/include/stdio.h"
int setvbuf( FILE *, char *, int ,  size_t ); 
#line 287 "/usr/include/stdio.h"
int sprintf(char *, const char *, ...); 
#line 288 "/usr/include/stdio.h"
int sscanf(const char *, const char *, ...); 
#line 289 "/usr/include/stdio.h"
 FILE *tmpfile(void ); 
#line 290 "/usr/include/stdio.h"
char *tmpnam(char *); 
#line 291 "/usr/include/stdio.h"
int ungetc(int ,  FILE *); 
#line 292 "/usr/include/stdio.h"
int vfprintf( FILE *, const char *,  va_list ); 
#line 293 "/usr/include/stdio.h"
int vprintf(const char *,  va_list ); 
#line 294 "/usr/include/stdio.h"
int vsprintf(char *, const char *,  va_list ); 
#line 296 "/usr/include/stdio.h"
int asprintf(char **, const char *, ...); 
#line 297 "/usr/include/stdio.h"
int vasprintf(char **, const char *,  va_list ); 
#line 309 "/usr/include/stdio.h"
char *ctermid(char *); 
#line 311 "/usr/include/stdio.h"
char *ctermid_r(char *); 
#line 313 "/usr/include/stdio.h"
 FILE *fdopen(int , const char *); 
#line 315 "/usr/include/stdio.h"
char *fgetln( FILE *,  size_t *); 
#line 317 "/usr/include/stdio.h"
int fileno( FILE *); 
#line 318 "/usr/include/stdio.h"
void flockfile( FILE *); 
#line 321 "/usr/include/stdio.h"
const char *fmtcheck(const char *, const char *); 
#line 322 "/usr/include/stdio.h"
int fpurge( FILE *); 
#line 324 "/usr/include/stdio.h"
int fseeko( FILE *,  fpos_t , int ); 
#line 325 "/usr/include/stdio.h"
 fpos_t ftello( FILE *); 
#line 326 "/usr/include/stdio.h"
int ftrylockfile( FILE *); 
#line 327 "/usr/include/stdio.h"
void funlockfile( FILE *); 
#line 328 "/usr/include/stdio.h"
int getc_unlocked( FILE *); 
#line 329 "/usr/include/stdio.h"
int getchar_unlocked(void ); 
#line 331 "/usr/include/stdio.h"
int getw( FILE *); 
#line 333 "/usr/include/stdio.h"
int pclose( FILE *); 
#line 334 "/usr/include/stdio.h"
 FILE *popen(const char *, const char *); 
#line 335 "/usr/include/stdio.h"
int putc_unlocked(int ,  FILE *); 
#line 336 "/usr/include/stdio.h"
int putchar_unlocked(int ); 
#line 338 "/usr/include/stdio.h"
int putw(int ,  FILE *); 
#line 339 "/usr/include/stdio.h"
void setbuffer( FILE *, char *, int ); 
#line 340 "/usr/include/stdio.h"
int setlinebuf( FILE *); 
#line 342 "/usr/include/stdio.h"
int snprintf(char *,  size_t , const char *, ...); 
#line 343 "/usr/include/stdio.h"
char *tempnam(const char *, const char *); 
#line 344 "/usr/include/stdio.h"
int vfscanf( FILE *, const char *,  va_list ); 
#line 345 "/usr/include/stdio.h"
int vscanf(const char *,  va_list ); 
#line 346 "/usr/include/stdio.h"
int vsnprintf(char *,  size_t , const char *,  va_list ); 
#line 347 "/usr/include/stdio.h"
int vsscanf(const char *, const char *,  va_list ); 
#line 349 "/usr/include/stdio.h"
 FILE *zopen(const char *, const char *, int ); 
#line 362 "/usr/include/stdio.h"
 FILE *funopen(const void *, int (*)(void *, char *, int ), int (*)(void *, const char *, int ),  fpos_t (*)(void *,  fpos_t , int ), int (*)(void *)); 
#line 373 "/usr/include/stdio.h"
int __srget( FILE *); 
#line 374 "/usr/include/stdio.h"
int __svfscanf( FILE *, const char *,  va_list ); 
#line 375 "/usr/include/stdio.h"
int __swbuf(int ,  FILE *); 
#line 384 "/usr/include/stdio.h"
static __inline int __sputc(int _c,  FILE *_p)  {

#line 388 "/usr/include/stdio.h"
if ((--(_p->_w)) >= 0 || ((_p->_w) >= (_p->_lbfsize) && ((char )_c) != '\n')){
return ((*(_p->_p)++) = _c); }else{
return (__swbuf(_c, _p)); }}
 
#line 7 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
void verify(int cond, char *msg)  {

#line 10 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
if ((!cond)){
printf("*** %s! ***\n", msg); }}
 
#line 16 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
int taken = 0; 
#line 18 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
void verify_semtake()  {

#line 19 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
verify((!taken), "attempt to take already taken semaphore"); 
#line 20 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
taken = 1; }
 
#line 23 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
void verify_semgive()  {

#line 24 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
verify(taken, "attempt to release already released semaphore"); 
#line 25 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
taken = 0; }
 
#line 28 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
void verify_update()  {

#line 29 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
verify(taken, "update not protected by semaphore"); }
 
#line 38 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
 
#line 41 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
 
#line 43 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
 
#line 50 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
 inline void __utac_acc__monitor_ac__4(void) { 



#line 51 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
verify_semtake(); }

 
#line 54 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
 inline void __utac_acc__monitor_ac__5(void) { 



#line 55 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
verify_semgive(); }

 
#line 58 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
 inline void __utac_acc__monitor_ac__6(void) { 



#line 59 "/Users/khavelun/Desktop/development/rmor/examples/ex9/monitor.acc"
verify_update(); }

 



