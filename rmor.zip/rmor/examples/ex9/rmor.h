
#define semgive_event 1
#define semtake_event 2
#define update_event 3

void M_init();
void M_print_monitors();
void M_submit(int event);
void M_stop_monitor(char *monitor);
void M_reset_monitor(char *monitor);
void M_stop_all_monitors();
void M_reset_all_monitors();
void M_end();
