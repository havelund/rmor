
#include <stdio.h>
#include <stdlib.h>

#define bool int
#define true  1
#define false 0

void verify(bool cond,char *msg) {
  if (!cond)
    printf("*** %s! ***\n",msg);
}

bool taken = false;

void verify_semtake() {
  verify(!taken,"attempt to take already taken semaphore");
  taken = 1;
}

void verify_semgive() {
  verify(taken,"attempt to release already released semaphore");
  taken = 0;
}

void verify_update() {
  verify(taken,"update not protected by semaphore");
}

void sem_take(int sem){printf("taking semaphore %d\n",sem);}
void sem_give(int sem){printf("giving semaphore %d\n",sem);}

int  alloc_page(){printf("allocate new page\n");return 19;} 
void free_page(int page){printf("free page %d\n",page);}
void update_entry(int page,int pos,int data){printf("update entry %d-%d-%d\n",page,pos,data);}
void update_header(int page,char *header){printf("update header %d:%s\n",page,header);}

void send_page(int page){printf("send page %d\n",page);}

main() {
  int page;
  sem_take(1);
    verify_semtake();
  page = alloc_page(); 
    verify_update();
  update_header(page,"status report");
    verify_update();
  update_entry(page,1,1);
    verify_update();
  update_entry(page,2,0);
    verify_update();
  sem_give(1);
    verify_semgive();
  send_page(page);
  free_page(page);
    verify_update();
  sem_give(1);
    verify_semgive();
}

