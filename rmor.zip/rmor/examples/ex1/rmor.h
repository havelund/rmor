
#define exe_event 1
#define execute_event 2
#define finalResult_event 3
#define new_event 4
#define newCmd_event 5
#define newCommand_event 6
#define rejectCommand_event 7
#define success_event 8
#define val_event 9
#define varUpdate_event 10

void M_init();
void M_print_monitors();
void M_submit(int event);
void M_stop_monitor(char *monitor);
void M_reset_monitor(char *monitor);
void M_stop_all_monitors();
void M_reset_all_monitors();
void M_end();
