
/***********************/
/* RMOR Generated Code */
/***********************/


/************/
/* Preamble */
/************/

#include <stdlib.h>
#include <stdio.h>
#include "sglib.h"
#include "rmor.h"

#define string char*
#define bool int
#define true 1
#define false 0

#define SAME_STATE(x,y) ((int)(x->state)-(y->state))

#define DEBUG_FLAG 0
#define DEBUG if(DEBUG_FLAG)printf

extern void handler(string monitor, string state, int kind);

static void error(string monitor, string state, int kind, bool handled){
  string msg;
  switch(kind){
    case 0 : msg = "error state entered";break;
    case 1 : msg = "next state not exited";break;
    case 2 : msg = "live state active at end";break;
    case 3 : msg = "states exhausted";
  };
  printf("*** %s.%s : %s\n",monitor,state,msg);
  if(handled){handler(monitor,state,kind);}
}

bool global_stop_or_reset = false;

/**********/
/* Events */
/**********/

struct{
  int kind;
} curr_event;

#define IS(E) (curr_event.kind == E)

static string event_name(){
  switch(curr_event.kind){
    case exe_event : return "exe";
    case execute_event : return "execute";
    case finalResult_event : return "finalResult";
    case new_event : return "new";
    case newCmd_event : return "newCmd";
    case newCommand_event : return "newCommand";
    case rejectCommand_event : return "rejectCommand";
    case success_event : return "success";
    case val_event : return "val";
    case varUpdate_event : return "varUpdate";
    default : return "UNKNOWN";
  }
}

/*************************************/
/* Automaton for : OneCommandAtATime */
/*************************************/

struct OneCommandAtATime_state{
  struct OneCommandAtATime_state *next;
  struct OneCommandAtATime_state *previous;
  int state;
};

typedef struct OneCommandAtATime_state *OneCommandAtATime_instance;

static OneCommandAtATime_instance newOneCommandAtATime(){
  return (OneCommandAtATime_instance)malloc(sizeof(struct OneCommandAtATime_state));
}

static void init_OneCommandAtATime_state(OneCommandAtATime_instance machine,int state){
  machine->state = state;
}

OneCommandAtATime_instance OneCommandAtATime_freeList = NULL;
OneCommandAtATime_instance OneCommandAtATime_currList = NULL;
OneCommandAtATime_instance OneCommandAtATime_nextList = NULL;
int OneCommandAtATime_stop_reset_status = 0;

#define ADD_OneCommandAtATime(list, machine)\
  SGLIB_DL_LIST_ADD(struct OneCommandAtATime_state, list, machine, previous, next);

#define ADD_NEXT_OneCommandAtATime(machine)\
  {\
    OneCommandAtATime_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct OneCommandAtATime_state, OneCommandAtATime_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_OneCommandAtATime(OneCommandAtATime_freeList,machine);\
    }\
  }

#define DELETE_OneCommandAtATime(list, machine)\
  SGLIB_DL_LIST_DELETE(struct OneCommandAtATime_state, list, machine, previous, next);

#define FREE_OneCommandAtATime(machine)\
  DELETE_OneCommandAtATime(OneCommandAtATime_currList,machine);\
  ADD_OneCommandAtATime(OneCommandAtATime_freeList,machine)

#define ALLOCATE_OneCommandAtATime(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct OneCommandAtATime_state, OneCommandAtATime_freeList, previous, next, machine);\
  DELETE_OneCommandAtATime(OneCommandAtATime_freeList, machine);

#define CURR_TO_NEXT_OneCommandAtATime(machine)\
  DELETE_OneCommandAtATime(OneCommandAtATime_currList, machine);\
  ADD_NEXT_OneCommandAtATime(machine);

#define FREE_TO_NEXT_OneCommandAtATime(state)\
  OneCommandAtATime_instance machine;\
  if(OneCommandAtATime_freeList != NULL){\
    ALLOCATE_OneCommandAtATime(machine);\
    init_OneCommandAtATime_state(machine,state);\
    ADD_NEXT_OneCommandAtATime(machine);\
  }else{\
    error("OneCommandAtATime",OneCommandAtATime_state_name(state),3,true);\
  }

#define MAP_ACTIVE_OneCommandAtATime(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct OneCommandAtATime_state, OneCommandAtATime_currList, machine, previous, next, cmd);

static int OneCommandAtATime_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct OneCommandAtATime_state, OneCommandAtATime_freeList, previous, next, result)
  return result;
}

#define OneCommandAtATime_Start_state 1
#define OneCommandAtATime_Processing_state 2

static string OneCommandAtATime_state_name(int state){
  switch(state){
    case OneCommandAtATime_Start_state: return "Start";
    case OneCommandAtATime_Processing_state: return "Processing";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_OneCommandAtATime_states(){
  OneCommandAtATime_instance machine;
  printf("\n-- OneCommandAtATime --\n");
  MAP_ACTIVE_OneCommandAtATime(machine,{
    printf("state = %s\n", OneCommandAtATime_state_name(machine->state));
  });
  printf("free : %d\n",OneCommandAtATime_freeList_length());
}

static void init_OneCommandAtATime(int noOfMachines){
  int i;
  OneCommandAtATime_instance r = newOneCommandAtATime();
  init_OneCommandAtATime_state(r,OneCommandAtATime_Start_state);
  if(noOfMachines>0)
    ADD_OneCommandAtATime(OneCommandAtATime_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newOneCommandAtATime();
    ADD_OneCommandAtATime(OneCommandAtATime_freeList, r);
  }
}

static void stop_reset_OneCommandAtATime(){
  OneCommandAtATime_instance machine;
  if(OneCommandAtATime_stop_reset_status > 0){
    MAP_ACTIVE_OneCommandAtATime(machine,{FREE_OneCommandAtATime(machine);});
    if(OneCommandAtATime_stop_reset_status == 1){
      ALLOCATE_OneCommandAtATime(machine);
      init_OneCommandAtATime_state(machine,OneCommandAtATime_Start_state);
      ADD_OneCommandAtATime(OneCommandAtATime_currList,machine);
    }
    OneCommandAtATime_stop_reset_status = 0;
  };
}

static void next_step_OneCommandAtATime(OneCommandAtATime_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case OneCommandAtATime_Start_state :
      if(IS(newCommand_event)){FREE_TO_NEXT_OneCommandAtATime(OneCommandAtATime_Processing_state);T = true;}
      break;
    case OneCommandAtATime_Processing_state :
      if(IS(newCommand_event)){error("OneCommandAtATime","Processing",0,true);T = true;K = true;}
      if((IS(rejectCommand_event)||IS(execute_event))){FREE_TO_NEXT_OneCommandAtATime(OneCommandAtATime_Start_state);T = true;}
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_OneCommandAtATime(machine);
  }
  else{
    FREE_OneCommandAtATime(machine);
  }
}

static void next_OneCommandAtATime(){
  if(
    IS(execute_event)||IS(newCommand_event)||IS(rejectCommand_event)
  ){
    OneCommandAtATime_nextList = NULL;
    OneCommandAtATime_instance machine;
    MAP_ACTIVE_OneCommandAtATime(machine,{next_step_OneCommandAtATime(machine);});
    OneCommandAtATime_currList = OneCommandAtATime_nextList;
  }
}

static void end_OneCommandAtATime(){
}

/********************************/
/* Automaton for : SystemIsLive */
/********************************/

struct SystemIsLive_state{
  struct SystemIsLive_state *next;
  struct SystemIsLive_state *previous;
  int state;
};

typedef struct SystemIsLive_state *SystemIsLive_instance;

static SystemIsLive_instance newSystemIsLive(){
  return (SystemIsLive_instance)malloc(sizeof(struct SystemIsLive_state));
}

static void init_SystemIsLive_state(SystemIsLive_instance machine,int state){
  machine->state = state;
}

SystemIsLive_instance SystemIsLive_freeList = NULL;
SystemIsLive_instance SystemIsLive_currList = NULL;
SystemIsLive_instance SystemIsLive_nextList = NULL;
int SystemIsLive_stop_reset_status = 0;

#define ADD_SystemIsLive(list, machine)\
  SGLIB_DL_LIST_ADD(struct SystemIsLive_state, list, machine, previous, next);

#define ADD_NEXT_SystemIsLive(machine)\
  {\
    SystemIsLive_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct SystemIsLive_state, SystemIsLive_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_SystemIsLive(SystemIsLive_freeList,machine);\
    }\
  }

#define DELETE_SystemIsLive(list, machine)\
  SGLIB_DL_LIST_DELETE(struct SystemIsLive_state, list, machine, previous, next);

#define FREE_SystemIsLive(machine)\
  DELETE_SystemIsLive(SystemIsLive_currList,machine);\
  ADD_SystemIsLive(SystemIsLive_freeList,machine)

#define ALLOCATE_SystemIsLive(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct SystemIsLive_state, SystemIsLive_freeList, previous, next, machine);\
  DELETE_SystemIsLive(SystemIsLive_freeList, machine);

#define CURR_TO_NEXT_SystemIsLive(machine)\
  DELETE_SystemIsLive(SystemIsLive_currList, machine);\
  ADD_NEXT_SystemIsLive(machine);

#define FREE_TO_NEXT_SystemIsLive(state)\
  SystemIsLive_instance machine;\
  if(SystemIsLive_freeList != NULL){\
    ALLOCATE_SystemIsLive(machine);\
    init_SystemIsLive_state(machine,state);\
    ADD_NEXT_SystemIsLive(machine);\
  }else{\
    error("SystemIsLive",SystemIsLive_state_name(state),3,false);\
  }

#define MAP_ACTIVE_SystemIsLive(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct SystemIsLive_state, SystemIsLive_currList, machine, previous, next, cmd);

static int SystemIsLive_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct SystemIsLive_state, SystemIsLive_freeList, previous, next, result)
  return result;
}

#define SystemIsLive_Start_state 1
#define SystemIsLive_Waiting_state 2
#define SystemIsLive_Done_state 3

static string SystemIsLive_state_name(int state){
  switch(state){
    case SystemIsLive_Start_state: return "Start";
    case SystemIsLive_Waiting_state: return "Waiting";
    case SystemIsLive_Done_state: return "Done";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_SystemIsLive_states(){
  SystemIsLive_instance machine;
  printf("\n-- SystemIsLive --\n");
  MAP_ACTIVE_SystemIsLive(machine,{
    printf("state = %s\n", SystemIsLive_state_name(machine->state));
  });
  printf("free : %d\n",SystemIsLive_freeList_length());
}

static void init_SystemIsLive(int noOfMachines){
  int i;
  SystemIsLive_instance r = newSystemIsLive();
  init_SystemIsLive_state(r,SystemIsLive_Start_state);
  if(noOfMachines>0)
    ADD_SystemIsLive(SystemIsLive_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newSystemIsLive();
    ADD_SystemIsLive(SystemIsLive_freeList, r);
  }
}

static void stop_reset_SystemIsLive(){
  SystemIsLive_instance machine;
  if(SystemIsLive_stop_reset_status > 0){
    MAP_ACTIVE_SystemIsLive(machine,{FREE_SystemIsLive(machine);});
    if(SystemIsLive_stop_reset_status == 1){
      ALLOCATE_SystemIsLive(machine);
      init_SystemIsLive_state(machine,SystemIsLive_Start_state);
      ADD_SystemIsLive(SystemIsLive_currList,machine);
    }
    SystemIsLive_stop_reset_status = 0;
  };
}

static void next_step_SystemIsLive(SystemIsLive_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case SystemIsLive_Start_state :
      if(IS(newCommand_event)){FREE_TO_NEXT_SystemIsLive(SystemIsLive_Waiting_state);T = true;K = true;}
      break;
    case SystemIsLive_Waiting_state :
      if((IS(rejectCommand_event)||IS(execute_event))){T = true;}
      break;
    case SystemIsLive_Done_state :
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_SystemIsLive(machine);
  }
  else{
    FREE_SystemIsLive(machine);
  }
}

static void next_SystemIsLive(){
  if(
    IS(execute_event)||IS(newCommand_event)||IS(rejectCommand_event)
  ){
    SystemIsLive_nextList = NULL;
    SystemIsLive_instance machine;
    MAP_ACTIVE_SystemIsLive(machine,{next_step_SystemIsLive(machine);});
    SystemIsLive_currList = SystemIsLive_nextList;
  }
}

static void end_SystemIsLive(){
  SystemIsLive_instance machine;
  MAP_ACTIVE_SystemIsLive(machine,{
    if(
       machine->state == SystemIsLive_Waiting_state
    ){
      error("SystemIsLive",SystemIsLive_state_name(machine->state),2,false);
    }
  });
}

/**************************************/
/* Automaton for : SystemIsResponsive */
/**************************************/

struct SystemIsResponsive_state{
  struct SystemIsResponsive_state *next;
  struct SystemIsResponsive_state *previous;
  int state;
};

typedef struct SystemIsResponsive_state *SystemIsResponsive_instance;

static SystemIsResponsive_instance newSystemIsResponsive(){
  return (SystemIsResponsive_instance)malloc(sizeof(struct SystemIsResponsive_state));
}

static void init_SystemIsResponsive_state(SystemIsResponsive_instance machine,int state){
  machine->state = state;
}

SystemIsResponsive_instance SystemIsResponsive_freeList = NULL;
SystemIsResponsive_instance SystemIsResponsive_currList = NULL;
SystemIsResponsive_instance SystemIsResponsive_nextList = NULL;
int SystemIsResponsive_stop_reset_status = 0;

#define ADD_SystemIsResponsive(list, machine)\
  SGLIB_DL_LIST_ADD(struct SystemIsResponsive_state, list, machine, previous, next);

#define ADD_NEXT_SystemIsResponsive(machine)\
  {\
    SystemIsResponsive_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct SystemIsResponsive_state, SystemIsResponsive_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_SystemIsResponsive(SystemIsResponsive_freeList,machine);\
    }\
  }

#define DELETE_SystemIsResponsive(list, machine)\
  SGLIB_DL_LIST_DELETE(struct SystemIsResponsive_state, list, machine, previous, next);

#define FREE_SystemIsResponsive(machine)\
  DELETE_SystemIsResponsive(SystemIsResponsive_currList,machine);\
  ADD_SystemIsResponsive(SystemIsResponsive_freeList,machine)

#define ALLOCATE_SystemIsResponsive(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct SystemIsResponsive_state, SystemIsResponsive_freeList, previous, next, machine);\
  DELETE_SystemIsResponsive(SystemIsResponsive_freeList, machine);

#define CURR_TO_NEXT_SystemIsResponsive(machine)\
  DELETE_SystemIsResponsive(SystemIsResponsive_currList, machine);\
  ADD_NEXT_SystemIsResponsive(machine);

#define FREE_TO_NEXT_SystemIsResponsive(state)\
  SystemIsResponsive_instance machine;\
  if(SystemIsResponsive_freeList != NULL){\
    ALLOCATE_SystemIsResponsive(machine);\
    init_SystemIsResponsive_state(machine,state);\
    ADD_NEXT_SystemIsResponsive(machine);\
  }else{\
    error("SystemIsResponsive",SystemIsResponsive_state_name(state),3,false);\
  }

#define MAP_ACTIVE_SystemIsResponsive(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct SystemIsResponsive_state, SystemIsResponsive_currList, machine, previous, next, cmd);

static int SystemIsResponsive_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct SystemIsResponsive_state, SystemIsResponsive_freeList, previous, next, result)
  return result;
}

#define SystemIsResponsive_Start_state 1
#define SystemIsResponsive_Waiting_state 2
#define SystemIsResponsive_Done_state 3

static string SystemIsResponsive_state_name(int state){
  switch(state){
    case SystemIsResponsive_Start_state: return "Start";
    case SystemIsResponsive_Waiting_state: return "Waiting";
    case SystemIsResponsive_Done_state: return "Done";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_SystemIsResponsive_states(){
  SystemIsResponsive_instance machine;
  printf("\n-- SystemIsResponsive --\n");
  MAP_ACTIVE_SystemIsResponsive(machine,{
    printf("state = %s\n", SystemIsResponsive_state_name(machine->state));
  });
  printf("free : %d\n",SystemIsResponsive_freeList_length());
}

static void init_SystemIsResponsive(int noOfMachines){
  int i;
  SystemIsResponsive_instance r = newSystemIsResponsive();
  init_SystemIsResponsive_state(r,SystemIsResponsive_Start_state);
  if(noOfMachines>0)
    ADD_SystemIsResponsive(SystemIsResponsive_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newSystemIsResponsive();
    ADD_SystemIsResponsive(SystemIsResponsive_freeList, r);
  }
}

static void stop_reset_SystemIsResponsive(){
  SystemIsResponsive_instance machine;
  if(SystemIsResponsive_stop_reset_status > 0){
    MAP_ACTIVE_SystemIsResponsive(machine,{FREE_SystemIsResponsive(machine);});
    if(SystemIsResponsive_stop_reset_status == 1){
      ALLOCATE_SystemIsResponsive(machine);
      init_SystemIsResponsive_state(machine,SystemIsResponsive_Start_state);
      ADD_SystemIsResponsive(SystemIsResponsive_currList,machine);
    }
    SystemIsResponsive_stop_reset_status = 0;
  };
}

static void next_step_SystemIsResponsive(SystemIsResponsive_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case SystemIsResponsive_Start_state :
      if(IS(success_event)){FREE_TO_NEXT_SystemIsResponsive(SystemIsResponsive_Waiting_state);T = true;K = true;}
      break;
    case SystemIsResponsive_Waiting_state :
      if(IS(execute_event)){T = true;}
      if(T == false){error("SystemIsResponsive","Waiting",1,false);T = true;};
      break;
    case SystemIsResponsive_Done_state :
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_SystemIsResponsive(machine);
  }
  else{
    FREE_SystemIsResponsive(machine);
  }
}

static void next_SystemIsResponsive(){
  if(
    true
  ){
    SystemIsResponsive_nextList = NULL;
    SystemIsResponsive_instance machine;
    MAP_ACTIVE_SystemIsResponsive(machine,{next_step_SystemIsResponsive(machine);});
    SystemIsResponsive_currList = SystemIsResponsive_nextList;
  }
}

static void end_SystemIsResponsive(){
  SystemIsResponsive_instance machine;
  MAP_ACTIVE_SystemIsResponsive(machine,{
    if(
       machine->state == SystemIsResponsive_Waiting_state
    ){
      error("SystemIsResponsive",SystemIsResponsive_state_name(machine->state),2,false);
    }
  });
}

/*********************************/
/* Automaton for : SucceedOrFail */
/*********************************/

struct SucceedOrFail_state{
  struct SucceedOrFail_state *next;
  struct SucceedOrFail_state *previous;
  int state;
};

typedef struct SucceedOrFail_state *SucceedOrFail_instance;

static SucceedOrFail_instance newSucceedOrFail(){
  return (SucceedOrFail_instance)malloc(sizeof(struct SucceedOrFail_state));
}

static void init_SucceedOrFail_state(SucceedOrFail_instance machine,int state){
  machine->state = state;
}

SucceedOrFail_instance SucceedOrFail_freeList = NULL;
SucceedOrFail_instance SucceedOrFail_currList = NULL;
SucceedOrFail_instance SucceedOrFail_nextList = NULL;
int SucceedOrFail_stop_reset_status = 0;

#define ADD_SucceedOrFail(list, machine)\
  SGLIB_DL_LIST_ADD(struct SucceedOrFail_state, list, machine, previous, next);

#define ADD_NEXT_SucceedOrFail(machine)\
  {\
    SucceedOrFail_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct SucceedOrFail_state, SucceedOrFail_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_SucceedOrFail(SucceedOrFail_freeList,machine);\
    }\
  }

#define DELETE_SucceedOrFail(list, machine)\
  SGLIB_DL_LIST_DELETE(struct SucceedOrFail_state, list, machine, previous, next);

#define FREE_SucceedOrFail(machine)\
  DELETE_SucceedOrFail(SucceedOrFail_currList,machine);\
  ADD_SucceedOrFail(SucceedOrFail_freeList,machine)

#define ALLOCATE_SucceedOrFail(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct SucceedOrFail_state, SucceedOrFail_freeList, previous, next, machine);\
  DELETE_SucceedOrFail(SucceedOrFail_freeList, machine);

#define CURR_TO_NEXT_SucceedOrFail(machine)\
  DELETE_SucceedOrFail(SucceedOrFail_currList, machine);\
  ADD_NEXT_SucceedOrFail(machine);

#define FREE_TO_NEXT_SucceedOrFail(state)\
  SucceedOrFail_instance machine;\
  if(SucceedOrFail_freeList != NULL){\
    ALLOCATE_SucceedOrFail(machine);\
    init_SucceedOrFail_state(machine,state);\
    ADD_NEXT_SucceedOrFail(machine);\
  }else{\
    error("SucceedOrFail",SucceedOrFail_state_name(state),3,false);\
  }

#define MAP_ACTIVE_SucceedOrFail(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct SucceedOrFail_state, SucceedOrFail_currList, machine, previous, next, cmd);

static int SucceedOrFail_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct SucceedOrFail_state, SucceedOrFail_freeList, previous, next, result)
  return result;
}

#define SucceedOrFail_Start_state 1
#define SucceedOrFail_Waiting_state 2
#define SucceedOrFail_Done_state 3

static string SucceedOrFail_state_name(int state){
  switch(state){
    case SucceedOrFail_Start_state: return "Start";
    case SucceedOrFail_Waiting_state: return "Waiting";
    case SucceedOrFail_Done_state: return "Done";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_SucceedOrFail_states(){
  SucceedOrFail_instance machine;
  printf("\n-- SucceedOrFail --\n");
  MAP_ACTIVE_SucceedOrFail(machine,{
    printf("state = %s\n", SucceedOrFail_state_name(machine->state));
  });
  printf("free : %d\n",SucceedOrFail_freeList_length());
}

static void init_SucceedOrFail(int noOfMachines){
  int i;
  SucceedOrFail_instance r = newSucceedOrFail();
  init_SucceedOrFail_state(r,SucceedOrFail_Start_state);
  if(noOfMachines>0)
    ADD_SucceedOrFail(SucceedOrFail_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newSucceedOrFail();
    ADD_SucceedOrFail(SucceedOrFail_freeList, r);
  }
}

static void stop_reset_SucceedOrFail(){
  SucceedOrFail_instance machine;
  if(SucceedOrFail_stop_reset_status > 0){
    MAP_ACTIVE_SucceedOrFail(machine,{FREE_SucceedOrFail(machine);});
    if(SucceedOrFail_stop_reset_status == 1){
      ALLOCATE_SucceedOrFail(machine);
      init_SucceedOrFail_state(machine,SucceedOrFail_Start_state);
      ADD_SucceedOrFail(SucceedOrFail_currList,machine);
    }
    SucceedOrFail_stop_reset_status = 0;
  };
}

static void next_step_SucceedOrFail(SucceedOrFail_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case SucceedOrFail_Start_state :
      if(IS(newCmd_event)){FREE_TO_NEXT_SucceedOrFail(SucceedOrFail_Waiting_state);T = true;K = true;}
      break;
    case SucceedOrFail_Waiting_state :
      if(IS(varUpdate_event)){error("SucceedOrFail","Waiting",0,false);T = true;K = true;}
      if(IS(finalResult_event)){T = true;}
      break;
    case SucceedOrFail_Done_state :
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_SucceedOrFail(machine);
  }
  else{
    FREE_SucceedOrFail(machine);
  }
}

static void next_SucceedOrFail(){
  if(
    IS(finalResult_event)||IS(newCmd_event)||IS(varUpdate_event)
  ){
    SucceedOrFail_nextList = NULL;
    SucceedOrFail_instance machine;
    MAP_ACTIVE_SucceedOrFail(machine,{next_step_SucceedOrFail(machine);});
    SucceedOrFail_currList = SucceedOrFail_nextList;
  }
}

static void end_SucceedOrFail(){
  SucceedOrFail_instance machine;
  MAP_ACTIVE_SucceedOrFail(machine,{
    if(
       machine->state == SucceedOrFail_Waiting_state
    ){
      error("SucceedOrFail",SucceedOrFail_state_name(machine->state),2,false);
    }
  });
}

/**************************/
/* Automaton for : Never1 */
/**************************/

struct Never1_state{
  struct Never1_state *next;
  struct Never1_state *previous;
  int state;
};

typedef struct Never1_state *Never1_instance;

static Never1_instance newNever1(){
  return (Never1_instance)malloc(sizeof(struct Never1_state));
}

static void init_Never1_state(Never1_instance machine,int state){
  machine->state = state;
}

Never1_instance Never1_freeList = NULL;
Never1_instance Never1_currList = NULL;
Never1_instance Never1_nextList = NULL;
int Never1_stop_reset_status = 0;

#define ADD_Never1(list, machine)\
  SGLIB_DL_LIST_ADD(struct Never1_state, list, machine, previous, next);

#define ADD_NEXT_Never1(machine)\
  {\
    Never1_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct Never1_state, Never1_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_Never1(Never1_freeList,machine);\
    }\
  }

#define DELETE_Never1(list, machine)\
  SGLIB_DL_LIST_DELETE(struct Never1_state, list, machine, previous, next);

#define FREE_Never1(machine)\
  DELETE_Never1(Never1_currList,machine);\
  ADD_Never1(Never1_freeList,machine)

#define ALLOCATE_Never1(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct Never1_state, Never1_freeList, previous, next, machine);\
  DELETE_Never1(Never1_freeList, machine);

#define CURR_TO_NEXT_Never1(machine)\
  DELETE_Never1(Never1_currList, machine);\
  ADD_NEXT_Never1(machine);

#define FREE_TO_NEXT_Never1(state)\
  Never1_instance machine;\
  if(Never1_freeList != NULL){\
    ALLOCATE_Never1(machine);\
    init_Never1_state(machine,state);\
    ADD_NEXT_Never1(machine);\
  }else{\
    error("Never1",Never1_state_name(state),3,false);\
  }

#define MAP_ACTIVE_Never1(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct Never1_state, Never1_currList, machine, previous, next, cmd);

static int Never1_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct Never1_state, Never1_freeList, previous, next, result)
  return result;
}

#define Never1_S0_state 1
#define Never1_acceptS1_state 2
#define Never1_acceptS2_state 3
#define Never1_S3_state 4

static string Never1_state_name(int state){
  switch(state){
    case Never1_S0_state: return "S0";
    case Never1_acceptS1_state: return "acceptS1";
    case Never1_acceptS2_state: return "acceptS2";
    case Never1_S3_state: return "S3";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_Never1_states(){
  Never1_instance machine;
  printf("\n-- Never1 --\n");
  MAP_ACTIVE_Never1(machine,{
    printf("state = %s\n", Never1_state_name(machine->state));
  });
  printf("free : %d\n",Never1_freeList_length());
}

static void init_Never1(int noOfMachines){
  int i;
  Never1_instance r = newNever1();
  init_Never1_state(r,Never1_S0_state);
  if(noOfMachines>0)
    ADD_Never1(Never1_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newNever1();
    ADD_Never1(Never1_freeList, r);
  }
}

static void stop_reset_Never1(){
  Never1_instance machine;
  if(Never1_stop_reset_status > 0){
    MAP_ACTIVE_Never1(machine,{FREE_Never1(machine);});
    if(Never1_stop_reset_status == 1){
      ALLOCATE_Never1(machine);
      init_Never1_state(machine,Never1_S0_state);
      ADD_Never1(Never1_currList,machine);
    }
    Never1_stop_reset_status = 0;
  };
}

static void next_step_Never1(Never1_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case Never1_S0_state :
      if(IS(new_event)){FREE_TO_NEXT_Never1(Never1_acceptS2_state);T = true;K = true;}
      break;
    case Never1_acceptS1_state :
      break;
    case Never1_acceptS2_state :
      if(IS(val_event)){T = true;}
      if(IS(exe_event)){error("Never1","acceptS2",0,false);T = true;}
      break;
    case Never1_S3_state :
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_Never1(machine);
  }
  else{
    FREE_Never1(machine);
  }
}

static void next_Never1(){
  if(
    true
  ){
    Never1_nextList = NULL;
    Never1_instance machine;
    MAP_ACTIVE_Never1(machine,{next_step_Never1(machine);});
    Never1_currList = Never1_nextList;
  }
}

static void end_Never1(){
  Never1_instance machine;
  MAP_ACTIVE_Never1(machine,{
    if(
       machine->state == Never1_acceptS2_state
    ){
      error("Never1",Never1_state_name(machine->state),2,false);
    }
  });
}

/**************************/
/* Private Main Functions */
/**************************/

void stop_reset_monitors(){
  if(global_stop_or_reset){
    stop_reset_OneCommandAtATime();
    stop_reset_SystemIsLive();
    stop_reset_SystemIsResponsive();
    stop_reset_SucceedOrFail();
    stop_reset_Never1();
  };
  global_stop_or_reset = false;
}

/*************************/
/* Public Main Functions */
/*************************/

void M_print_monitors(){
  print_OneCommandAtATime_states();
  print_SystemIsLive_states();
  print_SystemIsResponsive_states();
  print_SucceedOrFail_states();
  print_Never1_states();
}

void M_init(){
  init_OneCommandAtATime(10);
  init_SystemIsLive(10);
  init_SystemIsResponsive(10);
  init_SucceedOrFail(10);
  init_Never1(10);
  if(DEBUG_FLAG){
    M_print_monitors();
  }
}

void M_submit(int event){
  curr_event.kind = event;
  if(DEBUG_FLAG){
    printf("\n=== [%s]: ========================\n", event_name());
  }
  next_OneCommandAtATime();
  next_SystemIsLive();
  next_SystemIsResponsive();
  next_SucceedOrFail();
  next_Never1();
  stop_reset_monitors();
  if(DEBUG_FLAG){
    M_print_monitors();
  }
}

void M_stop_monitor(string monitor){
  if(monitor == "OneCommandAtATime")OneCommandAtATime_stop_reset_status = 2;
  else
  if(monitor == "SystemIsLive")SystemIsLive_stop_reset_status = 2;
  else
  if(monitor == "SystemIsResponsive")SystemIsResponsive_stop_reset_status = 2;
  else
  if(monitor == "SucceedOrFail")SucceedOrFail_stop_reset_status = 2;
  else
  if(monitor == "Never1")Never1_stop_reset_status = 2;
  global_stop_or_reset = true;
}

void M_reset_monitor(string monitor){
  if(monitor == "OneCommandAtATime" && OneCommandAtATime_stop_reset_status == 0)OneCommandAtATime_stop_reset_status = 1;
  else
  if(monitor == "SystemIsLive" && SystemIsLive_stop_reset_status == 0)SystemIsLive_stop_reset_status = 1;
  else
  if(monitor == "SystemIsResponsive" && SystemIsResponsive_stop_reset_status == 0)SystemIsResponsive_stop_reset_status = 1;
  else
  if(monitor == "SucceedOrFail" && SucceedOrFail_stop_reset_status == 0)SucceedOrFail_stop_reset_status = 1;
  else
  if(monitor == "Never1" && Never1_stop_reset_status == 0)Never1_stop_reset_status = 1;
  global_stop_or_reset = true;
}

void M_stop_all_monitors(){
  OneCommandAtATime_stop_reset_status = 2;
  SystemIsLive_stop_reset_status = 2;
  SystemIsResponsive_stop_reset_status = 2;
  SucceedOrFail_stop_reset_status = 2;
  Never1_stop_reset_status = 2;
  global_stop_or_reset = true;
}

void M_reset_all_monitors(){
  if(OneCommandAtATime_stop_reset_status == 0)OneCommandAtATime_stop_reset_status = 1;
  if(SystemIsLive_stop_reset_status == 0)SystemIsLive_stop_reset_status = 1;
  if(SystemIsResponsive_stop_reset_status == 0)SystemIsResponsive_stop_reset_status = 1;
  if(SucceedOrFail_stop_reset_status == 0)SucceedOrFail_stop_reset_status = 1;
  if(Never1_stop_reset_status == 0)Never1_stop_reset_status = 1;
  global_stop_or_reset = true;
}

void M_end(){
  end_OneCommandAtATime();
  end_SystemIsLive();
  end_SystemIsResponsive();
  end_SucceedOrFail();
  end_Never1();
}


