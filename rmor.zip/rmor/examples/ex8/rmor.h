
#define customValidate_event 1
#define execute_event 2
#define fail_event 3
#define newCommand_event 4
#define rejectCommand_event 5
#define success_event 6
#define validate_event 7

void M_init();
void M_print_monitors();
void M_submit(int event);
void M_stop_monitor(char *monitor);
void M_reset_monitor(char *monitor);
void M_stop_all_monitors();
void M_reset_all_monitors();
void M_end();
