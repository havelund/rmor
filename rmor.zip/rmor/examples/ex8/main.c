
#include <stdio.h>

int requested = 0;
int processed = 0;

void handler(char *monitor, char *state, int kind){
  printf("===> monitor %s encountered error %d in state %s\n",
         monitor, kind, state);
  // do something drastic!
}

void new_cmd(){
  printf("call new_cmd\n");
  requested++;
  printf("  update requested\n");
}

void cancel(){
  printf("call cancel\n");
  requested--;
  printf("  update requested\n");
}

void validate_cmd(){
  printf("call validate_cmd\n");
}

void custom_cmd(){
  printf("call custom_cmd\n");
}

void success_cmd(){
  printf("call success_cmd\n");
}

void fail_cmd(){
  printf("call fail_cmd\n");
}

void execute_cmd(){
  printf("call execute_cmd\n");
  processed++;
  printf("  update processed\n");
}

void reject_cmd(){
  printf("call reject_cmd\n");
  processed++;
  printf("  update processed\n");
}

void testmycode(){
  printf("call testmycode\n");
  success_cmd();
}

main(){
  new_cmd();
  execute_cmd();
  validate_cmd();
  success_cmd();
}









