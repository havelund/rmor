
/***********************/
/* RMOR Generated Code */
/***********************/


/************/
/* Preamble */
/************/

#include <stdlib.h>
#include <stdio.h>
#include "sglib.h"
#include "rmor.h"

#define string char*
#define bool int
#define true 1
#define false 0

#define SAME_STATE(x,y) ((int)(x->state)-(y->state))

#define DEBUG_FLAG 0
#define DEBUG if(DEBUG_FLAG)printf

static void error(string monitor, string state, int kind, bool handled){
  string msg;
  switch(kind){
    case 0 : msg = "error state entered";break;
    case 1 : msg = "next state not exited";break;
    case 2 : msg = "live state active at end";break;
    case 3 : msg = "states exhausted";
  };
  printf("*** %s.%s : %s\n",monitor,state,msg);
}

bool global_stop_or_reset = false;

/**********/
/* Events */
/**********/

struct{
  int kind;
} curr_event;

#define IS(E) (curr_event.kind == E)

static string event_name(){
  switch(curr_event.kind){
    case customValidate_event : return "customValidate";
    case execute_event : return "execute";
    case fail_event : return "fail";
    case newCommand_event : return "newCommand";
    case rejectCommand_event : return "rejectCommand";
    case success_event : return "success";
    case validate_event : return "validate";
    default : return "UNKNOWN";
  }
}

/******************************/
/* Automaton for : Validation */
/******************************/

struct Validation_state{
  struct Validation_state *next;
  struct Validation_state *previous;
  int state;
};

typedef struct Validation_state *Validation_instance;

static Validation_instance newValidation(){
  return (Validation_instance)malloc(sizeof(struct Validation_state));
}

static void init_Validation_state(Validation_instance machine,int state){
  machine->state = state;
}

Validation_instance Validation_freeList = NULL;
Validation_instance Validation_currList = NULL;
Validation_instance Validation_nextList = NULL;
int Validation_stop_reset_status = 0;

#define ADD_Validation(list, machine)\
  SGLIB_DL_LIST_ADD(struct Validation_state, list, machine, previous, next);

#define ADD_NEXT_Validation(machine)\
  {\
    Validation_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct Validation_state, Validation_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_Validation(Validation_freeList,machine);\
    }\
  }

#define DELETE_Validation(list, machine)\
  SGLIB_DL_LIST_DELETE(struct Validation_state, list, machine, previous, next);

#define FREE_Validation(machine)\
  DELETE_Validation(Validation_currList,machine);\
  ADD_Validation(Validation_freeList,machine)

#define ALLOCATE_Validation(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct Validation_state, Validation_freeList, previous, next, machine);\
  DELETE_Validation(Validation_freeList, machine);

#define CURR_TO_NEXT_Validation(machine)\
  DELETE_Validation(Validation_currList, machine);\
  ADD_NEXT_Validation(machine);

#define FREE_TO_NEXT_Validation(state)\
  Validation_instance machine;\
  if(Validation_freeList != NULL){\
    ALLOCATE_Validation(machine);\
    init_Validation_state(machine,state);\
    ADD_NEXT_Validation(machine);\
  }else{\
    error("Validation",Validation_state_name(state),3,false);\
  }

#define MAP_ACTIVE_Validation(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct Validation_state, Validation_currList, machine, previous, next, cmd);

static int Validation_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct Validation_state, Validation_freeList, previous, next, result)
  return result;
}

#define Validation_S1_state 1
#define Validation_S2_state 2
#define Validation_S3_state 3
#define Validation_S4_state 4
#define Validation_S5_state 5
#define Validation_S6_state 6
#define Validation_S7_state 7
#define Validation_S8_state 8

static string Validation_state_name(int state){
  switch(state){
    case Validation_S1_state: return "S1";
    case Validation_S2_state: return "S2";
    case Validation_S3_state: return "S3";
    case Validation_S4_state: return "S4";
    case Validation_S5_state: return "S5";
    case Validation_S6_state: return "S6";
    case Validation_S7_state: return "S7";
    case Validation_S8_state: return "S8";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_Validation_states(){
  Validation_instance machine;
  printf("\n-- Validation --\n");
  MAP_ACTIVE_Validation(machine,{
    printf("state = %s\n", Validation_state_name(machine->state));
  });
  printf("free : %d\n",Validation_freeList_length());
}

static void init_Validation(int noOfMachines){
  int i;
  Validation_instance r = newValidation();
  init_Validation_state(r,Validation_S1_state);
  if(noOfMachines>0)
    ADD_Validation(Validation_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newValidation();
    ADD_Validation(Validation_freeList, r);
  }
}

static void stop_reset_Validation(){
  Validation_instance machine;
  if(Validation_stop_reset_status > 0){
    MAP_ACTIVE_Validation(machine,{FREE_Validation(machine);});
    if(Validation_stop_reset_status == 1){
      ALLOCATE_Validation(machine);
      init_Validation_state(machine,Validation_S1_state);
      ADD_Validation(Validation_currList,machine);
    }
    Validation_stop_reset_status = 0;
  };
}

static void next_step_Validation(Validation_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case Validation_S1_state :
      if(IS(newCommand_event)){FREE_TO_NEXT_Validation(Validation_S2_state);T = true;}
      break;
    case Validation_S2_state :
      if(IS(execute_event)){error("Validation","S2",0,false);T = true;}
      if(IS(validate_event)){FREE_TO_NEXT_Validation(Validation_S3_state);T = true;}
      break;
    case Validation_S3_state :
      if(IS(fail_event)){FREE_TO_NEXT_Validation(Validation_S4_state);T = true;}
      if(IS(success_event)){FREE_TO_NEXT_Validation(Validation_S6_state);T = true;}
      break;
    case Validation_S4_state :
      if(IS(rejectCommand_event)){T = true;}
      break;
    case Validation_S5_state :
      break;
    case Validation_S6_state :
      if(IS(customValidate_event)){FREE_TO_NEXT_Validation(Validation_S7_state);T = true;}
      if(IS(execute_event)){T = true;}
      if(T == false){error("Validation","S6",1,false);T = true;};
      break;
    case Validation_S7_state :
      if(IS(customValidate_event)){FREE_TO_NEXT_Validation(Validation_S7_state);T = true;}
      if(IS(execute_event)){T = true;}
      if(T == false){error("Validation","S7",1,false);T = true;};
      break;
    case Validation_S8_state :
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_Validation(machine);
  }
  else{
    FREE_Validation(machine);
  }
}

static void next_Validation(){
  if(
    true
  ){
    Validation_nextList = NULL;
    Validation_instance machine;
    MAP_ACTIVE_Validation(machine,{next_step_Validation(machine);});
    Validation_currList = Validation_nextList;
  }
}

static void end_Validation(){
  Validation_instance machine;
  MAP_ACTIVE_Validation(machine,{
    if(
       machine->state == Validation_S2_state
    || machine->state == Validation_S4_state
    || machine->state == Validation_S6_state
    || machine->state == Validation_S7_state
    ){
      error("Validation",Validation_state_name(machine->state),2,false);
    }
  });
}

/**************************/
/* Private Main Functions */
/**************************/

void stop_reset_monitors(){
  if(global_stop_or_reset){
    stop_reset_Validation();
  };
  global_stop_or_reset = false;
}

/*************************/
/* Public Main Functions */
/*************************/

void M_print_monitors(){
  print_Validation_states();
}

void M_init(){
  init_Validation(10);
  if(DEBUG_FLAG){
    M_print_monitors();
  }
}

void M_submit(int event){
  curr_event.kind = event;
  if(DEBUG_FLAG){
    printf("\n=== [%s]: ========================\n", event_name());
  }
  next_Validation();
  stop_reset_monitors();
  if(DEBUG_FLAG){
    M_print_monitors();
  }
}

void M_stop_monitor(string monitor){
  if(monitor == "Validation")Validation_stop_reset_status = 2;
  global_stop_or_reset = true;
}

void M_reset_monitor(string monitor){
  if(monitor == "Validation" && Validation_stop_reset_status == 0)Validation_stop_reset_status = 1;
  global_stop_or_reset = true;
}

void M_stop_all_monitors(){
  Validation_stop_reset_status = 2;
  global_stop_or_reset = true;
}

void M_reset_all_monitors(){
  if(Validation_stop_reset_status == 0)Validation_stop_reset_status = 1;
  global_stop_or_reset = true;
}

void M_end(){
  end_Validation();
}


