
/***********************/
/* RMOR Generated Code */
/***********************/


/************/
/* Preamble */
/************/

#include <stdlib.h>
#include <stdio.h>
#include "sglib.h"
#include "rmor.h"

#define string char*
#define bool int
#define true 1
#define false 0

#define SAME_STATE(x,y) ((int)(x->state)-(y->state))

#define DEBUG_FLAG 0
#define DEBUG if(DEBUG_FLAG)printf

static void error(string monitor, string state, int kind, bool handled){
  string msg;
  switch(kind){
    case 0 : msg = "error state entered";break;
    case 1 : msg = "next state not exited";break;
    case 2 : msg = "live state active at end";break;
    case 3 : msg = "states exhausted";
  };
  printf("*** %s.%s : %s\n",monitor,state,msg);
}

bool global_stop_or_reset = false;

/**********/
/* Events */
/**********/

struct{
  int kind;
} curr_event;

#define IS(E) (curr_event.kind == E)

static string event_name(){
  switch(curr_event.kind){
    case close_event : return "close";
    case open_event : return "open";
    case process_event : return "process";
    default : return "UNKNOWN";
  }
}

/*****************************/
/* Automaton for : OpenClose */
/*****************************/

struct OpenClose_state{
  struct OpenClose_state *next;
  struct OpenClose_state *previous;
  int state;
};

typedef struct OpenClose_state *OpenClose_instance;

static OpenClose_instance newOpenClose(){
  return (OpenClose_instance)malloc(sizeof(struct OpenClose_state));
}

static void init_OpenClose_state(OpenClose_instance machine,int state){
  machine->state = state;
}

OpenClose_instance OpenClose_freeList = NULL;
OpenClose_instance OpenClose_currList = NULL;
OpenClose_instance OpenClose_nextList = NULL;
int OpenClose_stop_reset_status = 0;

#define ADD_OpenClose(list, machine)\
  SGLIB_DL_LIST_ADD(struct OpenClose_state, list, machine, previous, next);

#define ADD_NEXT_OpenClose(machine)\
  {\
    OpenClose_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct OpenClose_state, OpenClose_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_OpenClose(OpenClose_freeList,machine);\
    }\
  }

#define DELETE_OpenClose(list, machine)\
  SGLIB_DL_LIST_DELETE(struct OpenClose_state, list, machine, previous, next);

#define FREE_OpenClose(machine)\
  DELETE_OpenClose(OpenClose_currList,machine);\
  ADD_OpenClose(OpenClose_freeList,machine)

#define ALLOCATE_OpenClose(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct OpenClose_state, OpenClose_freeList, previous, next, machine);\
  DELETE_OpenClose(OpenClose_freeList, machine);

#define CURR_TO_NEXT_OpenClose(machine)\
  DELETE_OpenClose(OpenClose_currList, machine);\
  ADD_NEXT_OpenClose(machine);

#define FREE_TO_NEXT_OpenClose(state)\
  OpenClose_instance machine;\
  if(OpenClose_freeList != NULL){\
    ALLOCATE_OpenClose(machine);\
    init_OpenClose_state(machine,state);\
    ADD_NEXT_OpenClose(machine);\
  }else{\
    error("OpenClose",OpenClose_state_name(state),3,false);\
  }

#define MAP_ACTIVE_OpenClose(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct OpenClose_state, OpenClose_currList, machine, previous, next, cmd);

static int OpenClose_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct OpenClose_state, OpenClose_freeList, previous, next, result)
  return result;
}

#define OpenClose_FileClosed_state 1
#define OpenClose_FileOpen_state 2

static string OpenClose_state_name(int state){
  switch(state){
    case OpenClose_FileClosed_state: return "FileClosed";
    case OpenClose_FileOpen_state: return "FileOpen";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_OpenClose_states(){
  OpenClose_instance machine;
  printf("\n-- OpenClose --\n");
  MAP_ACTIVE_OpenClose(machine,{
    printf("state = %s\n", OpenClose_state_name(machine->state));
  });
  printf("free : %d\n",OpenClose_freeList_length());
}

static void init_OpenClose(int noOfMachines){
  int i;
  OpenClose_instance r = newOpenClose();
  init_OpenClose_state(r,OpenClose_FileClosed_state);
  if(noOfMachines>0)
    ADD_OpenClose(OpenClose_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newOpenClose();
    ADD_OpenClose(OpenClose_freeList, r);
  }
}

static void stop_reset_OpenClose(){
  OpenClose_instance machine;
  if(OpenClose_stop_reset_status > 0){
    MAP_ACTIVE_OpenClose(machine,{FREE_OpenClose(machine);});
    if(OpenClose_stop_reset_status == 1){
      ALLOCATE_OpenClose(machine);
      init_OpenClose_state(machine,OpenClose_FileClosed_state);
      ADD_OpenClose(OpenClose_currList,machine);
    }
    OpenClose_stop_reset_status = 0;
  };
}

static void next_step_OpenClose(OpenClose_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case OpenClose_FileClosed_state :
      if(IS(open_event)){FREE_TO_NEXT_OpenClose(OpenClose_FileOpen_state);T = true;}
      if(IS(process_event)){error("OpenClose","FileClosed",0,false);T = true;K = true;}
      if(IS(close_event)){error("OpenClose","FileClosed",0,false);T = true;K = true;}
      break;
    case OpenClose_FileOpen_state :
      if(IS(open_event)){error("OpenClose","FileOpen",0,false);T = true;K = true;}
      if(IS(close_event)){FREE_TO_NEXT_OpenClose(OpenClose_FileClosed_state);T = true;}
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_OpenClose(machine);
  }
  else{
    FREE_OpenClose(machine);
  }
}

static void next_OpenClose(){
  if(
    IS(close_event)||IS(open_event)||IS(process_event)
  ){
    OpenClose_nextList = NULL;
    OpenClose_instance machine;
    MAP_ACTIVE_OpenClose(machine,{next_step_OpenClose(machine);});
    OpenClose_currList = OpenClose_nextList;
  }
}

static void end_OpenClose(){
  OpenClose_instance machine;
  MAP_ACTIVE_OpenClose(machine,{
    if(
       machine->state == OpenClose_FileOpen_state
    ){
      error("OpenClose",OpenClose_state_name(machine->state),2,false);
    }
  });
}

/**************************/
/* Private Main Functions */
/**************************/

void stop_reset_monitors(){
  if(global_stop_or_reset){
    stop_reset_OpenClose();
  };
  global_stop_or_reset = false;
}

/*************************/
/* Public Main Functions */
/*************************/

void M_print_monitors(){
  print_OpenClose_states();
}

void M_init(){
  init_OpenClose(10);
  if(DEBUG_FLAG){
    M_print_monitors();
  }
}

void M_submit(int event){
  curr_event.kind = event;
  if(DEBUG_FLAG){
    printf("\n=== [%s]: ========================\n", event_name());
  }
  next_OpenClose();
  stop_reset_monitors();
  if(DEBUG_FLAG){
    M_print_monitors();
  }
}

void M_stop_monitor(string monitor){
  if(monitor == "OpenClose")OpenClose_stop_reset_status = 2;
  global_stop_or_reset = true;
}

void M_reset_monitor(string monitor){
  if(monitor == "OpenClose" && OpenClose_stop_reset_status == 0)OpenClose_stop_reset_status = 1;
  global_stop_or_reset = true;
}

void M_stop_all_monitors(){
  OpenClose_stop_reset_status = 2;
  global_stop_or_reset = true;
}

void M_reset_all_monitors(){
  if(OpenClose_stop_reset_status == 0)OpenClose_stop_reset_status = 1;
  global_stop_or_reset = true;
}

void M_end(){
  end_OpenClose();
}


