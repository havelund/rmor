
#include <stdio.h>
#include <stdlib.h>

#define bool int
#define false 0
#define true  1

struct FileStr{
  char* name;
  char* data; // simplified view of a file, not used
};

typedef struct FileStr *File;

File openfile(char* fileName) {
  printf("opening file %s\n",fileName);
  File file = (File)malloc(sizeof(struct FileStr));
  file->name = fileName;
  file->data = NULL;
  return file;
}

void closefile(File file) {
  printf("closing file %s\n",file->name);
}

void processfile(File file) {
  printf("processing file %s\n",file->name);
}

bool important(char* name) {
  return name == "silverbullet";
}

void handler(char *monitor, char *state, int kind){
  printf("--- HANDLER TAKES OVER: monitor %s encountered error %d in state %s\n",
         monitor, kind, state);
  // do something drastic!
}

main(){

  File file; 

  // first we don't open the file properly before processing and closing:
  file = (File)malloc(sizeof(struct FileStr));
  file->name = "self_opened_file";
  file->data = NULL;
  processfile(file); // error : file not opened with openfile
  closefile(file);   // error : file not opened with openfile

  // then we open, but do not close due to an "unimportant" file name:
  file = openfile("data"); 
  if (important(file->name)) { // evaluates to false since data is not "important"
    processfile(file);
    closefile(file); // therefore this is not executed
  }
}









