
#include <stdio.h>

#define bool int
#define false 0
#define true  1

void openfile(char* file) {
  printf("opening file: %s\n",file);
}

char* readfile(char* file) {
  printf("reading file: %s\n",file);
  return "some data";
}

void closefile(char* file) {
  printf("closing file: %s\n",file);
}

void senddata(char* data) {
  printf("sending: %s\n",data);
}

void finish() {
  printf("finishing\n");
}

void handler(char *monitor, char *state, int kind){
  printf("--- HANDLER TAKES OVER: monitor %s encountered error %d in state %s\n",
         monitor, kind, state);
  printf("*** this is really bad");
}

main(){
  char* file;;
  char* data;

  file = "imagedata";
  openfile(file); 
  data = readfile(file); 
  senddata(data); 
  closefile(file); 

  file = "drilldata";
  openfile(file); 
  senddata("opened drill data");

  finish();
}









