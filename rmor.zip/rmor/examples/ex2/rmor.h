
#define execute_event 1
#define finalResult_event 2
#define new_event 3
#define newCmd_event 4
#define validate_event 5
#define varUpdate_event 6

void M_init();
void M_print_monitors();
void M_submit(int event);
void M_stop_monitor(char *monitor);
void M_reset_monitor(char *monitor);
void M_stop_all_monitors();
void M_reset_all_monitors();
void M_end();
