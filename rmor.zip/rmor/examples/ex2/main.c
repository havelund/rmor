
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "rmor.h"

#define string char*
#define bool   int
#define true   1
#define false  0

void handler(char *monitor, char *state, int kind){
  printf("--- HANDLER TAKES OVER: monitor %s encountered error %d in state %s\n",
         monitor, kind, state);
  // do something drastic!
}

void read_cmd(char cmd[]){
  char line[512];
  fgets(line,80,stdin);
  int cmd_length = strlen(line) - 1;
  (void)strncpy(cmd,line,cmd_length);
  cmd[cmd_length] = '\0';
}

extern bool debug;

int main(){
  char cmd[512];

  for (;;) {
    printf("Command: ");
    read_cmd(cmd);   

    if (strcmp(cmd, "rr") == 0){
      M_reset_all_monitors();
    } else 
    if (strcmp(cmd, "ss") == 0){	
      M_stop_all_monitors();
    } else 
    if (strcmp(cmd, "pp") == 0){	
      M_print_monitors();
    } else 
    if (strcmp(cmd, "qq") == 0){	
      break;
    } else
    if (strcmp(cmd, "dd") == 0){
      if(debug == true){ 
        debug = false;
      } else { 
        debug = true;
      };
    } else
    if (strcmp(cmd, "n") == 0){
      new();      
    } else
    if (strcmp(cmd, "v") == 0){
      validate();      
    } else
    if (strcmp(cmd, "c") == 0){
      custom_validate();      
    } else
    if (strcmp(cmd, "s") == 0){
      success();      
    } else
    if (strcmp(cmd, "f") == 0){
      fail();;      
    } else
    if (strcmp(cmd, "e") == 0){
      execute();      
    } else 
    if (strcmp(cmd, "r") == 0){
      reject();      
    } else {
      printf("*** unknown command %s\n", cmd);
    };
    if(debug)M_print_monitors();
  }	

}




