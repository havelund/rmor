
/***********************/
/* RMOR Generated Code */
/***********************/


/************/
/* Preamble */
/************/

#include <stdlib.h>
#include <stdio.h>
#include "sglib.h"
#include "rmor.h"

#define string char*
#define bool int
#define true 1
#define false 0

#define SAME_STATE(x,y) ((int)(x->state)-(y->state))

#define DEBUG_FLAG 0
#define DEBUG if(DEBUG_FLAG)printf

static void error(string monitor, string state, int kind, bool handled){
  string msg;
  switch(kind){
    case 0 : msg = "error state entered";break;
    case 1 : msg = "next state not exited";break;
    case 2 : msg = "live state active at end";break;
    case 3 : msg = "states exhausted";
  };
  printf("*** %s.%s : %s\n",monitor,state,msg);
}

bool global_stop_or_reset = false;

/**********/
/* Events */
/**********/

struct{
  int kind;
} curr_event;

#define IS(E) (curr_event.kind == E)

static string event_name(){
  switch(curr_event.kind){
    case execute_event : return "execute";
    case finalResult_event : return "finalResult";
    case new_event : return "new";
    case newCmd_event : return "newCmd";
    case validate_event : return "validate";
    case varUpdate_event : return "varUpdate";
    default : return "UNKNOWN";
  }
}

/**********************************************/
/* Automaton for : no_execute_before_validate */
/**********************************************/

struct no_execute_before_validate_state{
  struct no_execute_before_validate_state *next;
  struct no_execute_before_validate_state *previous;
  int state;
};

typedef struct no_execute_before_validate_state *no_execute_before_validate_instance;

static no_execute_before_validate_instance newno_execute_before_validate(){
  return (no_execute_before_validate_instance)malloc(sizeof(struct no_execute_before_validate_state));
}

static void init_no_execute_before_validate_state(no_execute_before_validate_instance machine,int state){
  machine->state = state;
}

no_execute_before_validate_instance no_execute_before_validate_freeList = NULL;
no_execute_before_validate_instance no_execute_before_validate_currList = NULL;
no_execute_before_validate_instance no_execute_before_validate_nextList = NULL;
int no_execute_before_validate_stop_reset_status = 0;

#define ADD_no_execute_before_validate(list, machine)\
  SGLIB_DL_LIST_ADD(struct no_execute_before_validate_state, list, machine, previous, next);

#define ADD_NEXT_no_execute_before_validate(machine)\
  {\
    no_execute_before_validate_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct no_execute_before_validate_state, no_execute_before_validate_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_no_execute_before_validate(no_execute_before_validate_freeList,machine);\
    }\
  }

#define DELETE_no_execute_before_validate(list, machine)\
  SGLIB_DL_LIST_DELETE(struct no_execute_before_validate_state, list, machine, previous, next);

#define FREE_no_execute_before_validate(machine)\
  DELETE_no_execute_before_validate(no_execute_before_validate_currList,machine);\
  ADD_no_execute_before_validate(no_execute_before_validate_freeList,machine)

#define ALLOCATE_no_execute_before_validate(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct no_execute_before_validate_state, no_execute_before_validate_freeList, previous, next, machine);\
  DELETE_no_execute_before_validate(no_execute_before_validate_freeList, machine);

#define CURR_TO_NEXT_no_execute_before_validate(machine)\
  DELETE_no_execute_before_validate(no_execute_before_validate_currList, machine);\
  ADD_NEXT_no_execute_before_validate(machine);

#define FREE_TO_NEXT_no_execute_before_validate(state)\
  no_execute_before_validate_instance machine;\
  if(no_execute_before_validate_freeList != NULL){\
    ALLOCATE_no_execute_before_validate(machine);\
    init_no_execute_before_validate_state(machine,state);\
    ADD_NEXT_no_execute_before_validate(machine);\
  }else{\
    error("no_execute_before_validate",no_execute_before_validate_state_name(state),3,false);\
  }

#define MAP_ACTIVE_no_execute_before_validate(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct no_execute_before_validate_state, no_execute_before_validate_currList, machine, previous, next, cmd);

static int no_execute_before_validate_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct no_execute_before_validate_state, no_execute_before_validate_freeList, previous, next, result)
  return result;
}

#define no_execute_before_validate_Start_state 1
#define no_execute_before_validate_Waiting_state 2
#define no_execute_before_validate_Done_state 3

static string no_execute_before_validate_state_name(int state){
  switch(state){
    case no_execute_before_validate_Start_state: return "Start";
    case no_execute_before_validate_Waiting_state: return "Waiting";
    case no_execute_before_validate_Done_state: return "Done";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_no_execute_before_validate_states(){
  no_execute_before_validate_instance machine;
  printf("\n-- no_execute_before_validate --\n");
  MAP_ACTIVE_no_execute_before_validate(machine,{
    printf("state = %s\n", no_execute_before_validate_state_name(machine->state));
  });
  printf("free : %d\n",no_execute_before_validate_freeList_length());
}

static void init_no_execute_before_validate(int noOfMachines){
  int i;
  no_execute_before_validate_instance r = newno_execute_before_validate();
  init_no_execute_before_validate_state(r,no_execute_before_validate_Start_state);
  if(noOfMachines>0)
    ADD_no_execute_before_validate(no_execute_before_validate_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newno_execute_before_validate();
    ADD_no_execute_before_validate(no_execute_before_validate_freeList, r);
  }
}

static void stop_reset_no_execute_before_validate(){
  no_execute_before_validate_instance machine;
  if(no_execute_before_validate_stop_reset_status > 0){
    MAP_ACTIVE_no_execute_before_validate(machine,{FREE_no_execute_before_validate(machine);});
    if(no_execute_before_validate_stop_reset_status == 1){
      ALLOCATE_no_execute_before_validate(machine);
      init_no_execute_before_validate_state(machine,no_execute_before_validate_Start_state);
      ADD_no_execute_before_validate(no_execute_before_validate_currList,machine);
    }
    no_execute_before_validate_stop_reset_status = 0;
  };
}

static void next_step_no_execute_before_validate(no_execute_before_validate_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case no_execute_before_validate_Start_state :
      if(IS(new_event)){FREE_TO_NEXT_no_execute_before_validate(no_execute_before_validate_Waiting_state);T = true;K = true;}
      break;
    case no_execute_before_validate_Waiting_state :
      if(IS(execute_event)){error("no_execute_before_validate","Waiting",0,false);T = true;K = true;}
      if(IS(validate_event)){T = true;}
      break;
    case no_execute_before_validate_Done_state :
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_no_execute_before_validate(machine);
  }
  else{
    FREE_no_execute_before_validate(machine);
  }
}

static void next_no_execute_before_validate(){
  if(
    IS(execute_event)||IS(new_event)||IS(validate_event)
  ){
    no_execute_before_validate_nextList = NULL;
    no_execute_before_validate_instance machine;
    MAP_ACTIVE_no_execute_before_validate(machine,{next_step_no_execute_before_validate(machine);});
    no_execute_before_validate_currList = no_execute_before_validate_nextList;
  }
}

static void end_no_execute_before_validate(){
  no_execute_before_validate_instance machine;
  MAP_ACTIVE_no_execute_before_validate(machine,{
    if(
       machine->state == no_execute_before_validate_Waiting_state
    ){
      error("no_execute_before_validate",no_execute_before_validate_state_name(machine->state),2,false);
    }
  });
}

/*********************************/
/* Automaton for : SucceedOrFail */
/*********************************/

struct SucceedOrFail_state{
  struct SucceedOrFail_state *next;
  struct SucceedOrFail_state *previous;
  int state;
};

typedef struct SucceedOrFail_state *SucceedOrFail_instance;

static SucceedOrFail_instance newSucceedOrFail(){
  return (SucceedOrFail_instance)malloc(sizeof(struct SucceedOrFail_state));
}

static void init_SucceedOrFail_state(SucceedOrFail_instance machine,int state){
  machine->state = state;
}

SucceedOrFail_instance SucceedOrFail_freeList = NULL;
SucceedOrFail_instance SucceedOrFail_currList = NULL;
SucceedOrFail_instance SucceedOrFail_nextList = NULL;
int SucceedOrFail_stop_reset_status = 0;

#define ADD_SucceedOrFail(list, machine)\
  SGLIB_DL_LIST_ADD(struct SucceedOrFail_state, list, machine, previous, next);

#define ADD_NEXT_SucceedOrFail(machine)\
  {\
    SucceedOrFail_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct SucceedOrFail_state, SucceedOrFail_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_SucceedOrFail(SucceedOrFail_freeList,machine);\
    }\
  }

#define DELETE_SucceedOrFail(list, machine)\
  SGLIB_DL_LIST_DELETE(struct SucceedOrFail_state, list, machine, previous, next);

#define FREE_SucceedOrFail(machine)\
  DELETE_SucceedOrFail(SucceedOrFail_currList,machine);\
  ADD_SucceedOrFail(SucceedOrFail_freeList,machine)

#define ALLOCATE_SucceedOrFail(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct SucceedOrFail_state, SucceedOrFail_freeList, previous, next, machine);\
  DELETE_SucceedOrFail(SucceedOrFail_freeList, machine);

#define CURR_TO_NEXT_SucceedOrFail(machine)\
  DELETE_SucceedOrFail(SucceedOrFail_currList, machine);\
  ADD_NEXT_SucceedOrFail(machine);

#define FREE_TO_NEXT_SucceedOrFail(state)\
  SucceedOrFail_instance machine;\
  if(SucceedOrFail_freeList != NULL){\
    ALLOCATE_SucceedOrFail(machine);\
    init_SucceedOrFail_state(machine,state);\
    ADD_NEXT_SucceedOrFail(machine);\
  }else{\
    error("SucceedOrFail",SucceedOrFail_state_name(state),3,false);\
  }

#define MAP_ACTIVE_SucceedOrFail(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct SucceedOrFail_state, SucceedOrFail_currList, machine, previous, next, cmd);

static int SucceedOrFail_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct SucceedOrFail_state, SucceedOrFail_freeList, previous, next, result)
  return result;
}

#define SucceedOrFail_Start_state 1
#define SucceedOrFail_Waiting_state 2
#define SucceedOrFail_Done_state 3

static string SucceedOrFail_state_name(int state){
  switch(state){
    case SucceedOrFail_Start_state: return "Start";
    case SucceedOrFail_Waiting_state: return "Waiting";
    case SucceedOrFail_Done_state: return "Done";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_SucceedOrFail_states(){
  SucceedOrFail_instance machine;
  printf("\n-- SucceedOrFail --\n");
  MAP_ACTIVE_SucceedOrFail(machine,{
    printf("state = %s\n", SucceedOrFail_state_name(machine->state));
  });
  printf("free : %d\n",SucceedOrFail_freeList_length());
}

static void init_SucceedOrFail(int noOfMachines){
  int i;
  SucceedOrFail_instance r = newSucceedOrFail();
  init_SucceedOrFail_state(r,SucceedOrFail_Start_state);
  if(noOfMachines>0)
    ADD_SucceedOrFail(SucceedOrFail_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newSucceedOrFail();
    ADD_SucceedOrFail(SucceedOrFail_freeList, r);
  }
}

static void stop_reset_SucceedOrFail(){
  SucceedOrFail_instance machine;
  if(SucceedOrFail_stop_reset_status > 0){
    MAP_ACTIVE_SucceedOrFail(machine,{FREE_SucceedOrFail(machine);});
    if(SucceedOrFail_stop_reset_status == 1){
      ALLOCATE_SucceedOrFail(machine);
      init_SucceedOrFail_state(machine,SucceedOrFail_Start_state);
      ADD_SucceedOrFail(SucceedOrFail_currList,machine);
    }
    SucceedOrFail_stop_reset_status = 0;
  };
}

static void next_step_SucceedOrFail(SucceedOrFail_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case SucceedOrFail_Start_state :
      if(IS(newCmd_event)){FREE_TO_NEXT_SucceedOrFail(SucceedOrFail_Waiting_state);T = true;K = true;}
      break;
    case SucceedOrFail_Waiting_state :
      if(IS(varUpdate_event)){error("SucceedOrFail","Waiting",0,false);T = true;K = true;}
      if(IS(finalResult_event)){T = true;}
      break;
    case SucceedOrFail_Done_state :
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_SucceedOrFail(machine);
  }
  else{
    FREE_SucceedOrFail(machine);
  }
}

static void next_SucceedOrFail(){
  if(
    IS(finalResult_event)||IS(newCmd_event)||IS(varUpdate_event)
  ){
    SucceedOrFail_nextList = NULL;
    SucceedOrFail_instance machine;
    MAP_ACTIVE_SucceedOrFail(machine,{next_step_SucceedOrFail(machine);});
    SucceedOrFail_currList = SucceedOrFail_nextList;
  }
}

static void end_SucceedOrFail(){
  SucceedOrFail_instance machine;
  MAP_ACTIVE_SucceedOrFail(machine,{
    if(
       machine->state == SucceedOrFail_Waiting_state
    ){
      error("SucceedOrFail",SucceedOrFail_state_name(machine->state),2,false);
    }
  });
}

/**************************/
/* Private Main Functions */
/**************************/

void stop_reset_monitors(){
  if(global_stop_or_reset){
    stop_reset_no_execute_before_validate();
    stop_reset_SucceedOrFail();
  };
  global_stop_or_reset = false;
}

/*************************/
/* Public Main Functions */
/*************************/

void M_print_monitors(){
  print_no_execute_before_validate_states();
  print_SucceedOrFail_states();
}

void M_init(){
  init_no_execute_before_validate(10);
  init_SucceedOrFail(10);
  if(DEBUG_FLAG){
    M_print_monitors();
  }
}

void M_submit(int event){
  curr_event.kind = event;
  if(DEBUG_FLAG){
    printf("\n=== [%s]: ========================\n", event_name());
  }
  next_no_execute_before_validate();
  next_SucceedOrFail();
  stop_reset_monitors();
  if(DEBUG_FLAG){
    M_print_monitors();
  }
}

void M_stop_monitor(string monitor){
  if(monitor == "no_execute_before_validate")no_execute_before_validate_stop_reset_status = 2;
  else
  if(monitor == "SucceedOrFail")SucceedOrFail_stop_reset_status = 2;
  global_stop_or_reset = true;
}

void M_reset_monitor(string monitor){
  if(monitor == "no_execute_before_validate" && no_execute_before_validate_stop_reset_status == 0)no_execute_before_validate_stop_reset_status = 1;
  else
  if(monitor == "SucceedOrFail" && SucceedOrFail_stop_reset_status == 0)SucceedOrFail_stop_reset_status = 1;
  global_stop_or_reset = true;
}

void M_stop_all_monitors(){
  no_execute_before_validate_stop_reset_status = 2;
  SucceedOrFail_stop_reset_status = 2;
  global_stop_or_reset = true;
}

void M_reset_all_monitors(){
  if(no_execute_before_validate_stop_reset_status == 0)no_execute_before_validate_stop_reset_status = 1;
  if(SucceedOrFail_stop_reset_status == 0)SucceedOrFail_stop_reset_status = 1;
  global_stop_or_reset = true;
}

void M_end(){
  end_no_execute_before_validate();
  end_SucceedOrFail();
}


