
extern void print(char *msg);

void validate_cmd(){
  print("validate_cmd");
}

void custom_validate_cmd(){
  print("custom_cmd");
}

void success_cmd(){
  print("success_cmd");
}

void fail_cmd(){
  print("fail_cmd");
}

