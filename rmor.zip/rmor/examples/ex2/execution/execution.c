
extern void print(char *msg);

int requested = 0;
int processed = 0;

void new_cmd(){
  requested++;
  print("new_cmd");
}

void cancel_cmd(){
  requested--;
  print("cancel_cmd");
}

void execute_cmd(){
  processed++;
  print("execute_cmd");
}

void reject_cmd(){
  processed++;
  print("reject_cmd");
}
