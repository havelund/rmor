
#include <stdio.h>

#define string char*
#define bool int
#define true 1
#define false 0

bool debug = false;

void print(string msg){
  //printf("--- %s\n", msg);
  //if(debug) M_print_monitors();
}
