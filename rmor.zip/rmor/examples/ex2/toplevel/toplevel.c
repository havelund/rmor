
extern void print(char *msg);
void execute_cmd();
void reject_cmd();
void validate_cmd();
void custom_validate_cmd();
void success_cmd();  
void fail_cmd();

void new(){
  new_cmd();
}

void cancel(){
  cancel_cmd();
}

void execute(){
  execute_cmd();
}

void reject(){
  reject_cmd();
}

void validate(){
  validate_cmd();
}

void custom_validate(){
  custom_validate_cmd();
}

void success(){
  success_cmd();  
}

void fail(){
  fail_cmd();
}
