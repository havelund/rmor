#define rand	pan_rand
#if defined(HAS_CODE) && defined(VERBOSE)
	cpu_printf("Pr: %d Tr: %d\n", II, t->forw);
#endif
	switch (t->forw) {
	default: Uerror("bad forward move");
	case 0:	/* if without executable clauses */
		continue;
	case 1: /* generic 'goto' or 'skip' */
		IfNotBlocked
		_m = 3; goto P999;
	case 2: /* generic 'else' */
		IfNotBlocked
		if (trpt->o_pm&1) continue;
		_m = 3; goto P999;

		 /* PROC :init: */
	case 3: /* STATE 1 - line 26 "prog.pml" - [x = 0] (0:0:1 - 1) */
		IfNotBlocked
		reached[3][1] = 1;
		(trpt+1)->bup.oval = now.x;
		now.x = 0;
#ifdef VAR_RANGES
		logval("x", now.x);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 4: /* STATE 2 - line 27 "prog.pml" - [y = 1000] (0:0:1 - 1) */
		IfNotBlocked
		reached[3][2] = 1;
		(trpt+1)->bup.oval = now.y;
		now.y = 1000;
#ifdef VAR_RANGES
		logval("y", now.y);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 5: /* STATE 3 - line 28 "prog.pml" - [(run P())] (0:0:0 - 1) */
		IfNotBlocked
		reached[3][3] = 1;
		if (!(addproc(0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 6: /* STATE 4 - line 29 "prog.pml" - [(run Q())] (0:0:0 - 1) */
		IfNotBlocked
		reached[3][4] = 1;
		if (!(addproc(1)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 7: /* STATE 5 - line 30 "prog.pml" - [(run A())] (0:0:0 - 1) */
		IfNotBlocked
		reached[3][5] = 1;
		if (!(addproc(2)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 8: /* STATE 6 - line 31 "prog.pml" - [-end-] (0:0:0 - 1) */
		IfNotBlocked
		reached[3][6] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC A */
	case 9: /* STATE 1 - line 22 "prog.pml" - [assert((x!=y))] (0:0:0 - 1) */
		IfNotBlocked
		reached[2][1] = 1;
		assert((now.x!=now.y), "(x!=y)", II, tt, t);
		_m = 3; goto P999; /* 0 */
	case 10: /* STATE 2 - line 23 "prog.pml" - [-end-] (0:0:0 - 1) */
		IfNotBlocked
		reached[2][2] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC Q */
	case 11: /* STATE 1 - line 16 "prog.pml" - [((y>0))] (0:0:0 - 1) */
		IfNotBlocked
		reached[1][1] = 1;
		if (!((now.y>0)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 12: /* STATE 2 - line 16 "prog.pml" - [y = (y-1)] (0:0:1 - 1) */
		IfNotBlocked
		reached[1][2] = 1;
		(trpt+1)->bup.oval = now.y;
		now.y = (now.y-1);
#ifdef VAR_RANGES
		logval("y", now.y);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 13: /* STATE 7 - line 19 "prog.pml" - [-end-] (0:0:0 - 1) */
		IfNotBlocked
		reached[1][7] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */

		 /* PROC P */
	case 14: /* STATE 1 - line 9 "prog.pml" - [((x<1000))] (0:0:0 - 1) */
		IfNotBlocked
		reached[0][1] = 1;
		if (!((now.x<1000)))
			continue;
		_m = 3; goto P999; /* 0 */
	case 15: /* STATE 2 - line 9 "prog.pml" - [x = (x+1)] (0:0:1 - 1) */
		IfNotBlocked
		reached[0][2] = 1;
		(trpt+1)->bup.oval = now.x;
		now.x = (now.x+1);
#ifdef VAR_RANGES
		logval("x", now.x);
#endif
		;
		_m = 3; goto P999; /* 0 */
	case 16: /* STATE 7 - line 12 "prog.pml" - [-end-] (0:0:0 - 1) */
		IfNotBlocked
		reached[0][7] = 1;
		if (!delproc(1, II)) continue;
		_m = 3; goto P999; /* 0 */
	case  _T5:	/* np_ */
		if (!((!(trpt->o_pm&4) && !(trpt->tau&128))))
			continue;
		/* else fall through */
	case  _T2:	/* true */
		_m = 3; goto P999;
#undef rand
	}

