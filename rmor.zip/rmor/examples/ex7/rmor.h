
#define check_event 1
#define enter_event 2
#define leave_event 3

void M_init();
void M_print_monitors();
void M_submit(int event);
void M_stop_monitor(char *monitor);
void M_reset_monitor(char *monitor);
void M_stop_all_monitors();
void M_reset_all_monitors();
void M_end();
