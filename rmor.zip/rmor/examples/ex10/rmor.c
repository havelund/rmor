
/***********************/
/* RMOR Generated Code */
/***********************/


/************/
/* Preamble */
/************/

#include <stdlib.h>
#include <stdio.h>
#include "sglib.h"
#include "rmor.h"

#define string char*
#define bool int
#define true 1
#define false 0

#define SAME_STATE(x,y) ((int)(x->state)-(y->state))

#define DEBUG_FLAG 0
#define DEBUG if(DEBUG_FLAG)printf

static void error(string monitor, string state, int kind, bool handled){
  string msg;
  switch(kind){
    case 0 : msg = "error state entered";break;
    case 1 : msg = "next state not exited";break;
    case 2 : msg = "live state active at end";break;
    case 3 : msg = "states exhausted";
  };
  printf("*** %s.%s : %s\n",monitor,state,msg);
}

bool global_stop_or_reset = false;

/**********/
/* Events */
/**********/

struct{
  int kind;
} curr_event;

#define IS(E) (curr_event.kind == E)

static string event_name(){
  switch(curr_event.kind){
    case semgive_event : return "semgive";
    case semtake_event : return "semtake";
    case update_event : return "update";
    default : return "UNKNOWN";
  }
}

/********************************/
/* Automaton for : SemaphoreUse */
/********************************/

struct SemaphoreUse_state{
  struct SemaphoreUse_state *next;
  struct SemaphoreUse_state *previous;
  int state;
};

typedef struct SemaphoreUse_state *SemaphoreUse_instance;

static SemaphoreUse_instance newSemaphoreUse(){
  return (SemaphoreUse_instance)malloc(sizeof(struct SemaphoreUse_state));
}

static void init_SemaphoreUse_state(SemaphoreUse_instance machine,int state){
  machine->state = state;
}

SemaphoreUse_instance SemaphoreUse_freeList = NULL;
SemaphoreUse_instance SemaphoreUse_currList = NULL;
SemaphoreUse_instance SemaphoreUse_nextList = NULL;
int SemaphoreUse_stop_reset_status = 0;

#define ADD_SemaphoreUse(list, machine)\
  SGLIB_DL_LIST_ADD(struct SemaphoreUse_state, list, machine, previous, next);

#define ADD_NEXT_SemaphoreUse(machine)\
  {\
    SemaphoreUse_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct SemaphoreUse_state, SemaphoreUse_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_SemaphoreUse(SemaphoreUse_freeList,machine);\
    }\
  }

#define DELETE_SemaphoreUse(list, machine)\
  SGLIB_DL_LIST_DELETE(struct SemaphoreUse_state, list, machine, previous, next);

#define FREE_SemaphoreUse(machine)\
  DELETE_SemaphoreUse(SemaphoreUse_currList,machine);\
  ADD_SemaphoreUse(SemaphoreUse_freeList,machine)

#define ALLOCATE_SemaphoreUse(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct SemaphoreUse_state, SemaphoreUse_freeList, previous, next, machine);\
  DELETE_SemaphoreUse(SemaphoreUse_freeList, machine);

#define CURR_TO_NEXT_SemaphoreUse(machine)\
  DELETE_SemaphoreUse(SemaphoreUse_currList, machine);\
  ADD_NEXT_SemaphoreUse(machine);

#define FREE_TO_NEXT_SemaphoreUse(state)\
  SemaphoreUse_instance machine;\
  if(SemaphoreUse_freeList != NULL){\
    ALLOCATE_SemaphoreUse(machine);\
    init_SemaphoreUse_state(machine,state);\
    ADD_NEXT_SemaphoreUse(machine);\
  }else{\
    error("SemaphoreUse",SemaphoreUse_state_name(state),3,false);\
  }

#define MAP_ACTIVE_SemaphoreUse(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct SemaphoreUse_state, SemaphoreUse_currList, machine, previous, next, cmd);

static int SemaphoreUse_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct SemaphoreUse_state, SemaphoreUse_freeList, previous, next, result)
  return result;
}

#define SemaphoreUse_Released_state 1
#define SemaphoreUse_Taken_state 2

static string SemaphoreUse_state_name(int state){
  switch(state){
    case SemaphoreUse_Released_state: return "Released";
    case SemaphoreUse_Taken_state: return "Taken";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_SemaphoreUse_states(){
  SemaphoreUse_instance machine;
  printf("\n-- SemaphoreUse --\n");
  MAP_ACTIVE_SemaphoreUse(machine,{
    printf("state = %s\n", SemaphoreUse_state_name(machine->state));
  });
  printf("free : %d\n",SemaphoreUse_freeList_length());
}

static void init_SemaphoreUse(int noOfMachines){
  int i;
  SemaphoreUse_instance r = newSemaphoreUse();
  init_SemaphoreUse_state(r,SemaphoreUse_Released_state);
  if(noOfMachines>0)
    ADD_SemaphoreUse(SemaphoreUse_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newSemaphoreUse();
    ADD_SemaphoreUse(SemaphoreUse_freeList, r);
  }
}

static void stop_reset_SemaphoreUse(){
  SemaphoreUse_instance machine;
  if(SemaphoreUse_stop_reset_status > 0){
    MAP_ACTIVE_SemaphoreUse(machine,{FREE_SemaphoreUse(machine);});
    if(SemaphoreUse_stop_reset_status == 1){
      ALLOCATE_SemaphoreUse(machine);
      init_SemaphoreUse_state(machine,SemaphoreUse_Released_state);
      ADD_SemaphoreUse(SemaphoreUse_currList,machine);
    }
    SemaphoreUse_stop_reset_status = 0;
  };
}

static void next_step_SemaphoreUse(SemaphoreUse_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case SemaphoreUse_Released_state :
      if(IS(semtake_event)){FREE_TO_NEXT_SemaphoreUse(SemaphoreUse_Taken_state);T = true;}
      if(IS(semgive_event)){error("SemaphoreUse","Released",0,false);T = true;K = true;}
      if(IS(update_event)){error("SemaphoreUse","Released",0,false);T = true;K = true;}
      break;
    case SemaphoreUse_Taken_state :
      if(IS(semgive_event)){FREE_TO_NEXT_SemaphoreUse(SemaphoreUse_Released_state);T = true;}
      if(IS(semtake_event)){error("SemaphoreUse","Taken",0,false);T = true;K = true;}
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_SemaphoreUse(machine);
  }
  else{
    FREE_SemaphoreUse(machine);
  }
}

static void next_SemaphoreUse(){
  if(
    IS(semgive_event)||IS(semtake_event)||IS(update_event)
  ){
    SemaphoreUse_nextList = NULL;
    SemaphoreUse_instance machine;
    MAP_ACTIVE_SemaphoreUse(machine,{next_step_SemaphoreUse(machine);});
    SemaphoreUse_currList = SemaphoreUse_nextList;
  }
}

static void end_SemaphoreUse(){
  SemaphoreUse_instance machine;
  MAP_ACTIVE_SemaphoreUse(machine,{
    if(
       machine->state == SemaphoreUse_Taken_state
    ){
      error("SemaphoreUse",SemaphoreUse_state_name(machine->state),2,false);
    }
  });
}

/*********************************/
/* Automaton for : SemaphoreUse2 */
/*********************************/

struct SemaphoreUse2_state{
  struct SemaphoreUse2_state *next;
  struct SemaphoreUse2_state *previous;
  int state;
};

typedef struct SemaphoreUse2_state *SemaphoreUse2_instance;

static SemaphoreUse2_instance newSemaphoreUse2(){
  return (SemaphoreUse2_instance)malloc(sizeof(struct SemaphoreUse2_state));
}

static void init_SemaphoreUse2_state(SemaphoreUse2_instance machine,int state){
  machine->state = state;
}

SemaphoreUse2_instance SemaphoreUse2_freeList = NULL;
SemaphoreUse2_instance SemaphoreUse2_currList = NULL;
SemaphoreUse2_instance SemaphoreUse2_nextList = NULL;
int SemaphoreUse2_stop_reset_status = 0;

#define ADD_SemaphoreUse2(list, machine)\
  SGLIB_DL_LIST_ADD(struct SemaphoreUse2_state, list, machine, previous, next);

#define ADD_NEXT_SemaphoreUse2(machine)\
  {\
    SemaphoreUse2_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct SemaphoreUse2_state, SemaphoreUse2_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_SemaphoreUse2(SemaphoreUse2_freeList,machine);\
    }\
  }

#define DELETE_SemaphoreUse2(list, machine)\
  SGLIB_DL_LIST_DELETE(struct SemaphoreUse2_state, list, machine, previous, next);

#define FREE_SemaphoreUse2(machine)\
  DELETE_SemaphoreUse2(SemaphoreUse2_currList,machine);\
  ADD_SemaphoreUse2(SemaphoreUse2_freeList,machine)

#define ALLOCATE_SemaphoreUse2(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct SemaphoreUse2_state, SemaphoreUse2_freeList, previous, next, machine);\
  DELETE_SemaphoreUse2(SemaphoreUse2_freeList, machine);

#define CURR_TO_NEXT_SemaphoreUse2(machine)\
  DELETE_SemaphoreUse2(SemaphoreUse2_currList, machine);\
  ADD_NEXT_SemaphoreUse2(machine);

#define FREE_TO_NEXT_SemaphoreUse2(state)\
  SemaphoreUse2_instance machine;\
  if(SemaphoreUse2_freeList != NULL){\
    ALLOCATE_SemaphoreUse2(machine);\
    init_SemaphoreUse2_state(machine,state);\
    ADD_NEXT_SemaphoreUse2(machine);\
  }else{\
    error("SemaphoreUse2",SemaphoreUse2_state_name(state),3,false);\
  }

#define MAP_ACTIVE_SemaphoreUse2(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct SemaphoreUse2_state, SemaphoreUse2_currList, machine, previous, next, cmd);

static int SemaphoreUse2_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct SemaphoreUse2_state, SemaphoreUse2_freeList, previous, next, result)
  return result;
}

#define SemaphoreUse2_A_state 1
#define SemaphoreUse2_B_state 2

static string SemaphoreUse2_state_name(int state){
  switch(state){
    case SemaphoreUse2_A_state: return "A";
    case SemaphoreUse2_B_state: return "B";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_SemaphoreUse2_states(){
  SemaphoreUse2_instance machine;
  printf("\n-- SemaphoreUse2 --\n");
  MAP_ACTIVE_SemaphoreUse2(machine,{
    printf("state = %s\n", SemaphoreUse2_state_name(machine->state));
  });
  printf("free : %d\n",SemaphoreUse2_freeList_length());
}

static void init_SemaphoreUse2(int noOfMachines){
  int i;
  SemaphoreUse2_instance r = newSemaphoreUse2();
  init_SemaphoreUse2_state(r,SemaphoreUse2_A_state);
  if(noOfMachines>0)
    ADD_SemaphoreUse2(SemaphoreUse2_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newSemaphoreUse2();
    ADD_SemaphoreUse2(SemaphoreUse2_freeList, r);
  }
}

static void stop_reset_SemaphoreUse2(){
  SemaphoreUse2_instance machine;
  if(SemaphoreUse2_stop_reset_status > 0){
    MAP_ACTIVE_SemaphoreUse2(machine,{FREE_SemaphoreUse2(machine);});
    if(SemaphoreUse2_stop_reset_status == 1){
      ALLOCATE_SemaphoreUse2(machine);
      init_SemaphoreUse2_state(machine,SemaphoreUse2_A_state);
      ADD_SemaphoreUse2(SemaphoreUse2_currList,machine);
    }
    SemaphoreUse2_stop_reset_status = 0;
  };
}

static void next_step_SemaphoreUse2(SemaphoreUse2_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case SemaphoreUse2_A_state :
      if(IS(semtake_event)){FREE_TO_NEXT_SemaphoreUse2(SemaphoreUse2_B_state);T = true;}
      if(IS(semgive_event)){error("SemaphoreUse2","A",0,false);T = true;K = true;}
      if(IS(update_event)){error("SemaphoreUse2","A",0,false);T = true;K = true;}
      break;
    case SemaphoreUse2_B_state :
      if(IS(semgive_event)){FREE_TO_NEXT_SemaphoreUse2(SemaphoreUse2_A_state);T = true;}
      if(IS(semtake_event)){error("SemaphoreUse2","B",0,false);T = true;K = true;}
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_SemaphoreUse2(machine);
  }
  else{
    FREE_SemaphoreUse2(machine);
  }
}

static void next_SemaphoreUse2(){
  if(
    IS(semgive_event)||IS(semtake_event)||IS(update_event)
  ){
    SemaphoreUse2_nextList = NULL;
    SemaphoreUse2_instance machine;
    MAP_ACTIVE_SemaphoreUse2(machine,{next_step_SemaphoreUse2(machine);});
    SemaphoreUse2_currList = SemaphoreUse2_nextList;
  }
}

static void end_SemaphoreUse2(){
  SemaphoreUse2_instance machine;
  MAP_ACTIVE_SemaphoreUse2(machine,{
    if(
       machine->state == SemaphoreUse2_B_state
    ){
      error("SemaphoreUse2",SemaphoreUse2_state_name(machine->state),2,false);
    }
  });
}

/*********************************/
/* Automaton for : SemaphoreUse3 */
/*********************************/

struct SemaphoreUse3_state{
  struct SemaphoreUse3_state *next;
  struct SemaphoreUse3_state *previous;
  int state;
};

typedef struct SemaphoreUse3_state *SemaphoreUse3_instance;

static SemaphoreUse3_instance newSemaphoreUse3(){
  return (SemaphoreUse3_instance)malloc(sizeof(struct SemaphoreUse3_state));
}

static void init_SemaphoreUse3_state(SemaphoreUse3_instance machine,int state){
  machine->state = state;
}

SemaphoreUse3_instance SemaphoreUse3_freeList = NULL;
SemaphoreUse3_instance SemaphoreUse3_currList = NULL;
SemaphoreUse3_instance SemaphoreUse3_nextList = NULL;
int SemaphoreUse3_stop_reset_status = 0;

#define ADD_SemaphoreUse3(list, machine)\
  SGLIB_DL_LIST_ADD(struct SemaphoreUse3_state, list, machine, previous, next);

#define ADD_NEXT_SemaphoreUse3(machine)\
  {\
    SemaphoreUse3_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct SemaphoreUse3_state, SemaphoreUse3_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_SemaphoreUse3(SemaphoreUse3_freeList,machine);\
    }\
  }

#define DELETE_SemaphoreUse3(list, machine)\
  SGLIB_DL_LIST_DELETE(struct SemaphoreUse3_state, list, machine, previous, next);

#define FREE_SemaphoreUse3(machine)\
  DELETE_SemaphoreUse3(SemaphoreUse3_currList,machine);\
  ADD_SemaphoreUse3(SemaphoreUse3_freeList,machine)

#define ALLOCATE_SemaphoreUse3(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct SemaphoreUse3_state, SemaphoreUse3_freeList, previous, next, machine);\
  DELETE_SemaphoreUse3(SemaphoreUse3_freeList, machine);

#define CURR_TO_NEXT_SemaphoreUse3(machine)\
  DELETE_SemaphoreUse3(SemaphoreUse3_currList, machine);\
  ADD_NEXT_SemaphoreUse3(machine);

#define FREE_TO_NEXT_SemaphoreUse3(state)\
  SemaphoreUse3_instance machine;\
  if(SemaphoreUse3_freeList != NULL){\
    ALLOCATE_SemaphoreUse3(machine);\
    init_SemaphoreUse3_state(machine,state);\
    ADD_NEXT_SemaphoreUse3(machine);\
  }else{\
    error("SemaphoreUse3",SemaphoreUse3_state_name(state),3,false);\
  }

#define MAP_ACTIVE_SemaphoreUse3(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct SemaphoreUse3_state, SemaphoreUse3_currList, machine, previous, next, cmd);

static int SemaphoreUse3_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct SemaphoreUse3_state, SemaphoreUse3_freeList, previous, next, result)
  return result;
}

#define SemaphoreUse3_A_state 1
#define SemaphoreUse3_B_state 2

static string SemaphoreUse3_state_name(int state){
  switch(state){
    case SemaphoreUse3_A_state: return "A";
    case SemaphoreUse3_B_state: return "B";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_SemaphoreUse3_states(){
  SemaphoreUse3_instance machine;
  printf("\n-- SemaphoreUse3 --\n");
  MAP_ACTIVE_SemaphoreUse3(machine,{
    printf("state = %s\n", SemaphoreUse3_state_name(machine->state));
  });
  printf("free : %d\n",SemaphoreUse3_freeList_length());
}

static void init_SemaphoreUse3(int noOfMachines){
  int i;
  SemaphoreUse3_instance r = newSemaphoreUse3();
  init_SemaphoreUse3_state(r,SemaphoreUse3_A_state);
  if(noOfMachines>0)
    ADD_SemaphoreUse3(SemaphoreUse3_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newSemaphoreUse3();
    ADD_SemaphoreUse3(SemaphoreUse3_freeList, r);
  }
}

static void stop_reset_SemaphoreUse3(){
  SemaphoreUse3_instance machine;
  if(SemaphoreUse3_stop_reset_status > 0){
    MAP_ACTIVE_SemaphoreUse3(machine,{FREE_SemaphoreUse3(machine);});
    if(SemaphoreUse3_stop_reset_status == 1){
      ALLOCATE_SemaphoreUse3(machine);
      init_SemaphoreUse3_state(machine,SemaphoreUse3_A_state);
      ADD_SemaphoreUse3(SemaphoreUse3_currList,machine);
    }
    SemaphoreUse3_stop_reset_status = 0;
  };
}

static void next_step_SemaphoreUse3(SemaphoreUse3_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case SemaphoreUse3_A_state :
      if(IS(semtake_event)){FREE_TO_NEXT_SemaphoreUse3(SemaphoreUse3_B_state);T = true;}
      if(IS(semgive_event)){error("SemaphoreUse3","A",0,false);T = true;K = true;}
      if(IS(update_event)){error("SemaphoreUse3","A",0,false);T = true;K = true;}
      break;
    case SemaphoreUse3_B_state :
      if(IS(semgive_event)){FREE_TO_NEXT_SemaphoreUse3(SemaphoreUse3_A_state);T = true;}
      if(IS(semtake_event)){error("SemaphoreUse3","B",0,false);T = true;K = true;}
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_SemaphoreUse3(machine);
  }
  else{
    FREE_SemaphoreUse3(machine);
  }
}

static void next_SemaphoreUse3(){
  if(
    IS(semgive_event)||IS(semtake_event)||IS(update_event)
  ){
    SemaphoreUse3_nextList = NULL;
    SemaphoreUse3_instance machine;
    MAP_ACTIVE_SemaphoreUse3(machine,{next_step_SemaphoreUse3(machine);});
    SemaphoreUse3_currList = SemaphoreUse3_nextList;
  }
}

static void end_SemaphoreUse3(){
  SemaphoreUse3_instance machine;
  MAP_ACTIVE_SemaphoreUse3(machine,{
    if(
       machine->state == SemaphoreUse3_B_state
    ){
      error("SemaphoreUse3",SemaphoreUse3_state_name(machine->state),2,false);
    }
  });
}

/*********************************/
/* Automaton for : SemaphoreUse4 */
/*********************************/

struct SemaphoreUse4_state{
  struct SemaphoreUse4_state *next;
  struct SemaphoreUse4_state *previous;
  int state;
};

typedef struct SemaphoreUse4_state *SemaphoreUse4_instance;

static SemaphoreUse4_instance newSemaphoreUse4(){
  return (SemaphoreUse4_instance)malloc(sizeof(struct SemaphoreUse4_state));
}

static void init_SemaphoreUse4_state(SemaphoreUse4_instance machine,int state){
  machine->state = state;
}

SemaphoreUse4_instance SemaphoreUse4_freeList = NULL;
SemaphoreUse4_instance SemaphoreUse4_currList = NULL;
SemaphoreUse4_instance SemaphoreUse4_nextList = NULL;
int SemaphoreUse4_stop_reset_status = 0;

#define ADD_SemaphoreUse4(list, machine)\
  SGLIB_DL_LIST_ADD(struct SemaphoreUse4_state, list, machine, previous, next);

#define ADD_NEXT_SemaphoreUse4(machine)\
  {\
    SemaphoreUse4_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct SemaphoreUse4_state, SemaphoreUse4_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_SemaphoreUse4(SemaphoreUse4_freeList,machine);\
    }\
  }

#define DELETE_SemaphoreUse4(list, machine)\
  SGLIB_DL_LIST_DELETE(struct SemaphoreUse4_state, list, machine, previous, next);

#define FREE_SemaphoreUse4(machine)\
  DELETE_SemaphoreUse4(SemaphoreUse4_currList,machine);\
  ADD_SemaphoreUse4(SemaphoreUse4_freeList,machine)

#define ALLOCATE_SemaphoreUse4(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct SemaphoreUse4_state, SemaphoreUse4_freeList, previous, next, machine);\
  DELETE_SemaphoreUse4(SemaphoreUse4_freeList, machine);

#define CURR_TO_NEXT_SemaphoreUse4(machine)\
  DELETE_SemaphoreUse4(SemaphoreUse4_currList, machine);\
  ADD_NEXT_SemaphoreUse4(machine);

#define FREE_TO_NEXT_SemaphoreUse4(state)\
  SemaphoreUse4_instance machine;\
  if(SemaphoreUse4_freeList != NULL){\
    ALLOCATE_SemaphoreUse4(machine);\
    init_SemaphoreUse4_state(machine,state);\
    ADD_NEXT_SemaphoreUse4(machine);\
  }else{\
    error("SemaphoreUse4",SemaphoreUse4_state_name(state),3,false);\
  }

#define MAP_ACTIVE_SemaphoreUse4(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct SemaphoreUse4_state, SemaphoreUse4_currList, machine, previous, next, cmd);

static int SemaphoreUse4_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct SemaphoreUse4_state, SemaphoreUse4_freeList, previous, next, result)
  return result;
}

#define SemaphoreUse4_A_state 1
#define SemaphoreUse4_B_state 2

static string SemaphoreUse4_state_name(int state){
  switch(state){
    case SemaphoreUse4_A_state: return "A";
    case SemaphoreUse4_B_state: return "B";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_SemaphoreUse4_states(){
  SemaphoreUse4_instance machine;
  printf("\n-- SemaphoreUse4 --\n");
  MAP_ACTIVE_SemaphoreUse4(machine,{
    printf("state = %s\n", SemaphoreUse4_state_name(machine->state));
  });
  printf("free : %d\n",SemaphoreUse4_freeList_length());
}

static void init_SemaphoreUse4(int noOfMachines){
  int i;
  SemaphoreUse4_instance r = newSemaphoreUse4();
  init_SemaphoreUse4_state(r,SemaphoreUse4_A_state);
  if(noOfMachines>0)
    ADD_SemaphoreUse4(SemaphoreUse4_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newSemaphoreUse4();
    ADD_SemaphoreUse4(SemaphoreUse4_freeList, r);
  }
}

static void stop_reset_SemaphoreUse4(){
  SemaphoreUse4_instance machine;
  if(SemaphoreUse4_stop_reset_status > 0){
    MAP_ACTIVE_SemaphoreUse4(machine,{FREE_SemaphoreUse4(machine);});
    if(SemaphoreUse4_stop_reset_status == 1){
      ALLOCATE_SemaphoreUse4(machine);
      init_SemaphoreUse4_state(machine,SemaphoreUse4_A_state);
      ADD_SemaphoreUse4(SemaphoreUse4_currList,machine);
    }
    SemaphoreUse4_stop_reset_status = 0;
  };
}

static void next_step_SemaphoreUse4(SemaphoreUse4_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case SemaphoreUse4_A_state :
      if(IS(semtake_event)){FREE_TO_NEXT_SemaphoreUse4(SemaphoreUse4_B_state);T = true;}
      if(IS(semgive_event)){error("SemaphoreUse4","A",0,false);T = true;K = true;}
      if(IS(update_event)){error("SemaphoreUse4","A",0,false);T = true;K = true;}
      break;
    case SemaphoreUse4_B_state :
      if(IS(semgive_event)){FREE_TO_NEXT_SemaphoreUse4(SemaphoreUse4_A_state);T = true;}
      if(IS(semtake_event)){error("SemaphoreUse4","B",0,false);T = true;K = true;}
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_SemaphoreUse4(machine);
  }
  else{
    FREE_SemaphoreUse4(machine);
  }
}

static void next_SemaphoreUse4(){
  if(
    IS(semgive_event)||IS(semtake_event)||IS(update_event)
  ){
    SemaphoreUse4_nextList = NULL;
    SemaphoreUse4_instance machine;
    MAP_ACTIVE_SemaphoreUse4(machine,{next_step_SemaphoreUse4(machine);});
    SemaphoreUse4_currList = SemaphoreUse4_nextList;
  }
}

static void end_SemaphoreUse4(){
  SemaphoreUse4_instance machine;
  MAP_ACTIVE_SemaphoreUse4(machine,{
    if(
       machine->state == SemaphoreUse4_B_state
    ){
      error("SemaphoreUse4",SemaphoreUse4_state_name(machine->state),2,false);
    }
  });
}

/*********************************/
/* Automaton for : SemaphoreUse5 */
/*********************************/

struct SemaphoreUse5_state{
  struct SemaphoreUse5_state *next;
  struct SemaphoreUse5_state *previous;
  int state;
};

typedef struct SemaphoreUse5_state *SemaphoreUse5_instance;

static SemaphoreUse5_instance newSemaphoreUse5(){
  return (SemaphoreUse5_instance)malloc(sizeof(struct SemaphoreUse5_state));
}

static void init_SemaphoreUse5_state(SemaphoreUse5_instance machine,int state){
  machine->state = state;
}

SemaphoreUse5_instance SemaphoreUse5_freeList = NULL;
SemaphoreUse5_instance SemaphoreUse5_currList = NULL;
SemaphoreUse5_instance SemaphoreUse5_nextList = NULL;
int SemaphoreUse5_stop_reset_status = 0;

#define ADD_SemaphoreUse5(list, machine)\
  SGLIB_DL_LIST_ADD(struct SemaphoreUse5_state, list, machine, previous, next);

#define ADD_NEXT_SemaphoreUse5(machine)\
  {\
    SemaphoreUse5_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct SemaphoreUse5_state, SemaphoreUse5_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_SemaphoreUse5(SemaphoreUse5_freeList,machine);\
    }\
  }

#define DELETE_SemaphoreUse5(list, machine)\
  SGLIB_DL_LIST_DELETE(struct SemaphoreUse5_state, list, machine, previous, next);

#define FREE_SemaphoreUse5(machine)\
  DELETE_SemaphoreUse5(SemaphoreUse5_currList,machine);\
  ADD_SemaphoreUse5(SemaphoreUse5_freeList,machine)

#define ALLOCATE_SemaphoreUse5(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct SemaphoreUse5_state, SemaphoreUse5_freeList, previous, next, machine);\
  DELETE_SemaphoreUse5(SemaphoreUse5_freeList, machine);

#define CURR_TO_NEXT_SemaphoreUse5(machine)\
  DELETE_SemaphoreUse5(SemaphoreUse5_currList, machine);\
  ADD_NEXT_SemaphoreUse5(machine);

#define FREE_TO_NEXT_SemaphoreUse5(state)\
  SemaphoreUse5_instance machine;\
  if(SemaphoreUse5_freeList != NULL){\
    ALLOCATE_SemaphoreUse5(machine);\
    init_SemaphoreUse5_state(machine,state);\
    ADD_NEXT_SemaphoreUse5(machine);\
  }else{\
    error("SemaphoreUse5",SemaphoreUse5_state_name(state),3,false);\
  }

#define MAP_ACTIVE_SemaphoreUse5(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct SemaphoreUse5_state, SemaphoreUse5_currList, machine, previous, next, cmd);

static int SemaphoreUse5_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct SemaphoreUse5_state, SemaphoreUse5_freeList, previous, next, result)
  return result;
}

#define SemaphoreUse5_A_state 1
#define SemaphoreUse5_B_state 2

static string SemaphoreUse5_state_name(int state){
  switch(state){
    case SemaphoreUse5_A_state: return "A";
    case SemaphoreUse5_B_state: return "B";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_SemaphoreUse5_states(){
  SemaphoreUse5_instance machine;
  printf("\n-- SemaphoreUse5 --\n");
  MAP_ACTIVE_SemaphoreUse5(machine,{
    printf("state = %s\n", SemaphoreUse5_state_name(machine->state));
  });
  printf("free : %d\n",SemaphoreUse5_freeList_length());
}

static void init_SemaphoreUse5(int noOfMachines){
  int i;
  SemaphoreUse5_instance r = newSemaphoreUse5();
  init_SemaphoreUse5_state(r,SemaphoreUse5_A_state);
  if(noOfMachines>0)
    ADD_SemaphoreUse5(SemaphoreUse5_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newSemaphoreUse5();
    ADD_SemaphoreUse5(SemaphoreUse5_freeList, r);
  }
}

static void stop_reset_SemaphoreUse5(){
  SemaphoreUse5_instance machine;
  if(SemaphoreUse5_stop_reset_status > 0){
    MAP_ACTIVE_SemaphoreUse5(machine,{FREE_SemaphoreUse5(machine);});
    if(SemaphoreUse5_stop_reset_status == 1){
      ALLOCATE_SemaphoreUse5(machine);
      init_SemaphoreUse5_state(machine,SemaphoreUse5_A_state);
      ADD_SemaphoreUse5(SemaphoreUse5_currList,machine);
    }
    SemaphoreUse5_stop_reset_status = 0;
  };
}

static void next_step_SemaphoreUse5(SemaphoreUse5_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case SemaphoreUse5_A_state :
      if(IS(semtake_event)){FREE_TO_NEXT_SemaphoreUse5(SemaphoreUse5_B_state);T = true;}
      if(IS(semgive_event)){error("SemaphoreUse5","A",0,false);T = true;K = true;}
      if(IS(update_event)){error("SemaphoreUse5","A",0,false);T = true;K = true;}
      break;
    case SemaphoreUse5_B_state :
      if(IS(semgive_event)){FREE_TO_NEXT_SemaphoreUse5(SemaphoreUse5_A_state);T = true;}
      if(IS(semtake_event)){error("SemaphoreUse5","B",0,false);T = true;K = true;}
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_SemaphoreUse5(machine);
  }
  else{
    FREE_SemaphoreUse5(machine);
  }
}

static void next_SemaphoreUse5(){
  if(
    IS(semgive_event)||IS(semtake_event)||IS(update_event)
  ){
    SemaphoreUse5_nextList = NULL;
    SemaphoreUse5_instance machine;
    MAP_ACTIVE_SemaphoreUse5(machine,{next_step_SemaphoreUse5(machine);});
    SemaphoreUse5_currList = SemaphoreUse5_nextList;
  }
}

static void end_SemaphoreUse5(){
  SemaphoreUse5_instance machine;
  MAP_ACTIVE_SemaphoreUse5(machine,{
    if(
       machine->state == SemaphoreUse5_B_state
    ){
      error("SemaphoreUse5",SemaphoreUse5_state_name(machine->state),2,false);
    }
  });
}

/*********************************/
/* Automaton for : SemaphoreUse6 */
/*********************************/

struct SemaphoreUse6_state{
  struct SemaphoreUse6_state *next;
  struct SemaphoreUse6_state *previous;
  int state;
};

typedef struct SemaphoreUse6_state *SemaphoreUse6_instance;

static SemaphoreUse6_instance newSemaphoreUse6(){
  return (SemaphoreUse6_instance)malloc(sizeof(struct SemaphoreUse6_state));
}

static void init_SemaphoreUse6_state(SemaphoreUse6_instance machine,int state){
  machine->state = state;
}

SemaphoreUse6_instance SemaphoreUse6_freeList = NULL;
SemaphoreUse6_instance SemaphoreUse6_currList = NULL;
SemaphoreUse6_instance SemaphoreUse6_nextList = NULL;
int SemaphoreUse6_stop_reset_status = 0;

#define ADD_SemaphoreUse6(list, machine)\
  SGLIB_DL_LIST_ADD(struct SemaphoreUse6_state, list, machine, previous, next);

#define ADD_NEXT_SemaphoreUse6(machine)\
  {\
    SemaphoreUse6_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct SemaphoreUse6_state, SemaphoreUse6_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_SemaphoreUse6(SemaphoreUse6_freeList,machine);\
    }\
  }

#define DELETE_SemaphoreUse6(list, machine)\
  SGLIB_DL_LIST_DELETE(struct SemaphoreUse6_state, list, machine, previous, next);

#define FREE_SemaphoreUse6(machine)\
  DELETE_SemaphoreUse6(SemaphoreUse6_currList,machine);\
  ADD_SemaphoreUse6(SemaphoreUse6_freeList,machine)

#define ALLOCATE_SemaphoreUse6(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct SemaphoreUse6_state, SemaphoreUse6_freeList, previous, next, machine);\
  DELETE_SemaphoreUse6(SemaphoreUse6_freeList, machine);

#define CURR_TO_NEXT_SemaphoreUse6(machine)\
  DELETE_SemaphoreUse6(SemaphoreUse6_currList, machine);\
  ADD_NEXT_SemaphoreUse6(machine);

#define FREE_TO_NEXT_SemaphoreUse6(state)\
  SemaphoreUse6_instance machine;\
  if(SemaphoreUse6_freeList != NULL){\
    ALLOCATE_SemaphoreUse6(machine);\
    init_SemaphoreUse6_state(machine,state);\
    ADD_NEXT_SemaphoreUse6(machine);\
  }else{\
    error("SemaphoreUse6",SemaphoreUse6_state_name(state),3,false);\
  }

#define MAP_ACTIVE_SemaphoreUse6(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct SemaphoreUse6_state, SemaphoreUse6_currList, machine, previous, next, cmd);

static int SemaphoreUse6_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct SemaphoreUse6_state, SemaphoreUse6_freeList, previous, next, result)
  return result;
}

#define SemaphoreUse6_A_state 1
#define SemaphoreUse6_B_state 2

static string SemaphoreUse6_state_name(int state){
  switch(state){
    case SemaphoreUse6_A_state: return "A";
    case SemaphoreUse6_B_state: return "B";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_SemaphoreUse6_states(){
  SemaphoreUse6_instance machine;
  printf("\n-- SemaphoreUse6 --\n");
  MAP_ACTIVE_SemaphoreUse6(machine,{
    printf("state = %s\n", SemaphoreUse6_state_name(machine->state));
  });
  printf("free : %d\n",SemaphoreUse6_freeList_length());
}

static void init_SemaphoreUse6(int noOfMachines){
  int i;
  SemaphoreUse6_instance r = newSemaphoreUse6();
  init_SemaphoreUse6_state(r,SemaphoreUse6_A_state);
  if(noOfMachines>0)
    ADD_SemaphoreUse6(SemaphoreUse6_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newSemaphoreUse6();
    ADD_SemaphoreUse6(SemaphoreUse6_freeList, r);
  }
}

static void stop_reset_SemaphoreUse6(){
  SemaphoreUse6_instance machine;
  if(SemaphoreUse6_stop_reset_status > 0){
    MAP_ACTIVE_SemaphoreUse6(machine,{FREE_SemaphoreUse6(machine);});
    if(SemaphoreUse6_stop_reset_status == 1){
      ALLOCATE_SemaphoreUse6(machine);
      init_SemaphoreUse6_state(machine,SemaphoreUse6_A_state);
      ADD_SemaphoreUse6(SemaphoreUse6_currList,machine);
    }
    SemaphoreUse6_stop_reset_status = 0;
  };
}

static void next_step_SemaphoreUse6(SemaphoreUse6_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case SemaphoreUse6_A_state :
      if(IS(semtake_event)){FREE_TO_NEXT_SemaphoreUse6(SemaphoreUse6_B_state);T = true;}
      if(IS(semgive_event)){error("SemaphoreUse6","A",0,false);T = true;K = true;}
      if(IS(update_event)){error("SemaphoreUse6","A",0,false);T = true;K = true;}
      break;
    case SemaphoreUse6_B_state :
      if(IS(semgive_event)){FREE_TO_NEXT_SemaphoreUse6(SemaphoreUse6_A_state);T = true;}
      if(IS(semtake_event)){error("SemaphoreUse6","B",0,false);T = true;K = true;}
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_SemaphoreUse6(machine);
  }
  else{
    FREE_SemaphoreUse6(machine);
  }
}

static void next_SemaphoreUse6(){
  if(
    IS(semgive_event)||IS(semtake_event)||IS(update_event)
  ){
    SemaphoreUse6_nextList = NULL;
    SemaphoreUse6_instance machine;
    MAP_ACTIVE_SemaphoreUse6(machine,{next_step_SemaphoreUse6(machine);});
    SemaphoreUse6_currList = SemaphoreUse6_nextList;
  }
}

static void end_SemaphoreUse6(){
  SemaphoreUse6_instance machine;
  MAP_ACTIVE_SemaphoreUse6(machine,{
    if(
       machine->state == SemaphoreUse6_B_state
    ){
      error("SemaphoreUse6",SemaphoreUse6_state_name(machine->state),2,false);
    }
  });
}

/*********************************/
/* Automaton for : SemaphoreUse7 */
/*********************************/

struct SemaphoreUse7_state{
  struct SemaphoreUse7_state *next;
  struct SemaphoreUse7_state *previous;
  int state;
};

typedef struct SemaphoreUse7_state *SemaphoreUse7_instance;

static SemaphoreUse7_instance newSemaphoreUse7(){
  return (SemaphoreUse7_instance)malloc(sizeof(struct SemaphoreUse7_state));
}

static void init_SemaphoreUse7_state(SemaphoreUse7_instance machine,int state){
  machine->state = state;
}

SemaphoreUse7_instance SemaphoreUse7_freeList = NULL;
SemaphoreUse7_instance SemaphoreUse7_currList = NULL;
SemaphoreUse7_instance SemaphoreUse7_nextList = NULL;
int SemaphoreUse7_stop_reset_status = 0;

#define ADD_SemaphoreUse7(list, machine)\
  SGLIB_DL_LIST_ADD(struct SemaphoreUse7_state, list, machine, previous, next);

#define ADD_NEXT_SemaphoreUse7(machine)\
  {\
    SemaphoreUse7_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct SemaphoreUse7_state, SemaphoreUse7_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_SemaphoreUse7(SemaphoreUse7_freeList,machine);\
    }\
  }

#define DELETE_SemaphoreUse7(list, machine)\
  SGLIB_DL_LIST_DELETE(struct SemaphoreUse7_state, list, machine, previous, next);

#define FREE_SemaphoreUse7(machine)\
  DELETE_SemaphoreUse7(SemaphoreUse7_currList,machine);\
  ADD_SemaphoreUse7(SemaphoreUse7_freeList,machine)

#define ALLOCATE_SemaphoreUse7(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct SemaphoreUse7_state, SemaphoreUse7_freeList, previous, next, machine);\
  DELETE_SemaphoreUse7(SemaphoreUse7_freeList, machine);

#define CURR_TO_NEXT_SemaphoreUse7(machine)\
  DELETE_SemaphoreUse7(SemaphoreUse7_currList, machine);\
  ADD_NEXT_SemaphoreUse7(machine);

#define FREE_TO_NEXT_SemaphoreUse7(state)\
  SemaphoreUse7_instance machine;\
  if(SemaphoreUse7_freeList != NULL){\
    ALLOCATE_SemaphoreUse7(machine);\
    init_SemaphoreUse7_state(machine,state);\
    ADD_NEXT_SemaphoreUse7(machine);\
  }else{\
    error("SemaphoreUse7",SemaphoreUse7_state_name(state),3,false);\
  }

#define MAP_ACTIVE_SemaphoreUse7(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct SemaphoreUse7_state, SemaphoreUse7_currList, machine, previous, next, cmd);

static int SemaphoreUse7_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct SemaphoreUse7_state, SemaphoreUse7_freeList, previous, next, result)
  return result;
}

#define SemaphoreUse7_A_state 1
#define SemaphoreUse7_B_state 2

static string SemaphoreUse7_state_name(int state){
  switch(state){
    case SemaphoreUse7_A_state: return "A";
    case SemaphoreUse7_B_state: return "B";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_SemaphoreUse7_states(){
  SemaphoreUse7_instance machine;
  printf("\n-- SemaphoreUse7 --\n");
  MAP_ACTIVE_SemaphoreUse7(machine,{
    printf("state = %s\n", SemaphoreUse7_state_name(machine->state));
  });
  printf("free : %d\n",SemaphoreUse7_freeList_length());
}

static void init_SemaphoreUse7(int noOfMachines){
  int i;
  SemaphoreUse7_instance r = newSemaphoreUse7();
  init_SemaphoreUse7_state(r,SemaphoreUse7_A_state);
  if(noOfMachines>0)
    ADD_SemaphoreUse7(SemaphoreUse7_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newSemaphoreUse7();
    ADD_SemaphoreUse7(SemaphoreUse7_freeList, r);
  }
}

static void stop_reset_SemaphoreUse7(){
  SemaphoreUse7_instance machine;
  if(SemaphoreUse7_stop_reset_status > 0){
    MAP_ACTIVE_SemaphoreUse7(machine,{FREE_SemaphoreUse7(machine);});
    if(SemaphoreUse7_stop_reset_status == 1){
      ALLOCATE_SemaphoreUse7(machine);
      init_SemaphoreUse7_state(machine,SemaphoreUse7_A_state);
      ADD_SemaphoreUse7(SemaphoreUse7_currList,machine);
    }
    SemaphoreUse7_stop_reset_status = 0;
  };
}

static void next_step_SemaphoreUse7(SemaphoreUse7_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case SemaphoreUse7_A_state :
      if(IS(semtake_event)){FREE_TO_NEXT_SemaphoreUse7(SemaphoreUse7_B_state);T = true;}
      if(IS(semgive_event)){error("SemaphoreUse7","A",0,false);T = true;K = true;}
      if(IS(update_event)){error("SemaphoreUse7","A",0,false);T = true;K = true;}
      break;
    case SemaphoreUse7_B_state :
      if(IS(semgive_event)){FREE_TO_NEXT_SemaphoreUse7(SemaphoreUse7_A_state);T = true;}
      if(IS(semtake_event)){error("SemaphoreUse7","B",0,false);T = true;K = true;}
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_SemaphoreUse7(machine);
  }
  else{
    FREE_SemaphoreUse7(machine);
  }
}

static void next_SemaphoreUse7(){
  if(
    IS(semgive_event)||IS(semtake_event)||IS(update_event)
  ){
    SemaphoreUse7_nextList = NULL;
    SemaphoreUse7_instance machine;
    MAP_ACTIVE_SemaphoreUse7(machine,{next_step_SemaphoreUse7(machine);});
    SemaphoreUse7_currList = SemaphoreUse7_nextList;
  }
}

static void end_SemaphoreUse7(){
  SemaphoreUse7_instance machine;
  MAP_ACTIVE_SemaphoreUse7(machine,{
    if(
       machine->state == SemaphoreUse7_B_state
    ){
      error("SemaphoreUse7",SemaphoreUse7_state_name(machine->state),2,false);
    }
  });
}

/*********************************/
/* Automaton for : SemaphoreUse8 */
/*********************************/

struct SemaphoreUse8_state{
  struct SemaphoreUse8_state *next;
  struct SemaphoreUse8_state *previous;
  int state;
};

typedef struct SemaphoreUse8_state *SemaphoreUse8_instance;

static SemaphoreUse8_instance newSemaphoreUse8(){
  return (SemaphoreUse8_instance)malloc(sizeof(struct SemaphoreUse8_state));
}

static void init_SemaphoreUse8_state(SemaphoreUse8_instance machine,int state){
  machine->state = state;
}

SemaphoreUse8_instance SemaphoreUse8_freeList = NULL;
SemaphoreUse8_instance SemaphoreUse8_currList = NULL;
SemaphoreUse8_instance SemaphoreUse8_nextList = NULL;
int SemaphoreUse8_stop_reset_status = 0;

#define ADD_SemaphoreUse8(list, machine)\
  SGLIB_DL_LIST_ADD(struct SemaphoreUse8_state, list, machine, previous, next);

#define ADD_NEXT_SemaphoreUse8(machine)\
  {\
    SemaphoreUse8_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct SemaphoreUse8_state, SemaphoreUse8_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_SemaphoreUse8(SemaphoreUse8_freeList,machine);\
    }\
  }

#define DELETE_SemaphoreUse8(list, machine)\
  SGLIB_DL_LIST_DELETE(struct SemaphoreUse8_state, list, machine, previous, next);

#define FREE_SemaphoreUse8(machine)\
  DELETE_SemaphoreUse8(SemaphoreUse8_currList,machine);\
  ADD_SemaphoreUse8(SemaphoreUse8_freeList,machine)

#define ALLOCATE_SemaphoreUse8(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct SemaphoreUse8_state, SemaphoreUse8_freeList, previous, next, machine);\
  DELETE_SemaphoreUse8(SemaphoreUse8_freeList, machine);

#define CURR_TO_NEXT_SemaphoreUse8(machine)\
  DELETE_SemaphoreUse8(SemaphoreUse8_currList, machine);\
  ADD_NEXT_SemaphoreUse8(machine);

#define FREE_TO_NEXT_SemaphoreUse8(state)\
  SemaphoreUse8_instance machine;\
  if(SemaphoreUse8_freeList != NULL){\
    ALLOCATE_SemaphoreUse8(machine);\
    init_SemaphoreUse8_state(machine,state);\
    ADD_NEXT_SemaphoreUse8(machine);\
  }else{\
    error("SemaphoreUse8",SemaphoreUse8_state_name(state),3,false);\
  }

#define MAP_ACTIVE_SemaphoreUse8(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct SemaphoreUse8_state, SemaphoreUse8_currList, machine, previous, next, cmd);

static int SemaphoreUse8_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct SemaphoreUse8_state, SemaphoreUse8_freeList, previous, next, result)
  return result;
}

#define SemaphoreUse8_A_state 1
#define SemaphoreUse8_B_state 2

static string SemaphoreUse8_state_name(int state){
  switch(state){
    case SemaphoreUse8_A_state: return "A";
    case SemaphoreUse8_B_state: return "B";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_SemaphoreUse8_states(){
  SemaphoreUse8_instance machine;
  printf("\n-- SemaphoreUse8 --\n");
  MAP_ACTIVE_SemaphoreUse8(machine,{
    printf("state = %s\n", SemaphoreUse8_state_name(machine->state));
  });
  printf("free : %d\n",SemaphoreUse8_freeList_length());
}

static void init_SemaphoreUse8(int noOfMachines){
  int i;
  SemaphoreUse8_instance r = newSemaphoreUse8();
  init_SemaphoreUse8_state(r,SemaphoreUse8_A_state);
  if(noOfMachines>0)
    ADD_SemaphoreUse8(SemaphoreUse8_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newSemaphoreUse8();
    ADD_SemaphoreUse8(SemaphoreUse8_freeList, r);
  }
}

static void stop_reset_SemaphoreUse8(){
  SemaphoreUse8_instance machine;
  if(SemaphoreUse8_stop_reset_status > 0){
    MAP_ACTIVE_SemaphoreUse8(machine,{FREE_SemaphoreUse8(machine);});
    if(SemaphoreUse8_stop_reset_status == 1){
      ALLOCATE_SemaphoreUse8(machine);
      init_SemaphoreUse8_state(machine,SemaphoreUse8_A_state);
      ADD_SemaphoreUse8(SemaphoreUse8_currList,machine);
    }
    SemaphoreUse8_stop_reset_status = 0;
  };
}

static void next_step_SemaphoreUse8(SemaphoreUse8_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case SemaphoreUse8_A_state :
      if(IS(semtake_event)){FREE_TO_NEXT_SemaphoreUse8(SemaphoreUse8_B_state);T = true;}
      if(IS(semgive_event)){error("SemaphoreUse8","A",0,false);T = true;K = true;}
      if(IS(update_event)){error("SemaphoreUse8","A",0,false);T = true;K = true;}
      break;
    case SemaphoreUse8_B_state :
      if(IS(semgive_event)){FREE_TO_NEXT_SemaphoreUse8(SemaphoreUse8_A_state);T = true;}
      if(IS(semtake_event)){error("SemaphoreUse8","B",0,false);T = true;K = true;}
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_SemaphoreUse8(machine);
  }
  else{
    FREE_SemaphoreUse8(machine);
  }
}

static void next_SemaphoreUse8(){
  if(
    IS(semgive_event)||IS(semtake_event)||IS(update_event)
  ){
    SemaphoreUse8_nextList = NULL;
    SemaphoreUse8_instance machine;
    MAP_ACTIVE_SemaphoreUse8(machine,{next_step_SemaphoreUse8(machine);});
    SemaphoreUse8_currList = SemaphoreUse8_nextList;
  }
}

static void end_SemaphoreUse8(){
  SemaphoreUse8_instance machine;
  MAP_ACTIVE_SemaphoreUse8(machine,{
    if(
       machine->state == SemaphoreUse8_B_state
    ){
      error("SemaphoreUse8",SemaphoreUse8_state_name(machine->state),2,false);
    }
  });
}

/*********************************/
/* Automaton for : SemaphoreUse9 */
/*********************************/

struct SemaphoreUse9_state{
  struct SemaphoreUse9_state *next;
  struct SemaphoreUse9_state *previous;
  int state;
};

typedef struct SemaphoreUse9_state *SemaphoreUse9_instance;

static SemaphoreUse9_instance newSemaphoreUse9(){
  return (SemaphoreUse9_instance)malloc(sizeof(struct SemaphoreUse9_state));
}

static void init_SemaphoreUse9_state(SemaphoreUse9_instance machine,int state){
  machine->state = state;
}

SemaphoreUse9_instance SemaphoreUse9_freeList = NULL;
SemaphoreUse9_instance SemaphoreUse9_currList = NULL;
SemaphoreUse9_instance SemaphoreUse9_nextList = NULL;
int SemaphoreUse9_stop_reset_status = 0;

#define ADD_SemaphoreUse9(list, machine)\
  SGLIB_DL_LIST_ADD(struct SemaphoreUse9_state, list, machine, previous, next);

#define ADD_NEXT_SemaphoreUse9(machine)\
  {\
    SemaphoreUse9_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct SemaphoreUse9_state, SemaphoreUse9_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_SemaphoreUse9(SemaphoreUse9_freeList,machine);\
    }\
  }

#define DELETE_SemaphoreUse9(list, machine)\
  SGLIB_DL_LIST_DELETE(struct SemaphoreUse9_state, list, machine, previous, next);

#define FREE_SemaphoreUse9(machine)\
  DELETE_SemaphoreUse9(SemaphoreUse9_currList,machine);\
  ADD_SemaphoreUse9(SemaphoreUse9_freeList,machine)

#define ALLOCATE_SemaphoreUse9(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct SemaphoreUse9_state, SemaphoreUse9_freeList, previous, next, machine);\
  DELETE_SemaphoreUse9(SemaphoreUse9_freeList, machine);

#define CURR_TO_NEXT_SemaphoreUse9(machine)\
  DELETE_SemaphoreUse9(SemaphoreUse9_currList, machine);\
  ADD_NEXT_SemaphoreUse9(machine);

#define FREE_TO_NEXT_SemaphoreUse9(state)\
  SemaphoreUse9_instance machine;\
  if(SemaphoreUse9_freeList != NULL){\
    ALLOCATE_SemaphoreUse9(machine);\
    init_SemaphoreUse9_state(machine,state);\
    ADD_NEXT_SemaphoreUse9(machine);\
  }else{\
    error("SemaphoreUse9",SemaphoreUse9_state_name(state),3,false);\
  }

#define MAP_ACTIVE_SemaphoreUse9(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct SemaphoreUse9_state, SemaphoreUse9_currList, machine, previous, next, cmd);

static int SemaphoreUse9_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct SemaphoreUse9_state, SemaphoreUse9_freeList, previous, next, result)
  return result;
}

#define SemaphoreUse9_A_state 1
#define SemaphoreUse9_B_state 2

static string SemaphoreUse9_state_name(int state){
  switch(state){
    case SemaphoreUse9_A_state: return "A";
    case SemaphoreUse9_B_state: return "B";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_SemaphoreUse9_states(){
  SemaphoreUse9_instance machine;
  printf("\n-- SemaphoreUse9 --\n");
  MAP_ACTIVE_SemaphoreUse9(machine,{
    printf("state = %s\n", SemaphoreUse9_state_name(machine->state));
  });
  printf("free : %d\n",SemaphoreUse9_freeList_length());
}

static void init_SemaphoreUse9(int noOfMachines){
  int i;
  SemaphoreUse9_instance r = newSemaphoreUse9();
  init_SemaphoreUse9_state(r,SemaphoreUse9_A_state);
  if(noOfMachines>0)
    ADD_SemaphoreUse9(SemaphoreUse9_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newSemaphoreUse9();
    ADD_SemaphoreUse9(SemaphoreUse9_freeList, r);
  }
}

static void stop_reset_SemaphoreUse9(){
  SemaphoreUse9_instance machine;
  if(SemaphoreUse9_stop_reset_status > 0){
    MAP_ACTIVE_SemaphoreUse9(machine,{FREE_SemaphoreUse9(machine);});
    if(SemaphoreUse9_stop_reset_status == 1){
      ALLOCATE_SemaphoreUse9(machine);
      init_SemaphoreUse9_state(machine,SemaphoreUse9_A_state);
      ADD_SemaphoreUse9(SemaphoreUse9_currList,machine);
    }
    SemaphoreUse9_stop_reset_status = 0;
  };
}

static void next_step_SemaphoreUse9(SemaphoreUse9_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case SemaphoreUse9_A_state :
      if(IS(semtake_event)){FREE_TO_NEXT_SemaphoreUse9(SemaphoreUse9_B_state);T = true;}
      if(IS(semgive_event)){error("SemaphoreUse9","A",0,false);T = true;K = true;}
      if(IS(update_event)){error("SemaphoreUse9","A",0,false);T = true;K = true;}
      break;
    case SemaphoreUse9_B_state :
      if(IS(semgive_event)){FREE_TO_NEXT_SemaphoreUse9(SemaphoreUse9_A_state);T = true;}
      if(IS(semtake_event)){error("SemaphoreUse9","B",0,false);T = true;K = true;}
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_SemaphoreUse9(machine);
  }
  else{
    FREE_SemaphoreUse9(machine);
  }
}

static void next_SemaphoreUse9(){
  if(
    IS(semgive_event)||IS(semtake_event)||IS(update_event)
  ){
    SemaphoreUse9_nextList = NULL;
    SemaphoreUse9_instance machine;
    MAP_ACTIVE_SemaphoreUse9(machine,{next_step_SemaphoreUse9(machine);});
    SemaphoreUse9_currList = SemaphoreUse9_nextList;
  }
}

static void end_SemaphoreUse9(){
  SemaphoreUse9_instance machine;
  MAP_ACTIVE_SemaphoreUse9(machine,{
    if(
       machine->state == SemaphoreUse9_B_state
    ){
      error("SemaphoreUse9",SemaphoreUse9_state_name(machine->state),2,false);
    }
  });
}

/**********************************/
/* Automaton for : SemaphoreUse10 */
/**********************************/

struct SemaphoreUse10_state{
  struct SemaphoreUse10_state *next;
  struct SemaphoreUse10_state *previous;
  int state;
};

typedef struct SemaphoreUse10_state *SemaphoreUse10_instance;

static SemaphoreUse10_instance newSemaphoreUse10(){
  return (SemaphoreUse10_instance)malloc(sizeof(struct SemaphoreUse10_state));
}

static void init_SemaphoreUse10_state(SemaphoreUse10_instance machine,int state){
  machine->state = state;
}

SemaphoreUse10_instance SemaphoreUse10_freeList = NULL;
SemaphoreUse10_instance SemaphoreUse10_currList = NULL;
SemaphoreUse10_instance SemaphoreUse10_nextList = NULL;
int SemaphoreUse10_stop_reset_status = 0;

#define ADD_SemaphoreUse10(list, machine)\
  SGLIB_DL_LIST_ADD(struct SemaphoreUse10_state, list, machine, previous, next);

#define ADD_NEXT_SemaphoreUse10(machine)\
  {\
    SemaphoreUse10_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct SemaphoreUse10_state, SemaphoreUse10_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_SemaphoreUse10(SemaphoreUse10_freeList,machine);\
    }\
  }

#define DELETE_SemaphoreUse10(list, machine)\
  SGLIB_DL_LIST_DELETE(struct SemaphoreUse10_state, list, machine, previous, next);

#define FREE_SemaphoreUse10(machine)\
  DELETE_SemaphoreUse10(SemaphoreUse10_currList,machine);\
  ADD_SemaphoreUse10(SemaphoreUse10_freeList,machine)

#define ALLOCATE_SemaphoreUse10(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct SemaphoreUse10_state, SemaphoreUse10_freeList, previous, next, machine);\
  DELETE_SemaphoreUse10(SemaphoreUse10_freeList, machine);

#define CURR_TO_NEXT_SemaphoreUse10(machine)\
  DELETE_SemaphoreUse10(SemaphoreUse10_currList, machine);\
  ADD_NEXT_SemaphoreUse10(machine);

#define FREE_TO_NEXT_SemaphoreUse10(state)\
  SemaphoreUse10_instance machine;\
  if(SemaphoreUse10_freeList != NULL){\
    ALLOCATE_SemaphoreUse10(machine);\
    init_SemaphoreUse10_state(machine,state);\
    ADD_NEXT_SemaphoreUse10(machine);\
  }else{\
    error("SemaphoreUse10",SemaphoreUse10_state_name(state),3,false);\
  }

#define MAP_ACTIVE_SemaphoreUse10(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct SemaphoreUse10_state, SemaphoreUse10_currList, machine, previous, next, cmd);

static int SemaphoreUse10_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct SemaphoreUse10_state, SemaphoreUse10_freeList, previous, next, result)
  return result;
}

#define SemaphoreUse10_A_state 1
#define SemaphoreUse10_B_state 2

static string SemaphoreUse10_state_name(int state){
  switch(state){
    case SemaphoreUse10_A_state: return "A";
    case SemaphoreUse10_B_state: return "B";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_SemaphoreUse10_states(){
  SemaphoreUse10_instance machine;
  printf("\n-- SemaphoreUse10 --\n");
  MAP_ACTIVE_SemaphoreUse10(machine,{
    printf("state = %s\n", SemaphoreUse10_state_name(machine->state));
  });
  printf("free : %d\n",SemaphoreUse10_freeList_length());
}

static void init_SemaphoreUse10(int noOfMachines){
  int i;
  SemaphoreUse10_instance r = newSemaphoreUse10();
  init_SemaphoreUse10_state(r,SemaphoreUse10_A_state);
  if(noOfMachines>0)
    ADD_SemaphoreUse10(SemaphoreUse10_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newSemaphoreUse10();
    ADD_SemaphoreUse10(SemaphoreUse10_freeList, r);
  }
}

static void stop_reset_SemaphoreUse10(){
  SemaphoreUse10_instance machine;
  if(SemaphoreUse10_stop_reset_status > 0){
    MAP_ACTIVE_SemaphoreUse10(machine,{FREE_SemaphoreUse10(machine);});
    if(SemaphoreUse10_stop_reset_status == 1){
      ALLOCATE_SemaphoreUse10(machine);
      init_SemaphoreUse10_state(machine,SemaphoreUse10_A_state);
      ADD_SemaphoreUse10(SemaphoreUse10_currList,machine);
    }
    SemaphoreUse10_stop_reset_status = 0;
  };
}

static void next_step_SemaphoreUse10(SemaphoreUse10_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case SemaphoreUse10_A_state :
      if(IS(semtake_event)){FREE_TO_NEXT_SemaphoreUse10(SemaphoreUse10_B_state);T = true;}
      if(IS(semgive_event)){error("SemaphoreUse10","A",0,false);T = true;K = true;}
      if(IS(update_event)){error("SemaphoreUse10","A",0,false);T = true;K = true;}
      break;
    case SemaphoreUse10_B_state :
      if(IS(semgive_event)){FREE_TO_NEXT_SemaphoreUse10(SemaphoreUse10_A_state);T = true;}
      if(IS(semtake_event)){error("SemaphoreUse10","B",0,false);T = true;K = true;}
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_SemaphoreUse10(machine);
  }
  else{
    FREE_SemaphoreUse10(machine);
  }
}

static void next_SemaphoreUse10(){
  if(
    IS(semgive_event)||IS(semtake_event)||IS(update_event)
  ){
    SemaphoreUse10_nextList = NULL;
    SemaphoreUse10_instance machine;
    MAP_ACTIVE_SemaphoreUse10(machine,{next_step_SemaphoreUse10(machine);});
    SemaphoreUse10_currList = SemaphoreUse10_nextList;
  }
}

static void end_SemaphoreUse10(){
  SemaphoreUse10_instance machine;
  MAP_ACTIVE_SemaphoreUse10(machine,{
    if(
       machine->state == SemaphoreUse10_B_state
    ){
      error("SemaphoreUse10",SemaphoreUse10_state_name(machine->state),2,false);
    }
  });
}

/**************************/
/* Private Main Functions */
/**************************/

void stop_reset_monitors(){
  if(global_stop_or_reset){
    stop_reset_SemaphoreUse();
    stop_reset_SemaphoreUse2();
    stop_reset_SemaphoreUse3();
    stop_reset_SemaphoreUse4();
    stop_reset_SemaphoreUse5();
    stop_reset_SemaphoreUse6();
    stop_reset_SemaphoreUse7();
    stop_reset_SemaphoreUse8();
    stop_reset_SemaphoreUse9();
    stop_reset_SemaphoreUse10();
  };
  global_stop_or_reset = false;
}

/*************************/
/* Public Main Functions */
/*************************/

void M_print_monitors(){
  print_SemaphoreUse_states();
  print_SemaphoreUse2_states();
  print_SemaphoreUse3_states();
  print_SemaphoreUse4_states();
  print_SemaphoreUse5_states();
  print_SemaphoreUse6_states();
  print_SemaphoreUse7_states();
  print_SemaphoreUse8_states();
  print_SemaphoreUse9_states();
  print_SemaphoreUse10_states();
}

void M_init(){
  init_SemaphoreUse(10);
  init_SemaphoreUse2(10);
  init_SemaphoreUse3(10);
  init_SemaphoreUse4(10);
  init_SemaphoreUse5(10);
  init_SemaphoreUse6(10);
  init_SemaphoreUse7(10);
  init_SemaphoreUse8(10);
  init_SemaphoreUse9(10);
  init_SemaphoreUse10(10);
  if(DEBUG_FLAG){
    M_print_monitors();
  }
}

void M_submit(int event){
  curr_event.kind = event;
  if(DEBUG_FLAG){
    printf("\n=== [%s]: ========================\n", event_name());
  }
  next_SemaphoreUse();
  next_SemaphoreUse2();
  next_SemaphoreUse3();
  next_SemaphoreUse4();
  next_SemaphoreUse5();
  next_SemaphoreUse6();
  next_SemaphoreUse7();
  next_SemaphoreUse8();
  next_SemaphoreUse9();
  next_SemaphoreUse10();
  stop_reset_monitors();
  if(DEBUG_FLAG){
    M_print_monitors();
  }
}

void M_stop_monitor(string monitor){
  if(monitor == "SemaphoreUse")SemaphoreUse_stop_reset_status = 2;
  else
  if(monitor == "SemaphoreUse2")SemaphoreUse2_stop_reset_status = 2;
  else
  if(monitor == "SemaphoreUse3")SemaphoreUse3_stop_reset_status = 2;
  else
  if(monitor == "SemaphoreUse4")SemaphoreUse4_stop_reset_status = 2;
  else
  if(monitor == "SemaphoreUse5")SemaphoreUse5_stop_reset_status = 2;
  else
  if(monitor == "SemaphoreUse6")SemaphoreUse6_stop_reset_status = 2;
  else
  if(monitor == "SemaphoreUse7")SemaphoreUse7_stop_reset_status = 2;
  else
  if(monitor == "SemaphoreUse8")SemaphoreUse8_stop_reset_status = 2;
  else
  if(monitor == "SemaphoreUse9")SemaphoreUse9_stop_reset_status = 2;
  else
  if(monitor == "SemaphoreUse10")SemaphoreUse10_stop_reset_status = 2;
  global_stop_or_reset = true;
}

void M_reset_monitor(string monitor){
  if(monitor == "SemaphoreUse" && SemaphoreUse_stop_reset_status == 0)SemaphoreUse_stop_reset_status = 1;
  else
  if(monitor == "SemaphoreUse2" && SemaphoreUse2_stop_reset_status == 0)SemaphoreUse2_stop_reset_status = 1;
  else
  if(monitor == "SemaphoreUse3" && SemaphoreUse3_stop_reset_status == 0)SemaphoreUse3_stop_reset_status = 1;
  else
  if(monitor == "SemaphoreUse4" && SemaphoreUse4_stop_reset_status == 0)SemaphoreUse4_stop_reset_status = 1;
  else
  if(monitor == "SemaphoreUse5" && SemaphoreUse5_stop_reset_status == 0)SemaphoreUse5_stop_reset_status = 1;
  else
  if(monitor == "SemaphoreUse6" && SemaphoreUse6_stop_reset_status == 0)SemaphoreUse6_stop_reset_status = 1;
  else
  if(monitor == "SemaphoreUse7" && SemaphoreUse7_stop_reset_status == 0)SemaphoreUse7_stop_reset_status = 1;
  else
  if(monitor == "SemaphoreUse8" && SemaphoreUse8_stop_reset_status == 0)SemaphoreUse8_stop_reset_status = 1;
  else
  if(monitor == "SemaphoreUse9" && SemaphoreUse9_stop_reset_status == 0)SemaphoreUse9_stop_reset_status = 1;
  else
  if(monitor == "SemaphoreUse10" && SemaphoreUse10_stop_reset_status == 0)SemaphoreUse10_stop_reset_status = 1;
  global_stop_or_reset = true;
}

void M_stop_all_monitors(){
  SemaphoreUse_stop_reset_status = 2;
  SemaphoreUse2_stop_reset_status = 2;
  SemaphoreUse3_stop_reset_status = 2;
  SemaphoreUse4_stop_reset_status = 2;
  SemaphoreUse5_stop_reset_status = 2;
  SemaphoreUse6_stop_reset_status = 2;
  SemaphoreUse7_stop_reset_status = 2;
  SemaphoreUse8_stop_reset_status = 2;
  SemaphoreUse9_stop_reset_status = 2;
  SemaphoreUse10_stop_reset_status = 2;
  global_stop_or_reset = true;
}

void M_reset_all_monitors(){
  if(SemaphoreUse_stop_reset_status == 0)SemaphoreUse_stop_reset_status = 1;
  if(SemaphoreUse2_stop_reset_status == 0)SemaphoreUse2_stop_reset_status = 1;
  if(SemaphoreUse3_stop_reset_status == 0)SemaphoreUse3_stop_reset_status = 1;
  if(SemaphoreUse4_stop_reset_status == 0)SemaphoreUse4_stop_reset_status = 1;
  if(SemaphoreUse5_stop_reset_status == 0)SemaphoreUse5_stop_reset_status = 1;
  if(SemaphoreUse6_stop_reset_status == 0)SemaphoreUse6_stop_reset_status = 1;
  if(SemaphoreUse7_stop_reset_status == 0)SemaphoreUse7_stop_reset_status = 1;
  if(SemaphoreUse8_stop_reset_status == 0)SemaphoreUse8_stop_reset_status = 1;
  if(SemaphoreUse9_stop_reset_status == 0)SemaphoreUse9_stop_reset_status = 1;
  if(SemaphoreUse10_stop_reset_status == 0)SemaphoreUse10_stop_reset_status = 1;
  global_stop_or_reset = true;
}

void M_end(){
  end_SemaphoreUse();
  end_SemaphoreUse2();
  end_SemaphoreUse3();
  end_SemaphoreUse4();
  end_SemaphoreUse5();
  end_SemaphoreUse6();
  end_SemaphoreUse7();
  end_SemaphoreUse8();
  end_SemaphoreUse9();
  end_SemaphoreUse10();
}


