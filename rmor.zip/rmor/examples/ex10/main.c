
#define MAX 50000000

#include <stdio.h>
#include <stdlib.h>

void sem_take(int sem){}
void sem_give(int sem){}

int  alloc_page(){return 19;} 
void free_page(int page){}
void update_entry(int page,int pos,int data){}
void update_header(int page,char *header){}

void send_page(int page){}

main() {
  int page;
  int i;
  for(i=0;i<MAX;i++) {
    sem_take(1);
    page = alloc_page(); 
    update_header(page,"status report");
    update_entry(page,1,1);
    update_entry(page,2,0);
    send_page(page);
    free_page(page);
    sem_give(1);
  }
}
