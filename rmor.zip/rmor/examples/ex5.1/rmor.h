
#define ACK_event 1
#define CANCEL_event 2
#define CLOSE_event 3
#define COMMIT_event 4
#define OPEN_event 5
#define UPDATE_event 6
#define WRITE_event 7

void M_init();
void M_print_monitors();
void M_submit(int event);
void M_stop_monitor(char *monitor);
void M_reset_monitor(char *monitor);
void M_stop_all_monitors();
void M_reset_all_monitors();
void M_end();
