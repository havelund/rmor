
#define DELAY  100
#define OPEN   500
#define COMMIT 1000
#define WRITE  200

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define bool int
#define false 0
#define true  1

struct ConnectionStr{
  char* name;
  char* data; // simplified view of a file, not used
};

typedef struct ConnectionStr *Connection;
char* header;

Connection open_connection(char* name) {
  //printf("opening connection %s\n", name);
  Connection connection = (Connection)malloc(sizeof(struct ConnectionStr));
  connection->name = name;
  connection->data = NULL;
  return connection;
}

void delay(int N) {
  int i;
  int count = 0;
  //printf("delay begin\n");
  for(i=0;i<N;i++) {
    count++;
  }
  //printf("delay end\n");
}

bool close_connection(Connection connection) {
  //printf("closing connection %s\n",connection->name);
  return true;
}

void cancel_transmission(Connection connection) {
  //printf("cancelling connection %s\n",connection->name);
}

void write_buffer(Connection connection, int data) {
  //printf("writing buffer of connection %s\n",connection->name);
  delay(DELAY);
}

void commit_buffer(Connection connection) {
  //printf("committing buffer of connection %s\n",connection->name);
}

void acknowledge() {
  //printf("callback acknowledgement\n");
}

void debug(char* str){
  //printf("---> %s\n", str);
}

void handler(char *monitor, char *state, int kind){
  printf("--- HANDLER: monitor=%s state=%s kind=%d\n", monitor, state, kind);
}

main(){
  Connection c;
  int i,j,k;
  for(i=0;i<OPEN;i++) {
    c = open_connection("connection");
    for(j=1;j<COMMIT;j++) {
      for(k=1;k<WRITE;k++) {
	write_buffer(c,k);
      };
      commit_buffer(c);
      acknowledge();
    }
    close_connection(c);
  }
}









