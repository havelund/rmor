
/***********************/
/* RMOR Generated Code */
/***********************/


/************/
/* Preamble */
/************/

#include <stdlib.h>
#include <stdio.h>
#include "sglib.h"
#include "rmor.h"

#define string char*
#define bool int
#define true 1
#define false 0

#define SAME_STATE(x,y) ((int)(x->state)-(y->state))

#define DEBUG_FLAG 0
#define DEBUG if(DEBUG_FLAG)printf

extern void handler(string monitor, string state, int kind);

static void error(string monitor, string state, int kind, bool handled){
  string msg;
  switch(kind){
    case 0 : msg = "error state entered";break;
    case 1 : msg = "next state not exited";break;
    case 2 : msg = "live state active at end";break;
    case 3 : msg = "states exhausted";
  };
  printf("*** %s.%s : %s\n",monitor,state,msg);
  if(handled){handler(monitor,state,kind);}
}

bool global_stop_or_reset = false;

/**********/
/* Events */
/**********/

struct{
  int kind;
} curr_event;

#define IS(E) (curr_event.kind == E)

static string event_name(){
  switch(curr_event.kind){
    case ACK_event : return "ACK";
    case CANCEL_event : return "CANCEL";
    case CLOSE_event : return "CLOSE";
    case COMMIT_event : return "COMMIT";
    case OPEN_event : return "OPEN";
    case UPDATE_event : return "UPDATE";
    case WRITE_event : return "WRITE";
    default : return "UNKNOWN";
  }
}

/**************************************/
/* Automaton for : UplinkRequirements */
/**************************************/

struct UplinkRequirements_state{
  struct UplinkRequirements_state *next;
  struct UplinkRequirements_state *previous;
  int state;
};

typedef struct UplinkRequirements_state *UplinkRequirements_instance;

static UplinkRequirements_instance newUplinkRequirements(){
  return (UplinkRequirements_instance)malloc(sizeof(struct UplinkRequirements_state));
}

static void init_UplinkRequirements_state(UplinkRequirements_instance machine,int state){
  machine->state = state;
}

UplinkRequirements_instance UplinkRequirements_freeList = NULL;
UplinkRequirements_instance UplinkRequirements_currList = NULL;
UplinkRequirements_instance UplinkRequirements_nextList = NULL;
int UplinkRequirements_stop_reset_status = 0;

#define ADD_UplinkRequirements(list, machine)\
  SGLIB_DL_LIST_ADD(struct UplinkRequirements_state, list, machine, previous, next);

#define ADD_NEXT_UplinkRequirements(machine)\
  {\
    UplinkRequirements_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct UplinkRequirements_state, UplinkRequirements_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_UplinkRequirements(UplinkRequirements_freeList,machine);\
    }\
  }

#define DELETE_UplinkRequirements(list, machine)\
  SGLIB_DL_LIST_DELETE(struct UplinkRequirements_state, list, machine, previous, next);

#define FREE_UplinkRequirements(machine)\
  DELETE_UplinkRequirements(UplinkRequirements_currList,machine);\
  ADD_UplinkRequirements(UplinkRequirements_freeList,machine)

#define ALLOCATE_UplinkRequirements(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct UplinkRequirements_state, UplinkRequirements_freeList, previous, next, machine);\
  DELETE_UplinkRequirements(UplinkRequirements_freeList, machine);

#define CURR_TO_NEXT_UplinkRequirements(machine)\
  DELETE_UplinkRequirements(UplinkRequirements_currList, machine);\
  ADD_NEXT_UplinkRequirements(machine);

#define FREE_TO_NEXT_UplinkRequirements(state)\
  UplinkRequirements_instance machine;\
  if(UplinkRequirements_freeList != NULL){\
    ALLOCATE_UplinkRequirements(machine);\
    init_UplinkRequirements_state(machine,state);\
    ADD_NEXT_UplinkRequirements(machine);\
  }else{\
    error("UplinkRequirements",UplinkRequirements_state_name(state),3,true);\
  }

#define MAP_ACTIVE_UplinkRequirements(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct UplinkRequirements_state, UplinkRequirements_currList, machine, previous, next, cmd);

static int UplinkRequirements_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct UplinkRequirements_state, UplinkRequirements_freeList, previous, next, result)
  return result;
}

#define UplinkRequirements_Closed_state 1
#define UplinkRequirements_Opened_state 2
#define UplinkRequirements_Committing_state 3

static string UplinkRequirements_state_name(int state){
  switch(state){
    case UplinkRequirements_Closed_state: return "Closed";
    case UplinkRequirements_Opened_state: return "Opened";
    case UplinkRequirements_Committing_state: return "Committing";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_UplinkRequirements_states(){
  UplinkRequirements_instance machine;
  printf("\n-- UplinkRequirements --\n");
  MAP_ACTIVE_UplinkRequirements(machine,{
    printf("state = %s\n", UplinkRequirements_state_name(machine->state));
  });
  printf("free : %d\n",UplinkRequirements_freeList_length());
}

static void init_UplinkRequirements(int noOfMachines){
  int i;
  UplinkRequirements_instance r = newUplinkRequirements();
  init_UplinkRequirements_state(r,UplinkRequirements_Closed_state);
  if(noOfMachines>0)
    ADD_UplinkRequirements(UplinkRequirements_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newUplinkRequirements();
    ADD_UplinkRequirements(UplinkRequirements_freeList, r);
  }
}

static void stop_reset_UplinkRequirements(){
  UplinkRequirements_instance machine;
  if(UplinkRequirements_stop_reset_status > 0){
    MAP_ACTIVE_UplinkRequirements(machine,{FREE_UplinkRequirements(machine);});
    if(UplinkRequirements_stop_reset_status == 1){
      ALLOCATE_UplinkRequirements(machine);
      init_UplinkRequirements_state(machine,UplinkRequirements_Closed_state);
      ADD_UplinkRequirements(UplinkRequirements_currList,machine);
    }
    UplinkRequirements_stop_reset_status = 0;
  };
}

static void next_step_UplinkRequirements(UplinkRequirements_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case UplinkRequirements_Closed_state :
      if(IS(OPEN_event)){FREE_TO_NEXT_UplinkRequirements(UplinkRequirements_Opened_state);T = true;}
      if((((IS(WRITE_event)||IS(COMMIT_event))||IS(ACK_event))||IS(CLOSE_event))){error("UplinkRequirements","Closed",0,true);T = true;K = true;}
      break;
    case UplinkRequirements_Opened_state :
      if(IS(CANCEL_event)){FREE_TO_NEXT_UplinkRequirements(UplinkRequirements_Closed_state);T = true;}
      if(IS(OPEN_event)){error("UplinkRequirements","Opened",0,true);T = true;K = true;}
      if(IS(COMMIT_event)){FREE_TO_NEXT_UplinkRequirements(UplinkRequirements_Committing_state);T = true;}
      if(IS(CLOSE_event)){FREE_TO_NEXT_UplinkRequirements(UplinkRequirements_Closed_state);T = true;}
      if(IS(ACK_event)){error("UplinkRequirements","Opened",0,true);T = true;K = true;}
      break;
    case UplinkRequirements_Committing_state :
      if(IS(CANCEL_event)){FREE_TO_NEXT_UplinkRequirements(UplinkRequirements_Closed_state);T = true;}
      if(IS(OPEN_event)){error("UplinkRequirements","Committing",0,true);T = true;K = true;}
      if(IS(ACK_event)){FREE_TO_NEXT_UplinkRequirements(UplinkRequirements_Opened_state);T = true;}
      if(T == false){error("UplinkRequirements","Committing",1,true);T = true;};
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_UplinkRequirements(machine);
  }
  else{
    FREE_UplinkRequirements(machine);
  }
}

static void next_UplinkRequirements(){
  if(
    true
  ){
    UplinkRequirements_nextList = NULL;
    UplinkRequirements_instance machine;
    MAP_ACTIVE_UplinkRequirements(machine,{next_step_UplinkRequirements(machine);});
    UplinkRequirements_currList = UplinkRequirements_nextList;
  }
}

static void end_UplinkRequirements(){
  UplinkRequirements_instance machine;
  MAP_ACTIVE_UplinkRequirements(machine,{
    if(
       machine->state == UplinkRequirements_Opened_state
    || machine->state == UplinkRequirements_Committing_state
    ){
      error("UplinkRequirements",UplinkRequirements_state_name(machine->state),2,true);
    }
  });
}

/*********************************/
/* Automaton for : CommitUpdates */
/*********************************/

struct CommitUpdates_state{
  struct CommitUpdates_state *next;
  struct CommitUpdates_state *previous;
  int state;
};

typedef struct CommitUpdates_state *CommitUpdates_instance;

static CommitUpdates_instance newCommitUpdates(){
  return (CommitUpdates_instance)malloc(sizeof(struct CommitUpdates_state));
}

static void init_CommitUpdates_state(CommitUpdates_instance machine,int state){
  machine->state = state;
}

CommitUpdates_instance CommitUpdates_freeList = NULL;
CommitUpdates_instance CommitUpdates_currList = NULL;
CommitUpdates_instance CommitUpdates_nextList = NULL;
int CommitUpdates_stop_reset_status = 0;

#define ADD_CommitUpdates(list, machine)\
  SGLIB_DL_LIST_ADD(struct CommitUpdates_state, list, machine, previous, next);

#define ADD_NEXT_CommitUpdates(machine)\
  {\
    CommitUpdates_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct CommitUpdates_state, CommitUpdates_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_CommitUpdates(CommitUpdates_freeList,machine);\
    }\
  }

#define DELETE_CommitUpdates(list, machine)\
  SGLIB_DL_LIST_DELETE(struct CommitUpdates_state, list, machine, previous, next);

#define FREE_CommitUpdates(machine)\
  DELETE_CommitUpdates(CommitUpdates_currList,machine);\
  ADD_CommitUpdates(CommitUpdates_freeList,machine)

#define ALLOCATE_CommitUpdates(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct CommitUpdates_state, CommitUpdates_freeList, previous, next, machine);\
  DELETE_CommitUpdates(CommitUpdates_freeList, machine);

#define CURR_TO_NEXT_CommitUpdates(machine)\
  DELETE_CommitUpdates(CommitUpdates_currList, machine);\
  ADD_NEXT_CommitUpdates(machine);

#define FREE_TO_NEXT_CommitUpdates(state)\
  CommitUpdates_instance machine;\
  if(CommitUpdates_freeList != NULL){\
    ALLOCATE_CommitUpdates(machine);\
    init_CommitUpdates_state(machine,state);\
    ADD_NEXT_CommitUpdates(machine);\
  }else{\
    error("CommitUpdates",CommitUpdates_state_name(state),3,false);\
  }

#define MAP_ACTIVE_CommitUpdates(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct CommitUpdates_state, CommitUpdates_currList, machine, previous, next, cmd);

static int CommitUpdates_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct CommitUpdates_state, CommitUpdates_freeList, previous, next, result)
  return result;
}

#define CommitUpdates_Start_state 1
#define CommitUpdates_DoCommit_state 2
#define CommitUpdates_Done_state 3

static string CommitUpdates_state_name(int state){
  switch(state){
    case CommitUpdates_Start_state: return "Start";
    case CommitUpdates_DoCommit_state: return "DoCommit";
    case CommitUpdates_Done_state: return "Done";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_CommitUpdates_states(){
  CommitUpdates_instance machine;
  printf("\n-- CommitUpdates --\n");
  MAP_ACTIVE_CommitUpdates(machine,{
    printf("state = %s\n", CommitUpdates_state_name(machine->state));
  });
  printf("free : %d\n",CommitUpdates_freeList_length());
}

static void init_CommitUpdates(int noOfMachines){
  int i;
  CommitUpdates_instance r = newCommitUpdates();
  init_CommitUpdates_state(r,CommitUpdates_Start_state);
  if(noOfMachines>0)
    ADD_CommitUpdates(CommitUpdates_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newCommitUpdates();
    ADD_CommitUpdates(CommitUpdates_freeList, r);
  }
}

static void stop_reset_CommitUpdates(){
  CommitUpdates_instance machine;
  if(CommitUpdates_stop_reset_status > 0){
    MAP_ACTIVE_CommitUpdates(machine,{FREE_CommitUpdates(machine);});
    if(CommitUpdates_stop_reset_status == 1){
      ALLOCATE_CommitUpdates(machine);
      init_CommitUpdates_state(machine,CommitUpdates_Start_state);
      ADD_CommitUpdates(CommitUpdates_currList,machine);
    }
    CommitUpdates_stop_reset_status = 0;
  };
}

static void next_step_CommitUpdates(CommitUpdates_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case CommitUpdates_Start_state :
      if(IS(UPDATE_event)){FREE_TO_NEXT_CommitUpdates(CommitUpdates_DoCommit_state);T = true;K = true;}
      break;
    case CommitUpdates_DoCommit_state :
      if(IS(COMMIT_event)){T = true;}
      if(IS(CANCEL_event)){T = true;}
      if(IS(CLOSE_event)){error("CommitUpdates","DoCommit",0,false);T = true;}
      break;
    case CommitUpdates_Done_state :
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_CommitUpdates(machine);
  }
  else{
    FREE_CommitUpdates(machine);
  }
}

static void next_CommitUpdates(){
  if(
    IS(CANCEL_event)||IS(CLOSE_event)||IS(COMMIT_event)||IS(UPDATE_event)
  ){
    CommitUpdates_nextList = NULL;
    CommitUpdates_instance machine;
    MAP_ACTIVE_CommitUpdates(machine,{next_step_CommitUpdates(machine);});
    CommitUpdates_currList = CommitUpdates_nextList;
  }
}

static void end_CommitUpdates(){
  CommitUpdates_instance machine;
  MAP_ACTIVE_CommitUpdates(machine,{
    if(
       machine->state == CommitUpdates_DoCommit_state
    ){
      error("CommitUpdates",CommitUpdates_state_name(machine->state),2,false);
    }
  });
}

/**************************/
/* Private Main Functions */
/**************************/

void stop_reset_monitors(){
  if(global_stop_or_reset){
    stop_reset_UplinkRequirements();
    stop_reset_CommitUpdates();
  };
  global_stop_or_reset = false;
}

/*************************/
/* Public Main Functions */
/*************************/

void M_print_monitors(){
  print_UplinkRequirements_states();
  print_CommitUpdates_states();
}

void M_init(){
  init_UplinkRequirements(10);
  init_CommitUpdates(10);
  if(DEBUG_FLAG){
    M_print_monitors();
  }
}

void M_submit(int event){
  curr_event.kind = event;
  if(DEBUG_FLAG){
    printf("\n=== [%s]: ========================\n", event_name());
  }
  next_UplinkRequirements();
  next_CommitUpdates();
  stop_reset_monitors();
  if(DEBUG_FLAG){
    M_print_monitors();
  }
}

void M_stop_monitor(string monitor){
  if(monitor == "UplinkRequirements")UplinkRequirements_stop_reset_status = 2;
  else
  if(monitor == "CommitUpdates")CommitUpdates_stop_reset_status = 2;
  global_stop_or_reset = true;
}

void M_reset_monitor(string monitor){
  if(monitor == "UplinkRequirements" && UplinkRequirements_stop_reset_status == 0)UplinkRequirements_stop_reset_status = 1;
  else
  if(monitor == "CommitUpdates" && CommitUpdates_stop_reset_status == 0)CommitUpdates_stop_reset_status = 1;
  global_stop_or_reset = true;
}

void M_stop_all_monitors(){
  UplinkRequirements_stop_reset_status = 2;
  CommitUpdates_stop_reset_status = 2;
  global_stop_or_reset = true;
}

void M_reset_all_monitors(){
  if(UplinkRequirements_stop_reset_status == 0)UplinkRequirements_stop_reset_status = 1;
  if(CommitUpdates_stop_reset_status == 0)CommitUpdates_stop_reset_status = 1;
  global_stop_or_reset = true;
}

void M_end(){
  end_UplinkRequirements();
  end_CommitUpdates();
}


