
/***********************/
/* RMOR Generated Code */
/***********************/


/************/
/* Preamble */
/************/

#include <stdlib.h>
#include <stdio.h>
#include "sglib.h"
#include "rmor.h"

#define string char*
#define bool int
#define true 1
#define false 0

#define SAME_STATE(x,y) ((int)(x->state)-(y->state))

#define DEBUG_FLAG 0
#define DEBUG if(DEBUG_FLAG)printf

static void error(string monitor, string state, int kind, bool handled){
  string msg;
  switch(kind){
    case 0 : msg = "error state entered";break;
    case 1 : msg = "next state not exited";break;
    case 2 : msg = "live state active at end";break;
    case 3 : msg = "states exhausted";
  };
  printf("*** %s.%s : %s\n",monitor,state,msg);
}

bool global_stop_or_reset = false;

/**********/
/* Events */
/**********/

struct{
  int kind;
} curr_event;

#define IS(E) (curr_event.kind == E)

static string event_name(){
  switch(curr_event.kind){
    case close_event : return "close";
    case open_event : return "open";
    case process_event : return "process";
    default : return "UNKNOWN";
  }
}

/******************************/
/* Automaton for : OpenClose1 */
/******************************/

struct OpenClose1_state{
  struct OpenClose1_state *next;
  struct OpenClose1_state *previous;
  int state;
};

typedef struct OpenClose1_state *OpenClose1_instance;

static OpenClose1_instance newOpenClose1(){
  return (OpenClose1_instance)malloc(sizeof(struct OpenClose1_state));
}

static void init_OpenClose1_state(OpenClose1_instance machine,int state){
  machine->state = state;
}

OpenClose1_instance OpenClose1_freeList = NULL;
OpenClose1_instance OpenClose1_currList = NULL;
OpenClose1_instance OpenClose1_nextList = NULL;
int OpenClose1_stop_reset_status = 0;

#define ADD_OpenClose1(list, machine)\
  SGLIB_DL_LIST_ADD(struct OpenClose1_state, list, machine, previous, next);

#define ADD_NEXT_OpenClose1(machine)\
  {\
    OpenClose1_instance result;\
    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct OpenClose1_state, OpenClose1_nextList, machine, SAME_STATE, previous, next, result);\
    if(result != NULL){\
      ADD_OpenClose1(OpenClose1_freeList,machine);\
    }\
  }

#define DELETE_OpenClose1(list, machine)\
  SGLIB_DL_LIST_DELETE(struct OpenClose1_state, list, machine, previous, next);

#define FREE_OpenClose1(machine)\
  DELETE_OpenClose1(OpenClose1_currList,machine);\
  ADD_OpenClose1(OpenClose1_freeList,machine)

#define ALLOCATE_OpenClose1(machine)\
  SGLIB_DL_LIST_GET_FIRST(struct OpenClose1_state, OpenClose1_freeList, previous, next, machine);\
  DELETE_OpenClose1(OpenClose1_freeList, machine);

#define CURR_TO_NEXT_OpenClose1(machine)\
  DELETE_OpenClose1(OpenClose1_currList, machine);\
  ADD_NEXT_OpenClose1(machine);

#define FREE_TO_NEXT_OpenClose1(state)\
  OpenClose1_instance machine;\
  if(OpenClose1_freeList != NULL){\
    ALLOCATE_OpenClose1(machine);\
    init_OpenClose1_state(machine,state);\
    ADD_NEXT_OpenClose1(machine);\
  }else{\
    error("OpenClose1",OpenClose1_state_name(state),3,false);\
  }

#define MAP_ACTIVE_OpenClose1(machine, cmd)\
  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct OpenClose1_state, OpenClose1_currList, machine, previous, next, cmd);

static int OpenClose1_freeList_length(){
  int result;
  SGLIB_DL_LIST_LEN(struct OpenClose1_state, OpenClose1_freeList, previous, next, result)
  return result;
}

#define OpenClose1_FileClosed_state 1
#define OpenClose1_FileOpen_state 2

static string OpenClose1_state_name(int state){
  switch(state){
    case OpenClose1_FileClosed_state: return "FileClosed";
    case OpenClose1_FileOpen_state: return "FileOpen";
    default:
      printf("*** unknown state : %d\n", state);
      exit(1);
  }
}

static void print_OpenClose1_states(){
  OpenClose1_instance machine;
  printf("\n-- OpenClose1 --\n");
  MAP_ACTIVE_OpenClose1(machine,{
    printf("state = %s\n", OpenClose1_state_name(machine->state));
  });
  printf("free : %d\n",OpenClose1_freeList_length());
}

static void init_OpenClose1(int noOfMachines){
  int i;
  OpenClose1_instance r = newOpenClose1();
  init_OpenClose1_state(r,OpenClose1_FileClosed_state);
  if(noOfMachines>0)
    ADD_OpenClose1(OpenClose1_currList,r);
  for(i=1;i<noOfMachines;i++){
    r = newOpenClose1();
    ADD_OpenClose1(OpenClose1_freeList, r);
  }
}

static void stop_reset_OpenClose1(){
  OpenClose1_instance machine;
  if(OpenClose1_stop_reset_status > 0){
    MAP_ACTIVE_OpenClose1(machine,{FREE_OpenClose1(machine);});
    if(OpenClose1_stop_reset_status == 1){
      ALLOCATE_OpenClose1(machine);
      init_OpenClose1_state(machine,OpenClose1_FileClosed_state);
      ADD_OpenClose1(OpenClose1_currList,machine);
    }
    OpenClose1_stop_reset_status = 0;
  };
}

static void next_step_OpenClose1(OpenClose1_instance machine){
  bool T = false; /* did an event trigger */
  bool K = false; /* did a non-consuming event trigger */
  switch(machine->state){
    case OpenClose1_FileClosed_state :
      if(IS(open_event)){FREE_TO_NEXT_OpenClose1(OpenClose1_FileOpen_state);T = true;}
      if(IS(process_event)){error("OpenClose1","FileClosed",0,false);T = true;K = true;}
      if(IS(close_event)){error("OpenClose1","FileClosed",0,false);T = true;K = true;}
      break;
    case OpenClose1_FileOpen_state :
      if(IS(open_event)){error("OpenClose1","FileOpen",0,false);T = true;K = true;}
      if(IS(close_event)){FREE_TO_NEXT_OpenClose1(OpenClose1_FileClosed_state);T = true;}
      break;
  };
  if(!T || K){
    CURR_TO_NEXT_OpenClose1(machine);
  }
  else{
    FREE_OpenClose1(machine);
  }
}

static void next_OpenClose1(){
  if(
    IS(close_event)||IS(open_event)||IS(process_event)
  ){
    OpenClose1_nextList = NULL;
    OpenClose1_instance machine;
    MAP_ACTIVE_OpenClose1(machine,{next_step_OpenClose1(machine);});
    OpenClose1_currList = OpenClose1_nextList;
  }
}

static void end_OpenClose1(){
  OpenClose1_instance machine;
  MAP_ACTIVE_OpenClose1(machine,{
    if(
       machine->state == OpenClose1_FileOpen_state
    ){
      error("OpenClose1",OpenClose1_state_name(machine->state),2,false);
    }
  });
}

/**************************/
/* Private Main Functions */
/**************************/

void stop_reset_monitors(){
  if(global_stop_or_reset){
    stop_reset_OpenClose1();
  };
  global_stop_or_reset = false;
}

/*************************/
/* Public Main Functions */
/*************************/

void M_print_monitors(){
  print_OpenClose1_states();
}

void M_init(){
  init_OpenClose1(10);
  if(DEBUG_FLAG){
    M_print_monitors();
  }
}

void M_submit(int event){
  curr_event.kind = event;
  if(DEBUG_FLAG){
    printf("\n=== [%s]: ========================\n", event_name());
  }
  next_OpenClose1();
  stop_reset_monitors();
  if(DEBUG_FLAG){
    M_print_monitors();
  }
}

void M_stop_monitor(string monitor){
  if(monitor == "OpenClose1")OpenClose1_stop_reset_status = 2;
  global_stop_or_reset = true;
}

void M_reset_monitor(string monitor){
  if(monitor == "OpenClose1" && OpenClose1_stop_reset_status == 0)OpenClose1_stop_reset_status = 1;
  global_stop_or_reset = true;
}

void M_stop_all_monitors(){
  OpenClose1_stop_reset_status = 2;
  global_stop_or_reset = true;
}

void M_reset_all_monitors(){
  if(OpenClose1_stop_reset_status == 0)OpenClose1_stop_reset_status = 1;
  global_stop_or_reset = true;
}

void M_end(){
  end_OpenClose1();
}


