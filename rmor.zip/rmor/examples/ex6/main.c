
#include <stdio.h>
#include <stdlib.h>

#define bool int
#define false 0
#define true  1

#define N1 1000000
#define N2 10000

struct FileStr{
  char* name;
};

typedef struct FileStr *File;

File openfile(char* fileName) {
  File file = (File)malloc(sizeof(struct FileStr));
  file->name = fileName;
  return file;
}

void closefile(File file) {
  free(file);
}

void processfile(File file) {
  int i;
  int j = 0;
  for(i=0;i<N2;i++) {
    j = j + i;
  }
}

main(){
  File file; 
  int i;
  for(i=0;i<N1;i++) {
    file = openfile("data"); 
    processfile(file);
    closefile(file);
  }
  file = openfile("data"); 
  processfile(file);
}









