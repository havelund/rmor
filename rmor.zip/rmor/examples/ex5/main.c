
#include <stdio.h>
#include <stdlib.h>

#define bool int
#define false 0
#define true  1

struct ConnectionStr{
  char* name;
  char* data; // simplified view of a file, not used
};

typedef struct ConnectionStr *Connection;
char* header;

Connection open_connection(char* name) {
  printf("opening connection %s\n", name);
  Connection connection = (Connection)malloc(sizeof(struct ConnectionStr));
  connection->name = name;
  connection->data = NULL;
  return connection;
}

bool close_connection(Connection connection) {
  printf("closing connection %s\n",connection->name);
  return true;
}

void cancel_transmission(Connection connection) {
  printf("cancelling connection %s\n",connection->name);
}

void write_buffer(Connection connection, int data) {
  printf("writing buffer of connection %s\n",connection->name);
}

void commit_buffer(Connection connection) {
  printf("committing buffer of connection %s\n",connection->name);
}

void acknowledge() {
  printf("callback acknowledgement\n");
}

void debug(char* str){
  printf("---> %s\n", str);
}

void handler(char *monitor, char *state, int kind){
  printf("--- HANDLER: monitor=%s state=%s kind=%d\n", monitor, state, kind);
}


main(){
  Connection c1,c2;

  c1 = open_connection("connection1");
  c2 = open_connection("connection2");
  write_buffer(c1,100);
  commit_buffer(c1);
  close_connection(c1);
}









