
type lexerstate = NormalLex | PointcutLex

let lexstate : lexerstate ref = ref NormalLex
