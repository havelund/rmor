
open Ast
open Translate

let _ = 
   print_string "\n";
   print_string "#################\n";
   Printf.printf "RMOR Version 2.0\n"; 
   print_string "#################\n";
   print_string "\n";
   print_string "\n";
   print_string "======================================\n";
   Printf.printf "Synthesizing monitors from rmor.spec.\n"; 
   print_string "======================================\n";
   print_string "\n";
   let lexbuf = Lexing.from_channel (open_in "rmor.spec") in 
   let result = Parser.main Lexer.token lexbuf in 
   wholespec := result;
   if(not (wellformed result)) then
   begin
     Printf.printf "\n%d error(s) detected, application terminated!\n\n" !errors;    
     exit(1);
   end;
   generate_automata result
