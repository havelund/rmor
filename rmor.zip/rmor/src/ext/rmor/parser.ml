type token =
  | IDENT of (string)
  | IDENTPAT of (string)
  | INT of (int)
  | HANDLED
  | UNCHECKED
  | ASPECT
  | IMPORT
  | POINTCUT
  | SYMBOL
  | CALL
  | SET
  | WITHIN
  | WITHINCODE
  | BEFORE
  | AFTER
  | MACHINE
  | STATE
  | ANYTIME
  | ONCE
  | INITIAL
  | SAFE
  | LIVE
  | NEXT
  | WHEN
  | THEN
  | PARTHEN
  | SUPER
  | WHILE
  | DO
  | OD
  | GOTO
  | PLUS
  | TIMES
  | ANY
  | EQ
  | NOT
  | AND
  | OR
  | COLON
  | SEMIC
  | COMMA
  | LPAREN
  | RPAREN
  | LCURLY
  | RCURLY
  | LBRACK
  | RBRACK
  | EOF

open Parsing;;
# 5 "parser.mly"

open Ast
open Lexing
open Lexerstate
open Linecounter

let parse_error msg : unit = 
   Printf.printf "*** RMOR parser halts in line %d: %s\n" !lineno msg

let idcount : int ref = ref 0

let newIdent() = 
  idcount := !idcount + 1;
  Printf.sprintf "Never%d" !idcount

# 69 "parser.ml"
let yytransl_const = [|
  260 (* HANDLED *);
  261 (* UNCHECKED *);
  262 (* ASPECT *);
  263 (* IMPORT *);
  264 (* POINTCUT *);
  265 (* SYMBOL *);
  266 (* CALL *);
  267 (* SET *);
  268 (* WITHIN *);
  269 (* WITHINCODE *);
  270 (* BEFORE *);
  271 (* AFTER *);
  272 (* MACHINE *);
  273 (* STATE *);
  274 (* ANYTIME *);
  275 (* ONCE *);
  276 (* INITIAL *);
  277 (* SAFE *);
  278 (* LIVE *);
  279 (* NEXT *);
  280 (* WHEN *);
  281 (* THEN *);
  282 (* PARTHEN *);
  283 (* SUPER *);
  284 (* WHILE *);
  285 (* DO *);
  286 (* OD *);
  287 (* GOTO *);
  288 (* PLUS *);
  289 (* TIMES *);
  290 (* ANY *);
  291 (* EQ *);
  292 (* NOT *);
  293 (* AND *);
  294 (* OR *);
  295 (* COLON *);
  296 (* SEMIC *);
  297 (* COMMA *);
  298 (* LPAREN *);
  299 (* RPAREN *);
  300 (* LCURLY *);
  301 (* RCURLY *);
  302 (* LBRACK *);
  303 (* RBRACK *);
    0 (* EOF *);
    0|]

let yytransl_block = [|
  257 (* IDENT *);
  258 (* IDENTPAT *);
  259 (* INT *);
    0|]

let yylhs = "\255\255\
\001\000\001\000\002\000\003\000\003\000\006\000\006\000\004\000\
\004\000\005\000\005\000\007\000\007\000\008\000\008\000\008\000\
\008\000\008\000\009\000\010\000\014\000\014\000\014\000\014\000\
\014\000\014\000\014\000\014\000\014\000\015\000\016\000\016\000\
\017\000\017\000\018\000\011\000\011\000\019\000\019\000\020\000\
\020\000\012\000\021\000\021\000\013\000\013\000\013\000\013\000\
\022\000\022\000\023\000\023\000\025\000\025\000\027\000\027\000\
\027\000\027\000\027\000\027\000\024\000\024\000\028\000\028\000\
\030\000\030\000\031\000\031\000\026\000\026\000\026\000\026\000\
\026\000\026\000\029\000\029\000\000\000"

let yylen = "\002\000\
\001\000\002\000\006\000\000\000\002\000\001\000\001\000\000\000\
\001\000\000\000\001\000\001\000\002\000\001\000\001\000\001\000\
\001\000\001\000\003\000\005\000\004\000\004\000\004\000\004\000\
\001\000\003\000\003\000\003\000\002\000\001\000\001\000\003\000\
\001\000\003\000\001\000\004\000\006\000\000\000\003\000\001\000\
\001\000\005\000\000\000\002\000\009\000\006\000\006\000\003\000\
\001\000\003\000\000\000\003\000\000\000\002\000\001\000\001\000\
\001\000\001\000\001\000\001\000\000\000\002\000\006\000\002\000\
\000\000\001\000\000\000\001\000\001\000\001\000\003\000\003\000\
\003\000\002\000\001\000\001\000\002\000"

let yydefred = "\000\000\
\000\000\000\000\006\000\007\000\001\000\077\000\000\000\000\000\
\000\000\002\000\000\000\005\000\009\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\055\000\056\000\057\000\058\000\
\059\000\060\000\000\000\000\000\011\000\000\000\014\000\015\000\
\016\000\017\000\018\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\003\000\013\000\000\000\054\000\048\000\
\000\000\019\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\025\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\040\000\041\000\000\000\000\000\
\036\000\000\000\000\000\000\000\000\000\000\000\070\000\069\000\
\000\000\000\000\000\000\000\000\062\000\030\000\000\000\000\000\
\000\000\000\000\029\000\000\000\000\000\000\000\020\000\000\000\
\039\000\044\000\042\000\000\000\000\000\000\000\074\000\000\000\
\075\000\076\000\000\000\000\000\000\000\047\000\000\000\000\000\
\000\000\000\000\035\000\000\000\000\000\028\000\027\000\000\000\
\037\000\050\000\000\000\046\000\073\000\072\000\000\000\066\000\
\000\000\000\000\021\000\000\000\022\000\023\000\024\000\000\000\
\000\000\000\000\032\000\034\000\000\000\000\000\068\000\063\000\
\052\000\045\000"

let yydgoto = "\002\000\
\006\000\007\000\008\000\014\000\028\000\009\000\029\000\030\000\
\031\000\032\000\033\000\034\000\035\000\068\000\087\000\112\000\
\114\000\116\000\054\000\071\000\075\000\077\000\137\000\059\000\
\036\000\083\000\037\000\060\000\109\000\129\000\144\000"

let yysindex = "\020\000\
\001\000\000\000\000\000\000\000\000\000\000\000\001\000\019\255\
\071\255\000\000\030\255\000\000\000\000\000\255\047\255\250\254\
\061\255\063\255\072\255\095\255\000\000\000\000\000\000\000\000\
\000\000\000\000\098\255\039\255\000\000\047\255\000\000\000\000\
\000\000\000\000\000\000\032\255\092\255\007\255\078\255\066\255\
\245\254\059\255\076\255\000\000\000\000\125\255\000\000\000\000\
\103\255\000\000\003\255\110\255\127\255\089\255\060\255\129\255\
\087\255\004\255\102\255\103\255\000\000\091\255\091\255\091\255\
\091\255\003\255\003\255\068\255\000\000\000\000\003\255\093\255\
\000\000\060\255\090\255\096\255\094\255\103\255\000\000\000\000\
\004\255\004\255\034\255\099\255\000\000\000\000\134\255\136\255\
\138\255\134\255\000\000\048\255\003\255\003\255\000\000\079\255\
\000\000\000\000\000\000\129\255\100\255\097\255\000\000\055\255\
\000\000\000\000\004\255\004\255\112\255\000\000\106\255\104\255\
\107\255\105\255\000\000\108\255\109\255\000\000\000\000\113\255\
\000\000\000\000\121\255\000\000\000\000\000\000\116\255\000\000\
\153\255\154\255\000\000\155\255\000\000\000\000\000\000\004\255\
\103\255\115\255\000\000\000\000\083\255\114\255\000\000\000\000\
\000\000\000\000"

let yyrindex = "\000\000\
\152\255\000\000\000\000\000\000\000\000\000\000\152\255\000\000\
\152\255\000\000\117\255\000\000\000\000\000\000\248\254\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\002\255\000\000\000\000\
\000\000\000\000\000\000\000\000\143\255\000\000\000\000\000\000\
\122\255\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\133\255\000\000\000\000\000\000\000\000\000\000\005\255\000\000\
\000\000\000\000\000\000\013\255\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\122\255\
\000\000\005\255\000\000\118\255\000\000\119\255\000\000\000\000\
\000\000\000\000\243\254\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\165\255\000\000\124\255\000\000\
\126\255\000\000\000\000\000\000\000\000\000\000\000\000\057\255\
\000\000\000\000\238\254\000\000\000\000\000\000\064\255\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\119\255\252\254\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000"

let yygindex = "\000\000\
\161\000\000\000\162\000\000\000\000\000\000\000\140\000\000\000\
\000\000\000\000\000\000\000\000\224\255\197\255\244\255\082\000\
\000\000\000\000\101\000\000\000\100\000\075\000\000\000\196\255\
\139\000\177\255\000\000\000\000\000\000\000\000\000\000"

let yytablesize = 262
let yytable = "\085\000\
\005\000\103\000\104\000\061\000\079\000\051\000\091\000\092\000\
\053\000\048\000\064\000\096\000\062\000\063\000\064\000\065\000\
\064\000\102\000\053\000\067\000\001\000\053\000\074\000\052\000\
\011\000\067\000\051\000\126\000\127\000\053\000\013\000\064\000\
\038\000\119\000\120\000\049\000\010\000\080\000\066\000\081\000\
\067\000\074\000\061\000\015\000\067\000\082\000\012\000\016\000\
\046\000\043\000\088\000\089\000\090\000\017\000\018\000\019\000\
\141\000\061\000\105\000\106\000\016\000\039\000\020\000\040\000\
\021\000\022\000\023\000\024\000\025\000\026\000\107\000\108\000\
\041\000\027\000\003\000\004\000\142\000\021\000\022\000\023\000\
\024\000\025\000\026\000\044\000\093\000\094\000\027\000\071\000\
\071\000\071\000\118\000\107\000\108\000\071\000\026\000\042\000\
\026\000\125\000\043\000\026\000\051\000\071\000\055\000\071\000\
\093\000\094\000\071\000\095\000\071\000\021\000\022\000\023\000\
\024\000\025\000\026\000\093\000\094\000\050\000\121\000\107\000\
\108\000\056\000\145\000\069\000\070\000\057\000\058\000\072\000\
\073\000\076\000\078\000\084\000\086\000\053\000\099\000\111\000\
\100\000\113\000\110\000\115\000\101\000\124\000\128\000\123\000\
\130\000\132\000\131\000\133\000\136\000\093\000\134\000\135\000\
\107\000\138\000\143\000\139\000\140\000\004\000\146\000\053\000\
\008\000\038\000\061\000\061\000\049\000\065\000\031\000\010\000\
\033\000\045\000\012\000\117\000\097\000\098\000\122\000\047\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\
\000\000\000\000\000\000\000\000\003\000\004\000"

let yycheck = "\060\000\
\000\000\081\000\082\000\001\001\001\001\024\001\066\000\067\000\
\017\001\003\001\024\001\071\000\010\001\011\001\012\001\013\001\
\030\001\078\000\017\001\024\001\001\000\017\001\055\000\035\001\
\006\001\030\001\045\001\107\000\108\000\041\001\001\001\045\001\
\039\001\093\000\094\000\029\001\045\001\034\001\036\001\036\001\
\045\001\074\000\030\001\044\001\042\001\042\001\045\001\001\001\
\017\001\045\001\063\000\064\000\065\000\007\001\008\001\009\001\
\136\000\045\001\025\001\026\001\001\001\001\001\016\001\001\001\
\018\001\019\001\020\001\021\001\022\001\023\001\037\001\038\001\
\001\001\027\001\004\001\005\001\137\000\018\001\019\001\020\001\
\021\001\022\001\023\001\045\001\037\001\038\001\027\001\024\001\
\025\001\026\001\043\001\037\001\038\001\030\001\038\001\001\001\
\040\001\043\001\001\001\043\001\035\001\038\001\044\001\040\001\
\037\001\038\001\043\001\040\001\045\001\018\001\019\001\020\001\
\021\001\022\001\023\001\037\001\038\001\040\001\040\001\037\001\
\038\001\046\001\040\001\014\001\015\001\001\001\024\001\001\001\
\040\001\001\001\044\001\030\001\042\001\041\001\045\001\002\001\
\041\001\002\001\040\001\002\001\047\001\045\001\031\001\044\001\
\039\001\039\001\043\001\043\001\028\001\037\001\043\001\043\001\
\037\001\001\001\040\001\002\001\002\001\006\001\045\001\017\001\
\044\001\040\001\030\001\045\001\047\001\001\001\043\001\007\000\
\043\001\030\000\009\000\090\000\072\000\074\000\100\000\037\000\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\255\
\255\255\255\255\255\255\255\255\004\001\005\001"

let yynames_const = "\
  HANDLED\000\
  UNCHECKED\000\
  ASPECT\000\
  IMPORT\000\
  POINTCUT\000\
  SYMBOL\000\
  CALL\000\
  SET\000\
  WITHIN\000\
  WITHINCODE\000\
  BEFORE\000\
  AFTER\000\
  MACHINE\000\
  STATE\000\
  ANYTIME\000\
  ONCE\000\
  INITIAL\000\
  SAFE\000\
  LIVE\000\
  NEXT\000\
  WHEN\000\
  THEN\000\
  PARTHEN\000\
  SUPER\000\
  WHILE\000\
  DO\000\
  OD\000\
  GOTO\000\
  PLUS\000\
  TIMES\000\
  ANY\000\
  EQ\000\
  NOT\000\
  AND\000\
  OR\000\
  COLON\000\
  SEMIC\000\
  COMMA\000\
  LPAREN\000\
  RPAREN\000\
  LCURLY\000\
  RCURLY\000\
  LBRACK\000\
  RBRACK\000\
  EOF\000\
  "

let yynames_block = "\
  IDENT\000\
  IDENTPAT\000\
  INT\000\
  "

let yyact = [|
  (fun _ -> failwith "parser")
; (fun __caml_parser_env ->
    Obj.repr(
# 50 "parser.mly"
        ( [] )
# 354 "parser.ml"
               : Ast.specification))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'aspect_decl) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : Ast.specification) in
    Obj.repr(
# 51 "parser.mly"
                     ( _1 :: _2 )
# 362 "parser.ml"
               : Ast.specification))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 5 : 'aspect_modifiers) in
    let _3 = (Parsing.peek_val __caml_parser_env 3 : 'ident_opt) in
    let _5 = (Parsing.peek_val __caml_parser_env 1 : 'aspect_body) in
    Obj.repr(
# 55 "parser.mly"
                                                              ( ASPECT(_1,_3,_5) )
# 371 "parser.ml"
               : 'aspect_decl))
; (fun __caml_parser_env ->
    Obj.repr(
# 59 "parser.mly"
              ( [] )
# 377 "parser.ml"
               : 'aspect_modifiers))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'aspect_modifier) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'aspect_modifiers) in
    Obj.repr(
# 60 "parser.mly"
                                   ( _1 :: _2 )
# 385 "parser.ml"
               : 'aspect_modifiers))
; (fun __caml_parser_env ->
    Obj.repr(
# 64 "parser.mly"
            ( HANDLED)
# 391 "parser.ml"
               : 'aspect_modifier))
; (fun __caml_parser_env ->
    Obj.repr(
# 65 "parser.mly"
            ( UNCHECKED )
# 397 "parser.ml"
               : 'aspect_modifier))
; (fun __caml_parser_env ->
    Obj.repr(
# 69 "parser.mly"
              ( newIdent() )
# 403 "parser.ml"
               : 'ident_opt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 70 "parser.mly"
              ( _1 )
# 410 "parser.ml"
               : 'ident_opt))
; (fun __caml_parser_env ->
    Obj.repr(
# 74 "parser.mly"
              ( [] )
# 416 "parser.ml"
               : 'aspect_body))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'aspect_body_decl_list) in
    Obj.repr(
# 75 "parser.mly"
                        ( _1 )
# 423 "parser.ml"
               : 'aspect_body))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'aspect_body_decl) in
    Obj.repr(
# 79 "parser.mly"
                   ( _1 )
# 430 "parser.ml"
               : 'aspect_body_decl_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'aspect_body_decl) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'aspect_body_decl_list) in
    Obj.repr(
# 80 "parser.mly"
                                         ( _1 @ _2 )
# 438 "parser.ml"
               : 'aspect_body_decl_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'import_decl) in
    Obj.repr(
# 83 "parser.mly"
                ( _1 )
# 445 "parser.ml"
               : 'aspect_body_decl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'pointcut_decl) in
    Obj.repr(
# 84 "parser.mly"
                ( _1 )
# 452 "parser.ml"
               : 'aspect_body_decl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'symbol_decl) in
    Obj.repr(
# 85 "parser.mly"
                ( _1 )
# 459 "parser.ml"
               : 'aspect_body_decl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'machine_decl) in
    Obj.repr(
# 86 "parser.mly"
                ( _1 )
# 466 "parser.ml"
               : 'aspect_body_decl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : 'state_decl) in
    Obj.repr(
# 87 "parser.mly"
                ( _1 )
# 473 "parser.ml"
               : 'aspect_body_decl))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : string) in
    Obj.repr(
# 91 "parser.mly"
                     ( [IMPORT_DECL(_2)] )
# 480 "parser.ml"
               : 'import_decl))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'pointcut_expr) in
    Obj.repr(
# 95 "parser.mly"
                                        ( [POINTCUT_DECL(_2,_4)] )
# 488 "parser.ml"
               : 'pointcut_decl))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : 'lparen) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'method_identpat) in
    Obj.repr(
# 99 "parser.mly"
                                     ( let (file,meth) = _3 in CALL(file,meth) )
# 496 "parser.ml"
               : 'pointcut_expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : 'lparen) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'variable_identpat) in
    Obj.repr(
# 100 "parser.mly"
                                      ( let (file,var) = _3 in SET(file,var) )
# 504 "parser.ml"
               : 'pointcut_expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : 'lparen) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'file_identpat) in
    Obj.repr(
# 101 "parser.mly"
                                     ( WITHIN(_3) )
# 512 "parser.ml"
               : 'pointcut_expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : 'lparen) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'method_identpat) in
    Obj.repr(
# 102 "parser.mly"
                                           ( let (file,meth) = _3 in WITHINCODE(file,meth) )
# 520 "parser.ml"
               : 'pointcut_expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 103 "parser.mly"
        ( PCIDENT(_1) )
# 527 "parser.ml"
               : 'pointcut_expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'pointcut_expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'pointcut_expr) in
    Obj.repr(
# 104 "parser.mly"
                                 ( OR(_1,_3) )
# 535 "parser.ml"
               : 'pointcut_expr))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'pointcut_expr) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'pointcut_expr) in
    Obj.repr(
# 105 "parser.mly"
                                  ( AND(_1,_3) )
# 543 "parser.ml"
               : 'pointcut_expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'pointcut_expr) in
    Obj.repr(
# 106 "parser.mly"
                              ( _2 )
# 550 "parser.ml"
               : 'pointcut_expr))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'pointcut_expr) in
    Obj.repr(
# 107 "parser.mly"
                    ( NOT(_2) )
# 557 "parser.ml"
               : 'pointcut_expr))
; (fun __caml_parser_env ->
    Obj.repr(
# 111 "parser.mly"
         ( lexstate := PointcutLex )
# 563 "parser.ml"
               : 'lparen))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 115 "parser.mly"
           ( lexstate := NormalLex ; ("*",_1) )
# 570 "parser.ml"
               : 'method_identpat))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 116 "parser.mly"
                          ( lexstate := NormalLex ; (_1,_3) )
# 578 "parser.ml"
               : 'method_identpat))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 120 "parser.mly"
           ( lexstate := NormalLex ; ("*",_1) )
# 585 "parser.ml"
               : 'variable_identpat))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 121 "parser.mly"
                          ( lexstate := NormalLex ; (_1,_3) )
# 593 "parser.ml"
               : 'variable_identpat))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 125 "parser.mly"
           ( lexstate := NormalLex ; _1 )
# 600 "parser.ml"
               : 'file_identpat))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 1 : 'symbol_ident_list) in
    Obj.repr(
# 129 "parser.mly"
                                       ( ABS_SYMBOL_DECL(_2) :: _3 )
# 608 "parser.ml"
               : 'symbol_decl))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 4 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 2 : 'advice_spec) in
    let _5 = (Parsing.peek_val __caml_parser_env 1 : 'pointcut_expr) in
    Obj.repr(
# 130 "parser.mly"
                                                  ( [SYMBOL_DECL(_2,_4,_5)] )
# 617 "parser.ml"
               : 'symbol_decl))
; (fun __caml_parser_env ->
    Obj.repr(
# 134 "parser.mly"
              ( [] )
# 623 "parser.ml"
               : 'symbol_ident_list))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'symbol_ident_list) in
    Obj.repr(
# 135 "parser.mly"
                                ( ABS_SYMBOL_DECL(_2) :: _3 )
# 631 "parser.ml"
               : 'symbol_ident_list))
; (fun __caml_parser_env ->
    Obj.repr(
# 139 "parser.mly"
         ( BEFORE)
# 637 "parser.ml"
               : 'advice_spec))
; (fun __caml_parser_env ->
    Obj.repr(
# 140 "parser.mly"
         ( AFTER )
# 643 "parser.ml"
               : 'advice_spec))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 3 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 1 : 'state_decl_list) in
    Obj.repr(
# 144 "parser.mly"
                                              ( [MACHINE_DECL(_2,_4)] )
# 651 "parser.ml"
               : 'machine_decl))
; (fun __caml_parser_env ->
    Obj.repr(
# 148 "parser.mly"
              ( [] )
# 657 "parser.ml"
               : 'state_decl_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'state_decl) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'state_decl_list) in
    Obj.repr(
# 149 "parser.mly"
                             ( _1 @ _2 )
# 665 "parser.ml"
               : 'state_decl_list))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 7 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 5 : 'idlist) in
    let _7 = (Parsing.peek_val __caml_parser_env 2 : 'while_opt) in
    let _8 = (Parsing.peek_val __caml_parser_env 1 : 'state_body_decl_list) in
    Obj.repr(
# 154 "parser.mly"
  ( [SUPER_DECL(_2,_4,_7,_8)] )
# 675 "parser.ml"
               : 'state_decl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 5 : 'modifiers_opt) in
    let _3 = (Parsing.peek_val __caml_parser_env 3 : string) in
    let _5 = (Parsing.peek_val __caml_parser_env 1 : 'state_body_decl_list) in
    Obj.repr(
# 156 "parser.mly"
  ( [STATE_DECL(_1,_3,_5)] )
# 684 "parser.ml"
               : 'state_decl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 5 : string) in
    let _4 = (Parsing.peek_val __caml_parser_env 2 : 'state_body_decl_list) in
    Obj.repr(
# 157 "parser.mly"
                                               ( [STATE_DECL([],_1,_4)] )
# 692 "parser.ml"
               : 'state_decl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : int) in
    Obj.repr(
# 158 "parser.mly"
                  ( [STATE_DECL([],_1,[])] )
# 700 "parser.ml"
               : 'state_decl))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 162 "parser.mly"
        ( [_1] )
# 707 "parser.ml"
               : 'idlist))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : string) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'idlist) in
    Obj.repr(
# 163 "parser.mly"
                     ( _1 :: _3 )
# 715 "parser.ml"
               : 'idlist))
; (fun __caml_parser_env ->
    Obj.repr(
# 167 "parser.mly"
              ( None )
# 721 "parser.ml"
               : 'while_opt))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'condition) in
    Obj.repr(
# 168 "parser.mly"
                        ( Some _2  )
# 728 "parser.ml"
               : 'while_opt))
; (fun __caml_parser_env ->
    Obj.repr(
# 172 "parser.mly"
              ( [] )
# 734 "parser.ml"
               : 'modifiers_opt))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'modifier) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'modifiers_opt) in
    Obj.repr(
# 173 "parser.mly"
                         ( _1 :: _2)
# 742 "parser.ml"
               : 'modifiers_opt))
; (fun __caml_parser_env ->
    Obj.repr(
# 177 "parser.mly"
          ( ANYTIME )
# 748 "parser.ml"
               : 'modifier))
; (fun __caml_parser_env ->
    Obj.repr(
# 178 "parser.mly"
          ( ONCE    )
# 754 "parser.ml"
               : 'modifier))
; (fun __caml_parser_env ->
    Obj.repr(
# 179 "parser.mly"
          ( INITIAL )
# 760 "parser.ml"
               : 'modifier))
; (fun __caml_parser_env ->
    Obj.repr(
# 180 "parser.mly"
          ( SAFE    )
# 766 "parser.ml"
               : 'modifier))
; (fun __caml_parser_env ->
    Obj.repr(
# 181 "parser.mly"
          ( LIVE    )
# 772 "parser.ml"
               : 'modifier))
; (fun __caml_parser_env ->
    Obj.repr(
# 182 "parser.mly"
          ( NEXT    )
# 778 "parser.ml"
               : 'modifier))
; (fun __caml_parser_env ->
    Obj.repr(
# 186 "parser.mly"
              ( [] )
# 784 "parser.ml"
               : 'state_body_decl_list))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 1 : 'state_body_decl) in
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'state_body_decl_list) in
    Obj.repr(
# 187 "parser.mly"
                                       ( _1 :: _2 )
# 792 "parser.ml"
               : 'state_body_decl_list))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 4 : 'condition) in
    let _3 = (Parsing.peek_val __caml_parser_env 3 : 'thenarrow) in
    let _4 = (Parsing.peek_val __caml_parser_env 2 : 'goto_opt) in
    let _5 = (Parsing.peek_val __caml_parser_env 1 : string) in
    let _6 = (Parsing.peek_val __caml_parser_env 0 : 'semic_opt) in
    Obj.repr(
# 191 "parser.mly"
                                                    ( Leave(_2,_3,_5) )
# 803 "parser.ml"
               : 'state_body_decl))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'condition) in
    Obj.repr(
# 192 "parser.mly"
                 ( Stay(_2) )
# 810 "parser.ml"
               : 'state_body_decl))
; (fun __caml_parser_env ->
    Obj.repr(
# 196 "parser.mly"
              ()
# 816 "parser.ml"
               : 'goto_opt))
; (fun __caml_parser_env ->
    Obj.repr(
# 197 "parser.mly"
       ()
# 822 "parser.ml"
               : 'goto_opt))
; (fun __caml_parser_env ->
    Obj.repr(
# 201 "parser.mly"
              ()
# 828 "parser.ml"
               : 'semic_opt))
; (fun __caml_parser_env ->
    Obj.repr(
# 202 "parser.mly"
        ()
# 834 "parser.ml"
               : 'semic_opt))
; (fun __caml_parser_env ->
    Obj.repr(
# 206 "parser.mly"
      ( ANY )
# 840 "parser.ml"
               : 'condition))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 0 : string) in
    Obj.repr(
# 207 "parser.mly"
        ( CoIDENT(_1) )
# 847 "parser.ml"
               : 'condition))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'condition) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'condition) in
    Obj.repr(
# 208 "parser.mly"
                         ( CoOR(_1,_3) )
# 855 "parser.ml"
               : 'condition))
; (fun __caml_parser_env ->
    let _1 = (Parsing.peek_val __caml_parser_env 2 : 'condition) in
    let _3 = (Parsing.peek_val __caml_parser_env 0 : 'condition) in
    Obj.repr(
# 209 "parser.mly"
                          ( CoAND(_1,_3) )
# 863 "parser.ml"
               : 'condition))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 1 : 'condition) in
    Obj.repr(
# 210 "parser.mly"
                          ( _2 )
# 870 "parser.ml"
               : 'condition))
; (fun __caml_parser_env ->
    let _2 = (Parsing.peek_val __caml_parser_env 0 : 'condition) in
    Obj.repr(
# 211 "parser.mly"
                ( CoNOT(_2) )
# 877 "parser.ml"
               : 'condition))
; (fun __caml_parser_env ->
    Obj.repr(
# 215 "parser.mly"
          ( THEN )
# 883 "parser.ml"
               : 'thenarrow))
; (fun __caml_parser_env ->
    Obj.repr(
# 216 "parser.mly"
          ( PARTHEN )
# 889 "parser.ml"
               : 'thenarrow))
(* Entry main *)
; (fun __caml_parser_env -> raise (Parsing.YYexit (Parsing.peek_val __caml_parser_env 0)))
|]
let yytables =
  { Parsing.actions=yyact;
    Parsing.transl_const=yytransl_const;
    Parsing.transl_block=yytransl_block;
    Parsing.lhs=yylhs;
    Parsing.len=yylen;
    Parsing.defred=yydefred;
    Parsing.dgoto=yydgoto;
    Parsing.sindex=yysindex;
    Parsing.rindex=yyrindex;
    Parsing.gindex=yygindex;
    Parsing.tablesize=yytablesize;
    Parsing.table=yytable;
    Parsing.check=yycheck;
    Parsing.error_function=parse_error;
    Parsing.names_const=yynames_const;
    Parsing.names_block=yynames_block }
let main (lexfun : Lexing.lexbuf -> token) (lexbuf : Lexing.lexbuf) =
   (Parsing.yyparse yytables 1 lexfun lexbuf : Ast.specification)
