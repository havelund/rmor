
open List
open String
open Ast

(***************)
(* Shared data *)
(***************)

let debug : bool ref = ref false

(*************)
(* Utilities *)
(*************)

let head = List.hd
let tail = List.tl

let concat_strings : string list -> string =
  function ss -> concat "" ss


(***********************)
(* Encryption of names *)
(***********************)

let encrypt_event : string -> string =
  function event ->
    concat_strings [event;"_event"]

let encrypt_monitor : string -> string =
  function monitor ->
    concat_strings [monitor;"_instance"]


(**********************)
(* Printing Functions *)
(**********************)

let out = open_out "rmor.c"
let ouh = open_out "rmor.h"

let print = Printf.fprintf

let print_nl() = print out "\n"

let println : string -> unit = 
  function s ->
    print out "%s" s;
    print_nl()

let print_comment : string -> unit =
  function comment ->
    let l = length comment in
    let stars = make l '*' in
    begin
      print out "\n";
      print out "/**%s**/\n" stars;
      print out "/* %s */\n" comment;
      print out "/**%s**/\n" stars;
      print out "\n";
    end


(*************)
(* Translate *)
(*************)

let rec generate_automata : specification -> unit =
  function spec ->
    generate_preamble spec;
    generate_events spec;
    translate_specification spec;
    generate_main_functions (monitor_names spec);
    print out "\n\n";


(************)
(* Preamble *)
(************)

and generate_preamble : specification -> unit =
  function spec ->
    print_comment("RMOR Generated Code");
    print_comment("Preamble");
    println("#include <stdlib.h>");
    println("#include <stdio.h>");
    println("#include \"sglib.h\"");
    println("#include \"rmor.h\"");
    println("");
    println("#define string char*");
    println("#define bool int");
    println("#define true 1");
    println("#define false 0");
    println("");
    println("#define SAME_STATE(x,y) ((int)(x->state)-(y->state))");
    println("");
    if !debug then
      println("#define DEBUG_FLAG 1")
    else
      println("#define DEBUG_FLAG 0");
    println("#define DEBUG if(DEBUG_FLAG)printf");
    if any_handled spec then
    begin
      println("");
      println("extern void handler(string monitor, string state, int kind);");
    end;
    println("");
    println("static void error(string monitor, string state, int kind, bool handled){");
    println("  string msg;");
    println("  switch(kind){");
    println("    case 0 : msg = \"error state entered\";break;");
    println("    case 1 : msg = \"next state not exited\";break;");
    println("    case 2 : msg = \"live state active at end\";break;");
    println("    case 3 : msg = \"states exhausted\";");
    println("  };");
    println("  printf(\"*** %s.%s : %s\\n\",monitor,state,msg);");
    if any_handled spec then
      println("  if(handled){handler(monitor,state,kind);}");
    println("}");
    println("");
    println("bool global_stop_or_reset = false;");


(************)
(* Automata *)
(************)

and translate_specification : specification -> unit = 
  function
  | [] -> ()
  | a :: spec1 ->
      translate_aspect(a);
      translate_specification(spec1);

and translate_aspect : aspect -> unit =
  function ASPECT(_,s,ds) ->
    if contains_states ds then
      translate_automaton s ds;
    translate_sub_automata ds;

and translate_sub_automata : aspect_body_decl list -> unit =
  function 
  | [] -> ()
  | d :: ds ->
      translate_sub_automaton d;
      translate_sub_automata ds

and translate_sub_automaton : aspect_body_decl -> unit =
  function
  | MACHINE_DECL(name,ds) ->
      translate_automaton name ds
  | _ -> ()
  
and translate_automaton : string -> aspect_body_decl list -> unit = 
  fun name ds ->
    print_comment(concat_strings ["Automaton for : "; name]);
    generate_automaton_state name;
    generate_automaton_lists name;
    generate_state_names name ds;
    generate_print_init_next_end name ds;

and generate_automaton_state : string -> unit =
  function name ->
    print out "struct %s_state{\n" name; 
    print out "  struct %s_state *next;\n" name;
    print out "  struct %s_state *previous;\n" name;
    print out "  int state;\n";
    print out "};\n";
    print_nl();
    print out "typedef struct %s_state *%s;\n" name (encrypt_monitor name);
    print_nl();
    print out "static %s new%s(){\n" (encrypt_monitor name) name;
    print out "  return (%s)malloc(sizeof(struct %s_state));\n" (encrypt_monitor name) name;
    print out "}\n";
    print_nl();
    print out "static void init_%s_state(%s machine,int state){\n" name (encrypt_monitor name);
    print out "  machine->state = state;\n";
    print out "}\n";
    print_nl();

and generate_automaton_lists : string -> unit =
  function name ->
    print out "%s %s_freeList = NULL;\n" (encrypt_monitor name) name;
    print out "%s %s_currList = NULL;\n" (encrypt_monitor name) name; 
    print out "%s %s_nextList = NULL;\n" (encrypt_monitor name) name;
    print out "int %s_stop_reset_status = 0;\n" name;
    print_nl();
    print out "#define ADD_%s(list, machine)\\\n" name;
    print out "  SGLIB_DL_LIST_ADD(struct %s_state, list, machine, previous, next);\n" name;
    print_nl();
    print out "#define ADD_NEXT_%s(machine)\\\n" name;
    print out "  {\\\n";
    print out "    %s result;\\\n" (encrypt_monitor name);
    print out "    SGLIB_DL_LIST_ADD_IF_NOT_MEMBER(struct %s_state, %s_nextList, machine, SAME_STATE, previous, next, result);\\\n" name name;
    print out "    if(result != NULL){\\\n";
    print out "      ADD_%s(%s_freeList,machine);\\\n" name name;
    print out "    }\\\n";
    print out "  }\n";
    print_nl();
    print out "#define DELETE_%s(list, machine)\\\n" name;
    print out "  SGLIB_DL_LIST_DELETE(struct %s_state, list, machine, previous, next);\n" name;
    print_nl();
    print out "#define FREE_%s(machine)\\\n" name;
    print out "  DELETE_%s(%s_currList,machine);\\\n" name name;
    print out "  ADD_%s(%s_freeList,machine)\n" name name;
    print_nl();
    print out "#define ALLOCATE_%s(machine)\\\n" name;
    print out "  SGLIB_DL_LIST_GET_FIRST(struct %s_state, %s_freeList, previous, next, machine);\\\n" name name;
    print out "  DELETE_%s(%s_freeList, machine);\n" name name;
    print_nl();
    print out "#define CURR_TO_NEXT_%s(machine)\\\n" name;
    print out "  DELETE_%s(%s_currList, machine);\\\n" name name;
    print out "  ADD_NEXT_%s(machine);\n" name;
    print_nl();
    print out "#define FREE_TO_NEXT_%s(state)\\\n" name;
    print out "  %s machine;\\\n" (encrypt_monitor name);
    print out "  if(%s_freeList != NULL){\\\n" name;
    print out "    ALLOCATE_%s(machine);\\\n" name;
    print out "    init_%s_state(machine,state);\\\n" name;
    print out "    ADD_NEXT_%s(machine);\\\n" name;
    print out "  }else{\\\n";
    print out "    error(\"%s\",%s_state_name(state),3,%b);\\\n" name name (is_handled name);
    print out "  }\n";
    print_nl();
    print out "#define MAP_ACTIVE_%s(machine, cmd)\\\n" name;
    print out "  SGLIB_DL_LIST_MAP_ON_ELEMENTS(struct %s_state, %s_currList, machine, previous, next, cmd);\n" name name;
    print_nl();
    print out "static int %s_freeList_length(){\n" name;
    print out "  int result;\n";
    print out "  SGLIB_DL_LIST_LEN(struct %s_state, %s_freeList, previous, next, result)\n" name name;
    print out "  return result;\n";
    print out "}\n";


(*********************)
(* State Definitions *)
(*********************)

and generate_state_names : string -> aspect_body_decl list -> unit =
  fun monitorname ds ->
    let statenames = get_states_aspect_body_decl_list ds in
    print_nl();
    generate_state_definitions 1 monitorname statenames;
    print_nl();
    generate_state_name_funct monitorname statenames;

and generate_state_definitions : int -> string -> string list -> unit =
  fun next monitorname statenames ->
    match statenames with
    | [] -> ()
    | statename :: statenames1 ->
        print out "#define %s_%s_state %d\n" monitorname statename next;
        generate_state_definitions (next+1) monitorname statenames1

and generate_state_name_funct : string -> string list -> unit =
  fun monitorname statenames ->
    print out "static string %s_state_name(int state){\n" monitorname;
    print out "  switch(state){\n";
    print_state_name_cases monitorname statenames;
    print out "    default:\n"; 
    print out "      printf(\"*** unknown state : %%d\\n\", state);\n";
    print out "      exit(1);\n"; 
    print out "  }\n";
    print out "}\n";

and print_state_name_cases : string -> string list -> unit =
  fun monitorname statenames ->
    match statenames with
    | [] -> ()
    | statename :: statenames1 ->
        print out "    case %s_%s_state: return \"%s\";\n" 
                        monitorname statename statename;
        print_state_name_cases monitorname statenames1;


(**************************)
(* Print, Init, Next, End *)
(**************************)

and generate_print_init_next_end : string -> aspect_body_decl list -> unit =
  fun name ds ->
    generate_print_monitor name;
    generate_init_monitor name ds;
    generate_next_monitor name ds;
    generate_end_monitor  name ds;

(* print *)

and generate_print_monitor : string -> unit =
  function name ->
    print_nl();
    print out "static void print_%s_states(){\n" name;
    print out "  %s machine;\n" (encrypt_monitor name);
    print out "  printf(\"\\n-- %s --\\n\");\n" name;
    print out "  MAP_ACTIVE_%s(machine,{\n" name;
    print out "    printf(\"state = %s\\n\", %s_state_name(machine->state));\n" "%s" name;  
    print out "  });\n";          (*^^ cheating printf to accept %s in string    ^^ *)
    print out "  printf(\"free : %%d\\n\",%s_freeList_length());\n" name;
    print out "}\n";

(* Init *)

and generate_init_monitor : string -> aspect_body_decl list -> unit =
  fun name ds ->
    let initial_state = get_initial_state_from_decls ds in
    print_nl();
    print out "static void init_%s(int noOfMachines){\n" name;
    print out "  int i;\n";
    print out "  %s r = new%s();\n" (encrypt_monitor name) name;
    print out "  init_%s_state(r,%s_%s_state);\n" name name initial_state; 
    print out "  if(noOfMachines>0)\n";
    print out "    ADD_%s(%s_currList,r);\n" name name;
    print out "  for(i=1;i<noOfMachines;i++){\n";
    print out "    r = new%s();\n" name;
    print out "    ADD_%s(%s_freeList, r);\n" name name;
    print out "  }\n";
    print out "}\n";

(* Next *)

and generate_next_monitor : string -> aspect_body_decl list -> unit =
  fun name ds ->
    generate_stop_reset_function name;
    generate_next_from_single_state name ds;
    generate_next_from_all_states name ds;

and generate_stop_reset_function : string -> unit =
  function monitorname ->
    let ename = encrypt_monitor monitorname in
    print_nl();
    print out "static void stop_reset_%s(){\n" monitorname;
    print out "  %s machine;\n" ename;
    print out "  if(%s_stop_reset_status > 0){\n" monitorname;
    print out "    MAP_ACTIVE_%s(machine,{FREE_%s(machine);});\n" monitorname monitorname;
    print out "    if(%s_stop_reset_status == 1){\n" monitorname;
    print out "      ALLOCATE_%s(machine);\n" monitorname;
    print out "      init_%s_state(machine,%s_%s_state);\n" 
                       monitorname monitorname (get_initial_state monitorname);
    print out "      ADD_%s(%s_currList,machine);\n" monitorname monitorname;
    print out "    }\n";
    print out "    %s_stop_reset_status = 0;\n" monitorname;
    print out "  };\n";
    print out "}\n";

and generate_next_from_single_state : string -> aspect_body_decl list -> unit =
  fun name ds -> 
    print_nl();
    print out "static void next_step_%s(%s machine){\n" name (encrypt_monitor name);
    print out "  bool T = false; /* did an event trigger */\n";
    print out "  bool K = false; /* did a non-consuming event trigger */\n";
    print out "  switch(machine->state){\n";
    generate_transitions name (final_plus_super ds) ds;
    print out "  };\n";
    print out "  if(!T || K){\n";
    print out "    CURR_TO_NEXT_%s(machine);\n" name;
    print out "  }\n";
    print out "  else{\n"; 
    print out "    FREE_%s(machine);\n" name;
    print out "  }\n";
    print out "}\n";

and generate_transitions : string -> final_super -> aspect_body_decl list -> unit =
  fun name finalsuper ds ->
    match ds with
    | [] -> ()
    | d :: ds1 ->
        generate_transitions_aspect_body_decl name finalsuper d;
        generate_transitions name finalsuper ds1

and generate_transitions_aspect_body_decl : string -> final_super -> aspect_body_decl -> unit =
  fun name finalsuper aspectbodydecl ->
    match aspectbodydecl with
    | STATE_DECL(modifiers,statename,statebodydecls) ->
        print out "    case %s_%s_state :\n" name statename; 
        let modifiers =
          if contains_true_selfloops statebodydecls then
            ANYTIME :: modifiers
          else
            modifiers
        in
        begin
          generate_super_conditions_transitions name statename modifiers finalsuper;
          generate_basic_transitions name statename modifiers finalsuper statebodydecls;     
          if mem NEXT modifiers then
          begin
            let leading_spaces = "      " in
            print out "%s" leading_spaces;
            print out "if(T == false){error(\"%s\",\"%s\",1,%b);T = true;};\n"
                  name statename (is_handled name);
          end;    
          print out "      break;\n";
        end
   | _ -> ()

and generate_super_conditions_transitions :
  string -> string -> modifier list -> final_super -> unit =
  fun monitorname sourcestate modifiers finalsuper ->
    generate_super_conditions monitorname sourcestate modifiers finalsuper.super;
    generate_super_transitions monitorname sourcestate modifiers finalsuper;

and generate_super_conditions : string -> string -> modifier list -> aspect_body_decl list -> unit =
  fun monitorname sourcestate modifiers superdecls -> 
    foreach superdecls
      begin function
      | SUPER_DECL(name,substates,condition_opt,ds) ->
          if(mem sourcestate substates) then
            begin
              match condition_opt with
              | None -> ()
              | Some(cond) ->
                  let leading_spaces = "      " in
                  print out "%s" leading_spaces;
                  print out "if(";
                  generate_condition (CoNOT(cond));
                  print out "){";
                  print out "T = true;";
                  if(mem ANYTIME modifiers) then print out "K = true;";
                  print out "break;}\n";
            end 
      | _ -> () (* should not happen *)
      end

and generate_super_transitions : string -> string -> modifier list -> final_super -> unit =
  fun monitorname sourcestate modifiers finalsuper -> 
    foreach finalsuper.super
      begin function 
      | SUPER_DECL(name,substates,condition_opt,ds) ->
          if(mem sourcestate substates) then
            generate_basic_transitions monitorname sourcestate modifiers finalsuper ds
      | _ -> () (* should not happen *)
      end

and generate_basic_transitions : 
  string -> string -> modifier list -> final_super -> state_body_decl list -> unit =
  fun monitorname sourcestate modifiers finalsuper ds ->
    match ds with
    | [] -> ()
    | d :: ds1 ->
        generate_transition monitorname sourcestate modifiers finalsuper d;
        generate_basic_transitions monitorname sourcestate modifiers finalsuper ds1

and generate_transition : string -> string -> modifier list -> final_super -> state_body_decl -> unit = 
  fun monitorname sourcestate modifiers finalsuper transition ->
    match transition with
    | Leave(condition,transkind,targetstate) ->
        let leading_spaces = "      " in
        print out "%s" leading_spaces;
        print out "if(";
        generate_condition condition;
        print out "){";
        if not ((mem targetstate finalsuper.final) || 
                (errorstate targetstate) || 
                (mem targetstate finalsuper.error)) 
        then 
          print out "FREE_TO_NEXT_%s(%s_%s_state);" monitorname monitorname targetstate;
        if (errorstate targetstate) || (mem targetstate finalsuper.error) then
          print out "error(\"%s\",\"%s\",0,%b);" monitorname sourcestate (is_handled monitorname);
        print out "T = true;";
        if(mem ANYTIME modifiers || transkind = PARTHEN) 
          then print out "K = true;";
        print out "}\n";
    | Stay(condition) -> () (* Not generating anything this time for Buchi self-loops *)

and errorstate : string -> bool =
  function s -> s = "error"
  
and generate_condition : condition -> unit =
  function
  | ANY ->
      print out "ANY"
  | CoIDENT(name) ->
      print out "IS(%s)" (encrypt_event name)
  | CoOR(cond1,cond2) ->
      print out "(";
      generate_condition cond1;
      print out "||";
      generate_condition cond2;
      print out ")"
  | CoAND(cond1,cond2) ->
      print out "(";
      generate_condition cond1;
      print out "&&";
      generate_condition cond2;
      print out ")"
  | CoNOT(cond) ->
      print out "!(";
      generate_condition cond;
      print out ")"

and generate_next_from_all_states : string -> aspect_body_decl list -> unit =
  fun name ds ->
    let events = get_used_events_decls ds in
    print_nl();
    print out "static void next_%s(){\n" name;
    print out "  if(\n";
    print out "    ";
    generate_used_events true events;
    print out "\n";
    print out "  ){\n";
    print out "    %s_nextList = NULL;\n" name;
    print out "    %s machine;\n" (encrypt_monitor name);
    print out "    MAP_ACTIVE_%s(machine,{next_step_%s(machine);});\n" name name;
    print out "    %s_currList = %s_nextList;\n" name name;
    print out "  }\n";
    print out "}\n";

and generate_used_events : bool -> string list -> unit =
  fun first names ->
    if first && names = [] then
      print out "false"
    else if first && mem "ANY" names then
      print out "true"
    else
      begin
        match names with
        | [] -> ()
        | name :: names1 ->
            if not first then print out "||";
            print out "IS(%s)" (encrypt_event name);
            generate_used_events false names1; 
      end

(* End *)

and generate_end_monitor : string -> aspect_body_decl list -> unit =
  fun name ds ->
    let the_live_states = live_states ds in
    print_nl();
    print out "static void end_%s(){\n" name;       
    if the_live_states != [] then 
    begin
      print out "  %s machine;\n" (encrypt_monitor name);
      print out "  MAP_ACTIVE_%s(machine,{\n" name;
      print out "    if(\n";
      generate_live_state_tests true name the_live_states;
      print out "    ){\n";
      print out "      error(\"%s\",%s_state_name(machine->state),2,%b);\n"  
                             name name (is_handled name);
      print out "    }\n";
      print out "  });\n";
    end;
    print out "}\n";

and generate_live_state_tests : bool -> string -> string list -> unit =
  fun first monitorname statenames ->        
    match statenames with
    | [] -> ()
    | statename :: statenames1 ->        
        if first then
          print out "       "
        else
          print out "    || ";
        print out "machine->state == %s_%s_state\n" monitorname statename;
        generate_live_state_tests false monitorname statenames1


(******************)
(* Main Functions *)
(******************)

and generate_main_functions : string list -> unit =
  function monitornames ->
    generate_private_main_functions monitornames;
    generate_public_main_functions monitornames;

and generate_private_main_functions : string list -> unit =
  function monitornames ->
    print_comment("Private Main Functions"); 
    generate_global_stop_reset_function monitornames;    

and generate_global_stop_reset_function : string list -> unit =
  function monitornames ->
    print out "void stop_reset_monitors(){\n";
    print out "  if(global_stop_or_reset){\n";
    let prfn monname =  
    print out "    stop_reset_%s();\n" monname 
    in map prfn monitornames;  
    print out "  };\n";
    print out "  global_stop_or_reset = false;\n";  	
    print out "}\n";
    
and generate_public_main_functions : string list -> unit =
  function monitornames ->
    print_comment("Public Main Functions"); 
    generate_print_function monitornames;
    generate_init_function monitornames;
    generate_submit_function monitornames;
    generate_stop_reset_functions monitornames;
    generate_end_function monitornames;

and generate_print_function : string list -> unit =
  function monitornames ->
    print out "void M_print_monitors(){\n";
    let prfn monname = 
      print out "  print_%s_states();\n" monname 
    in map prfn monitornames;	
    print out "}\n";

and generate_init_function : string list -> unit =
  function monitornames -> 
    print_nl();
    print out "void M_init(){\n";
    let prfn size monitorname =
      print out "  init_%s(%d);\n" monitorname size
    in map (prfn 10) monitornames; 
    print out "  if(DEBUG_FLAG){\n";
    print out "    M_print_monitors();\n";
    print out "  }\n";
    print out "}\n";

and generate_submit_function : string list -> unit =
  function monitornames -> 
    print_nl();
    print out "void M_submit(int event){\n";
    print out "  curr_event.kind = event;\n";
    print out "  if(DEBUG_FLAG){\n";
    print out "    printf(\"\\n=== [%%s]: ========================\\n\", event_name());\n";
    print out "  }\n";
    let prfn monitorname = 
      print out "  next_%s();\n" monitorname; 
    in map prfn monitornames;	
    print out "  stop_reset_monitors();\n";
    print out "  if(DEBUG_FLAG){\n";	
    print out "    M_print_monitors();\n";
    print out "  }\n";
    print out "}\n";

and generate_end_function : string list -> unit =
  function monitornames ->
    print_nl();
    print out "void M_end(){\n";
    let prfn monitorname = 
      print out "  end_%s();\n" monitorname  
    in map prfn monitornames;	
    print out "}\n";

and generate_stop_reset_functions : string list -> unit =
  function monitornames ->
    generate_stop_function monitornames;
    generate_reset_function monitornames;
    generate_stop_all_function monitornames;
    generate_reset_all_function monitornames;

and generate_stop_function : string list -> unit =
  function monitornames ->  
    print_nl();
    print out "void M_stop_monitor(string monitor){\n";
    let first : bool ref = ref true in
    foreach monitornames
    begin function name ->
      if not (!first) then print out "  else\n";
      first := false;
      print out "  if(monitor == \"%s\")%s_stop_reset_status = 2;\n" name name;
    end;
    print out "  global_stop_or_reset = true;\n";
    print out "}\n"

and generate_reset_function : string list -> unit =
  function monitornames ->  
    print_nl();
    print out "void M_reset_monitor(string monitor){\n";
    let first : bool ref = ref true in
    foreach monitornames
    begin function name ->
      if not (!first) then print out "  else\n";
      first := false;
      print out "  if(monitor == \"%s\" && %s_stop_reset_status == 0)%s_stop_reset_status = 1;\n" 
                   name name name;
    end;
    print out "  global_stop_or_reset = true;\n";
    print out "}\n"

and generate_stop_all_function : string list -> unit =
  function monitornames ->
    print_nl();
    print out "void M_stop_all_monitors(){\n";
    foreach monitornames
    begin function name ->
    print out "  %s_stop_reset_status = 2;\n" name;
    end;
    print out "  global_stop_or_reset = true;\n";
    print out "}\n"

and generate_reset_all_function : string list -> unit =
  function monitornames ->
    print_nl();
    print out "void M_reset_all_monitors(){\n";
    foreach monitornames
    begin function name ->
    print out "  if(%s_stop_reset_status == 0)%s_stop_reset_status = 1;\n" name name;
    end;
    print out "  global_stop_or_reset = true;\n";
    print out "}\n"


(**********)
(* Events *)
(**********)

and generate_events : specification -> unit =
  function spec ->
    print_comment("Events");
    generate_event_struct();
    let events = get_declared_events spec in
    let eventmap = number_events events 1 in
    generate_rmor_h eventmap;
    generate_event_name_function events;

and get_eventmap : specification -> eventmapping =
  function spec -> 
    let 
      events = get_declared_events spec 
    in
    number_events events 1;

and generate_event_struct() =
  print out "struct{\n";
  print out "  int kind;\n"; 
  print out "} curr_event;\n";
  print_nl();
  print out "#define IS(E) (curr_event.kind == E)\n"

and number_events : string list -> int -> (string * int) list =
  fun names next ->
    match names with
    | [] -> []
    | name :: names1 -> (name,next) :: number_events names1 (next+1)

and generate_rmor_h : (string * int) list ->  unit =
  function pairs ->
    generate_rmor_h_event_definitions pairs;
    generate_rmor_h_function_prototypes ();

and generate_rmor_h_event_definitions : (string * int) list ->  unit =
  function pairs ->
    print ouh "\n";
    foreach pairs
    begin function (name,nr) ->
      print ouh "#define %s %d\n" (encrypt_event name) nr
    end
      
and generate_rmor_h_function_prototypes : unit -> unit =
  function () -> 
    print ouh "\n";
    print ouh "void M_init();\n";
    print ouh "void M_print_monitors();\n"; 
    print ouh "void M_submit(int event);\n";
    print ouh "void M_stop_monitor(char *monitor);\n";
    print ouh "void M_reset_monitor(char *monitor);\n";
    print ouh "void M_stop_all_monitors();\n";
    print ouh "void M_reset_all_monitors();\n";
    print ouh "void M_end();\n"

and generate_event_name_function : string list -> unit =
  function names -> 
    print_nl();
    print out "static string event_name(){\n";
    print out "  switch(curr_event.kind){\n";
    foreach names
    begin function name ->
      print out "    case %s : return \"%s\";\n" (encrypt_event name) name;
    end;
    print out "    default : return \"UNKNOWN\";\n";
    print out "  }\n";
    print out "}\n";


