
let lineno : int ref = ref 1

let newLine() =
  lineno := !lineno + 1;

