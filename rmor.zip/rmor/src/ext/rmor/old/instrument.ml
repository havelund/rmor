
open Pretty
open Cil
open Ast
open Str
open String


(*************)
(* Utilities *)
(*************)

let head = List.hd
let tail = List.tl

let concat_strings : string list -> string =
  function ss -> concat "" ss


(***********************)
(* Regular Expressions *)
(***********************)

let str2reg : string -> regexp =
  function str -> 
   let closed = concat_strings ["^";str;"$"] in

   (* do a convertion to a Ocaml regular expression *)
   (* for example: a*b.h -> ^a.*b\.h$ *)
 
   (* replace '.' with '\.*' *)
   let str_list1 : string list = split (regexp "\.") closed in
   let result1 = concat "\." str_list1 in

   (* replace '*' with '.*' *)
   let str_list2 : string list = split (regexp "\*") result1 in
   let result2 = concat ".*" str_list2 in

   (* convert resulting string into a regular expression: *)
   begin
     (* Printf.printf "converting regexp: %s -> %s\n" str result2; *)
     regexp result2
   end  


(**********************)
(* Reading in the AST *)
(**********************)

(* Read in the specification from rmor.spec *)

let spec : specification = 
  (
     let lexbuf = Lexing.from_channel (open_in "rmor.spec") in 
     let result = Parser.main Lexer.token lexbuf in 
     result
  )

let eventmap = get_eventmap spec


(****************)
(* Advice Table *)
(****************)

type pointcut = 
  | PCCALL of regexp * regexp
  | PCSET of regexp * regexp
  | PCWITHIN of regexp
  | PCWITHINCODE of regexp * regexp
  | PCOR of pointcut * pointcut
  | PCAND of pointcut * pointcut
  | PCNOT of pointcut

type advice_code = string
type advice_insert = advice_spec * advice_code
type advice = pointcut * advice_insert
type advice_table = advice list

let rec extract_advice_table : specification -> advice_table =
  function spec ->
    extract_advice_table_specification spec spec

and extract_advice_table_specification : specification -> specification -> advice_table =
  fun spec wholespec ->
    match spec with
    | [] -> []
    | aspect :: spec1 ->
        List.append
          (extract_advice_table_aspect aspect wholespec)
          (extract_advice_table_specification spec1 wholespec)

and extract_advice_table_aspect : aspect -> specification -> advice_table =
  fun aspect spec ->
    match aspect with
    | ASPECT(_,name,ds) ->
        extract_advice_table_decls ds aspect spec

and extract_advice_table_decls : aspect_body_decl list -> aspect -> specification -> advice_table =
  fun decls aspect spec ->
    match decls with
    | [] -> []
    | decl :: decls1 ->
        List.append 
          (extract_advice_table_decl decl aspect spec) 
          (extract_advice_table_decls decls1 aspect spec)

and extract_advice_table_decl : aspect_body_decl -> aspect -> specification -> advice_table =
  fun decl aspect wholespec ->
    match decl with
    | SYMBOL_DECL(str,advspec,pcexpr) ->
        [(compose_pc pcexpr aspect spec, (advspec,str))]
    | _ -> []

and compose_pc : pointcut_expr -> aspect -> specification -> pointcut =
  fun pcexpr aspect spec ->
    let compose pc = compose_pc pc aspect spec in
    match pcexpr with
    | CALL(str1,str2) -> 
        PCCALL(str2reg str1,str2reg str2) 
    | SET(str1,str2) ->
        PCSET(str2reg str1,str2reg str2)
    | WITHIN(str) ->
        PCWITHIN(str2reg str)
    | WITHINCODE(str1,str2) ->
        PCWITHINCODE(str2reg str1,str2reg str2)
    | PCIDENT(str) -> 
        compose (lookup_pcexpr str aspect spec)
    | OR(pcexpr1,pcexpr2) -> 
        PCOR(compose pcexpr1,compose pcexpr2)
    | AND(pcexpr1,pcexpr2) -> 
        PCAND(compose pcexpr1,compose pcexpr2)
    | NOT(pcexpr) ->
        PCNOT(compose pcexpr)

and lookup_pcexpr : string -> aspect -> specification -> pointcut_expr =
  fun pcname aspect spec ->
    match aspect with
    | ASPECT(_,name,decls) ->
        try
          lookup_pc_decls pcname true decls spec
        with Not_found ->
          lookup_pc_decls pcname false decls spec

and lookup_pc_decls : string -> bool -> aspect_body_decl list -> specification -> pointcut_expr =
  fun pcname onlytop decls spec ->
    match decls with
    | [] -> raise Not_found
    | decl :: decls1 -> 
       try 
         lookup_pc_decl pcname onlytop decl spec
       with Not_found -> 
         lookup_pc_decls pcname onlytop decls1 spec

and lookup_pc_decl : string -> bool -> aspect_body_decl -> specification -> pointcut_expr =
  fun pcname onlytop decl spec ->
    match decl with 
    | POINTCUT_DECL(name,pcexpr) -> 
        if pcname = name then pcexpr else raise Not_found
    | IMPORT_DECL(name) ->
        if not onlytop then
          lookup_pcexpr pcname (get_aspect name spec) spec
        else
          raise Not_found
    | _ ->
        raise Not_found

let advices : advice_table ref = ref (extract_advice_table spec)


(*********************)
(* Accessing CIL ABS *)
(*********************)

let nameOfCalledFunction(i:instr) : string =
  match i with
  | Call(lvo, e, args, l) -> 
      match e with
      | Lval(Var(vinfo),off) -> vinfo.vname 
      | _ -> exit(1)  
  | _ -> exit(1)

let fileOfCalledFunction(i:instr) : string =
  match i with
  | Call(lvo, e, args, l) -> 
    match e with
    | Lval(Var(vinfo),off) -> vinfo.vdecl.file 
    | _ -> exit(1)  
  | _ -> exit(1)

let nameOfFundec(f:fundec) : string =
  let varinfo = f.svar in
  varinfo.vname

let fileOfFundec(f:fundec) : string =
  let varinfo = f.svar in
  varinfo.vdecl.file

let fileOfLval : lval -> string =
  function (lhost,offset) ->
    match lhost with
    | Var(varinfo) ->
        varinfo.vdecl.file
    | _ -> 
      Printf.printf "*** illformed 'file of lval' operation";
      exit(1)    

let nameOfLval : lval -> string =
  function (lhost,offset) ->
    match lhost with
    | Var(varinfo) ->
        varinfo.vname
    | _ -> 
      Printf.printf "*** illformed 'name of lval' operation";
      exit(1)    

let isGlobal : lval -> bool = 
  function (lhost,offset) ->
    match lhost with
    | Var(varinfo) ->
        varinfo.vglob
    | _ -> 
      false
    
let locationOfInstr : instr -> location =
  function i -> 
    match i with 
    | Call(_,_,_,l) -> l
    | Set(_,_,l) -> l
    | Asm(_,_,_,_,_,l) -> l


(************)
(* Matching *)
(************)

let match_call_pattern : instr -> regexp -> regexp -> bool =
  fun i reg_exp1 reg_exp2 -> 
    match i with 
    | Call(lvo, f, args, l) -> 
        let filename = fileOfCalledFunction i in
        let methodcall = nameOfCalledFunction i in
        ((string_match reg_exp1 filename 0) &&
         (string_match reg_exp2 methodcall 0)) 
    | _ -> false

let match_set_pattern : instr -> regexp -> regexp -> bool =
  fun i reg_exp1 reg_exp2 -> 
    match i with 
    | Set((Var(_),_) as lv, e, l) -> 
        let filename = fileOfLval lv in
        let variablename = nameOfLval lv in
        ((isGlobal lv)
          && (string_match reg_exp1 filename 0) 
          && (string_match reg_exp2 variablename 0)) 
    | _ -> 
      false

let match_within_pattern : instr -> regexp -> bool =
  fun i reg_exp -> 
    let l = locationOfInstr i in
    string_match reg_exp l.file 0

let match_withincode_pattern : fundec -> regexp -> regexp -> bool =
  fun f reg_exp1 reg_exp2 -> 
    let filename = fileOfFundec f in
    let methodname = nameOfFundec f in
    ((string_match reg_exp1 filename 0) &&
     (string_match reg_exp2 methodname 0)) 

let rec match_pcexpr : fundec -> instr -> pointcut -> bool =
  fun f i pc ->
    match pc with
    | PCCALL(reg_exp1,reg_exp2) -> 
        match_call_pattern i reg_exp1 reg_exp2
    | PCSET(reg_exp1,reg_exp2) ->
        match_set_pattern i reg_exp1 reg_exp2
    | PCWITHIN(reg_exp) ->
        match_within_pattern i reg_exp
    | PCWITHINCODE(reg_exp1,reg_exp2) ->
        match_withincode_pattern f reg_exp1 reg_exp2
    | PCOR(pcexpr1,pcexpr2) -> 
        match_pcexpr f i pcexpr1 || match_pcexpr f i pcexpr2
    | PCAND(pcexpr1,pcexpr2) -> 
        match_pcexpr f i pcexpr1 && match_pcexpr f i pcexpr2
    | PCNOT(pcexpr) ->
        not(match_pcexpr f i pcexpr)

let match_advice : fundec -> instr -> advice -> advice_insert list =
  fun f i (pc,advinsert) ->
    if match_pcexpr f i pc then
      [advinsert]
    else
      []

let rec match_advice_table : fundec -> instr -> advice_table -> advice_insert list =
  fun f i advtab -> 
    match advtab with
    | [] -> []
    | adv::advtab1 -> (match_advice f i adv) @ match_advice_table f i advtab1

let match_instr : fundec -> instr -> advice_insert list =
  fun f i ->
    match_advice_table f i !advices

let rec extract_advice_strings : advice_insert list -> string =
  function 
  | [] -> ""
  | (advicespec,event) :: rest -> 
      let advicespec_str = (match advicespec with BEFORE -> "before" | AFTER -> "after") in  
      let adviceinsert_str = concat_strings ["{";advicespec_str;":";event;"}"] in
      let rest_str = extract_advice_strings rest in
      concat_strings [adviceinsert_str;rest_str]
      

(*************)
(* Insertion *)
(*************)

let printfFun =   
  let fdec = emptyFunction "printf" in
  fdec.svar.vtype <- TFun(
    intType,                                 (* result type             *) 
    Some [("format", charConstPtrType, [])], (* argument list, no attrs *)
    true,                                    (* variable arg function   *)
    []);                                     (* no attributes           *)
  fdec

let submitFun =   
  let fdec = emptyFunction "M_submit" in
  fdec.svar.vtype <- TFun(
    voidType,                       (* result type             *) 
    Some [("event", intType, [])],  (* argument list, no attrs *)
    false,                          (* variable arg function   *)
    []);                            (* no attributes           *)
  fdec

let create_print_instr : string -> location -> instr =
  fun str loc -> 
    let 
      format = Pretty.sprint 80 (Pretty.dprintf "event %%s at %%s:%%d\n")
    in 
    Call(
      None, 
      Lval(Var(printfFun.svar),NoOffset), 
      [ 
        mkString format ; 
        mkString str; 
        mkString loc.file; 
        integer  loc.line
      ], 
      locUnknown
    )

let create_submit_instr : string -> instr =
  fun str -> 
    let event_nr =
      try List.assoc str eventmap 
      with Not_found ->
      begin
        Printf.printf "*** event %s not found in eventmap\n" str;
        Printf.printf "*** event map:\n";
        foreach eventmap
        begin function (s,i) ->
          Printf.printf "(%s,%d)\n" s i
        end;
        1000;
      end
    in
    Call(
      None, 
      Lval(Var(submitFun.svar),NoOffset), 
      [integer event_nr],
      locUnknown
    )

let rec create_before_after : advice_insert list -> instr list * instr list =
  function ail ->
    match ail with 
    | [] -> 
        ([],[])
    | (advspec,str) :: ail1 ->
        let (il1,il2) = create_before_after ail1 in
        let i = create_submit_instr str in 
        match advspec with
        | BEFORE ->
            (i::il1,il2)
        | AFTER ->     
            (il1,i::il2)


(*****************************)
(* Reporting Instrumentation *)
(*****************************)

let rec report_instr_instrumentation : instr -> fundec -> advice_insert list -> unit =
  fun i f advice_inserts ->
    let l = locationOfInstr i in
    let filename = l.file in
    let linenumber = l.line in
    let methodname = nameOfFundec f in
    let instruction = instr2string i in
    let code = extract_advice_strings advice_inserts in
    Printf.printf "instruments [%s:%s line %d]\n" filename methodname linenumber; 
    Printf.printf "  %s\n" instruction;
    Printf.printf "with %s\n" code;
    Printf.printf "--------------------------------------\n"

and instr2string : instr -> string =
  function i ->
    let doc = d_instr () i in
    sprint 80 doc


(*****************)
(* visitor class *)
(*****************)

class instrumentVisitor = 
object (self)
  inherit nopCilVisitor

  val mutable current_function : fundec option = None
 
  method private get_current_function =
    match current_function with
    | Some f -> f
    | None -> 
        Printf.printf "*** get_current_function called on None";
        exit(1)

  method vfunc (f : fundec) : fundec visitAction =
    current_function <- Some f;
    DoChildren

  method vinst (i : instr) : instr list visitAction = 
   let cf = self#get_current_function in
   let advice_inserts = match_instr cf i in
   if advice_inserts = [] then 
     SkipChildren 
   else
   begin
     report_instr_instrumentation i (self#get_current_function) advice_inserts;
     let (il1,il2) = create_before_after advice_inserts in
     ChangeTo (il1 @ [i] @ il2)
   end

end


(***********************)
(* Feature Description *)
(***********************)

let feature : featureDescr = 
  { fd_name = "instrument";
    fd_enabled = ref false;
    fd_description = "instrumentation of code";
    fd_extraopt = [];
    fd_doit = 
    (function (f: file) -> 
      print_string "\n";
      print_string "=======================================\n";
      Printf.printf "Instrumentation of file '%s':\n" f.fileName; 
      print_string "=======================================\n";
      print_string "\n";
      let insVisitor = new instrumentVisitor in
      visitCilFileSameGlobals insVisitor f);
    fd_post_check = true;
  } 

