
open List
open String

(*************)
(* Utilities *)
(*************)

let foreach : 'a list -> ('a -> unit) -> unit =
  fun l f -> List.iter f l


(**********************)
(* Printing Utilities *)
(**********************)

let print = Printf.printf

let cur_indent : int ref = ref 0

let indent_space : string = "  "

let indent_up() =
  cur_indent := !cur_indent + 1

let indent_down() =
  cur_indent := !cur_indent - 1

let rec print_indent count =
  if count > 0 then
  begin
    print_string indent_space;
    print_indent (count - 1)
  end

let print_indent() = 
  print_indent(!cur_indent);


(******************)
(* The Aspect AST *)
(******************)

type specification = aspect list

and  aspect = 
       ASPECT of aspect_modifier list * string * aspect_body_decl list

and aspect_modifier =
     | HANDLED
     | UNCHECKED

and  aspect_body_decl =
     | IMPORT_DECL of string
     | POINTCUT_DECL of string * pointcut_expr 
     | SYMBOL_DECL of string * advice_spec * pointcut_expr
     | ABS_SYMBOL_DECL of string
     | MACHINE_DECL of string * aspect_body_decl list (* 2nd arg only STATE_DECLs and SUPER_DECLs *)
     | STATE_DECL of modifier list * string * state_body_decl list
     | SUPER_DECL of string * string list * condition option * state_body_decl list

and advice_spec =
    | BEFORE
    | AFTER

and  pointcut_expr = 
    | CALL of string * string
    | SET of string * string
    | WITHIN of string
    | WITHINCODE of string * string
    | PCIDENT of string
    | OR of pointcut_expr * pointcut_expr
    | AND of pointcut_expr * pointcut_expr
    | NOT of pointcut_expr

and modifier =
    ANYTIME | ONCE | INITIAL | SAFE | LIVE | NEXT    
  
and state_body_decl = 
    | Leave of condition * transition_kind * string
    | Stay of condition

and condition =
    | ANY
    | CoIDENT of string
    | CoOR of condition * condition
    | CoAND of condition * condition
    | CoNOT of condition

and transition_kind = 
    | THEN
    | PARTHEN
;;


(********************)
(* Shared variables *)
(********************)

let wholespec : specification ref = ref []


(* ----------------------- *)
(* Printing the Aspect AST *)
(* ----------------------- *)

let rec print_specification = function
    | [] -> ()
    | aspect :: spec ->
        print_aspect aspect;
        print_newline();
        print_newline();
        print_specification spec;  

and print_aspect = function 
      ASPECT(ms,s,ds) ->
        if mem HANDLED ms then print "handled ";
        if mem UNCHECKED ms then print "unchecked ";
        print "aspect %s{" s;
        print_newline();
        indent_up();
        print_aspect_body_decl_list ds;
        indent_down();
	print "}";

and print_aspect_body_decl_list = function
    | [] -> ()
    | d :: l -> 
        print_aspect_body_decl d;
        print_newline();    
        print_aspect_body_decl_list l  

and print_aspect_body_decl = function 
    | IMPORT_DECL(name) ->
        print_indent();
        print "import %s;" name;
    | POINTCUT_DECL(name,pcexpr) ->
        print_indent();
        print "pointcut %s = " name;
        print_pointcut_expr pcexpr;
        print ";"
    | SYMBOL_DECL(name,advspec,pcexpr) ->
        print_indent();
        print "symbol %s = " name;
        print_advice_spec advspec;
        print " ";
        print_pointcut_expr pcexpr;
	print ";";
    | ABS_SYMBOL_DECL(name) ->
        print_indent();
        print "symbol %s;" name;
    | MACHINE_DECL(name,ds) ->
        print_newline();
        print_indent();
        print "machine %s{" name;
        indent_up();
        print_aspect_body_decl_list ds;
        indent_down();
        print_indent();
        print "}";      
    | STATE_DECL(mods,name,ds) ->
        print_newline();
        print_indent();
        print_modifiers true mods;
        if mods != [] then print " ";
        print "state %s{\n" name;
        indent_up();
        print_state_body_decl_list ds;               
        indent_down();
        print_indent(); 
        print "}"
    | SUPER_DECL(name,names,condopt,ds) ->
        print_newline();
        print_indent();
        print "super %s[" name;
        print_idlist true names;
        print "]{\n";
        indent_up();
        print_while_opt condopt;
        print_state_body_decl_list ds;               
        indent_down();
        print_indent(); 
        print "}"        

and print_advice_spec = function
    | BEFORE -> print "before"
    | AFTER  -> print "after"

and print_pointcut_expr = function
    | CALL(str1,str2) -> 
        print "call(";
        print_string str1;
        print_string ":";
        print_string str2;
        print ")";
    | SET(str1,str2) ->
        print "set(";
        print_string str1;
        print_string ":";
        print_string str2;
        print ")";
    | WITHIN(str) ->
        print "within(";
        print_string str;
        print ")";
    | WITHINCODE(str1,str2) -> 
        print "withincode(";
        print_string str1;
        print_string ":";
        print_string str2;
        print ")";
    | PCIDENT(str) -> 
        print_string str; 
    | OR(pcexpr1,pcexpr2) -> 
        print "(";
        print_pointcut_expr(pcexpr1);
        print " || ";
        print_pointcut_expr(pcexpr2);
        print ")"; 
    | AND(pcexpr1,pcexpr2) ->
        print "(";
        print_pointcut_expr(pcexpr1);
        print " && ";
        print_pointcut_expr(pcexpr2);
        print ")"; 
    | NOT(pcexpr) -> 
        print "!";
        print_pointcut_expr(pcexpr);

and print_modifiers first mods =
      match mods with
      | [] -> ()
      | m :: mods1 ->
          begin
            if not first then print " ";
            print_modifier m;
            print_modifiers false mods1;
          end 

and print_modifier = function 
    | ANYTIME -> print "anytime"
    | ONCE    -> print "once"
    | INITIAL -> print "initial"
    | SAFE    -> print "safe"
    | LIVE    -> print "live"
    | NEXT    -> print "next"

and print_state_body_decl_list = function
    | [] -> ()
    | d :: ds ->
       print_state_body_decl d;
       print_newline(); 
       print_state_body_decl_list ds

and print_state_body_decl sbd =
  match sbd with
  | Leave(cond,kind,name) ->
      print_indent();
      print "when ";
      print_condition cond;
      print_transition_kind kind;
      print "%s;" name;
  | Stay(cond) ->
      print_indent();
      print "when ";
      print_condition cond;

and print_condition = function
    | ANY ->
        print "ANY";
    | CoIDENT(str) -> 
        print_string str; 
    | CoOR(cond1,cond2) -> 
        print "(";
        print_condition(cond1);
        print "||";
        print_condition(cond2);
        print ")"; 
    | CoAND(cond1,cond2) ->
        print "(";
        print_condition(cond1);
        print "&&";
        print_condition(cond2);
        print ")"; 
    | CoNOT(pcexpr) -> 
        print "!";
        print_condition(pcexpr);

and print_transition_kind = function
    | THEN -> print " -> " 
    | PARTHEN -> print " => "

and print_idlist first names =
      match names with
      | [] -> ()
      | name :: names1 ->
          if not first then print ",";
          print_string name;
          print_idlist false names1;

and print_while_opt = function
    | None -> ()
    | Some(cond) ->
        print_indent();
        print_string "while ";
        print_condition cond;
        print_string ";\n";
;; 


(*********************)
(* Accessing the AST *)
(*********************)

type eventmapping = (string * int) list

let rec cleanup_string_list : 'a list -> 'a list =
  function l ->
    let duplicates_removed = remove_duplicates l in
    let equality x y = (if x < y then -1 else if x = y then 0 else 1) in
    sort equality duplicates_removed
    
and remove_duplicates : 'a list -> 'a list =
  function
  | [] -> []
  | x :: l ->
      if mem x l then
        remove_duplicates l
      else
        x :: (remove_duplicates l)


(* Get aspect *)

let rec get_aspect : string -> specification -> aspect =
  fun name spec ->
    match spec with
    | [] -> 
        Printf.printf "*** could not find aspect: %s\n" name;
        raise Not_found
    | ASPECT(_,n,ds) as aspect :: spec1 ->
        if name = n then 
          aspect
        else
          match get_aspect_aspect_body_decl_list name ds with
          | Some a -> a
          | None -> get_aspect name spec1
 
and get_aspect_aspect_body_decl_list : string -> aspect_body_decl list -> aspect option =
  fun name ds ->
    match ds with
    | [] -> None
    | MACHINE_DECL(n,sds) :: ds1 -> 
        if name = n then 
          Some (ASPECT([],n,sds)) 
        else
          get_aspect_aspect_body_decl_list name ds1
    | _ :: ds1 ->
          get_aspect_aspect_body_decl_list name ds1
      
let aspect_name : aspect -> string =
  function ASPECT(_,name,ds) -> name

let contains_states : aspect_body_decl list -> bool =
  function ds ->
    let statedecl(d) =
          match d with
          | STATE_DECL(mods,name,sds) -> true
          | _ -> false
    in
    exists statedecl ds


(* Handled *)

let rec any_handled : specification -> bool =
  function
  | [] -> false
  | ASPECT(modifiers,name,ds) :: ds1 ->
      (mem HANDLED modifiers) || any_handled ds1

let is_handled : string -> bool =
  function aspectname ->
    let ASPECT(modifiers,name,ds) = get_aspect aspectname !wholespec in
    mem HANDLED modifiers


(* Get monitor names *)

let rec monitor_names : specification -> string list =
  function
  | [] -> []
  | a :: spec1 ->
      append
        (monitor_names_aspect a)
        (monitor_names spec1)

and monitor_names_aspect : aspect -> string list =
  function ASPECT(_,name,ds) ->
    append
      (if contains_states ds then [name] else [])  
      (monitor_names_aspect_body_decl_list ds)

and monitor_names_aspect_body_decl_list : aspect_body_decl list -> string list =
  function
  | [] -> []
  | d :: ds ->
      append
        (monitor_names_aspect_body_decl d)
        (monitor_names_aspect_body_decl_list ds)

and monitor_names_aspect_body_decl : aspect_body_decl -> string list =
  function
  | MACHINE_DECL(name,ds) ->
      [name]  
  | _ -> []


(* Get initial state *)

and get_initial_state_from_decls : aspect_body_decl list -> string =
  function ds ->
    try 
      perhaps_get_initial_state_from_decls ds
    with Not_found ->
      get_first_state ds

and perhaps_get_initial_state_from_decls : aspect_body_decl list -> string =
  function
  | [] -> raise Not_found       
  | d :: ds ->
     (match get_initial_state_decl d with
      | Some name -> name
      | None -> perhaps_get_initial_state_from_decls ds
     )

and get_initial_state_decl : aspect_body_decl -> string option =
  function  
  | STATE_DECL(mods,name,ds) ->
      if (mem INITIAL mods) then 
        Some name 
      else 
        None
  | _ -> None

and get_first_state : aspect_body_decl list -> string =
  function
  | [] ->
      Printf.printf "*** could not find first state\n";
      raise Not_found       
  | d :: ds ->
     (match d with
      | STATE_DECL(_,name,_) -> name
      | _ -> get_first_state ds
     )

let get_initial_state : string -> string =
  function monitorname ->
    let ASPECT(_,_,ds) = get_aspect monitorname (!wholespec) in
    get_initial_state_from_decls ds


(* Get super states *)

let rec super_states : aspect_body_decl list -> aspect_body_decl list =
  function
  | [] ->  []
  | d :: ds ->
      append
        (super_states_aspect_body_decl d)
        (super_states ds)    

and super_states_aspect_body_decl : aspect_body_decl -> aspect_body_decl list =
  function d ->
    match d with
    | SUPER_DECL(name,substates,condition_opt,ds) -> [d]
    | _ -> []


(* Get final states *)

let rec final_states : aspect_body_decl list -> string list =
  function
  | [] -> []
  | d :: ds -> 
    append (final_states_aspect_body_decl d) (final_states ds)

and final_states_aspect_body_decl : aspect_body_decl -> string list =
  function
  | STATE_DECL(mods,name,ds) -> 
      if ds = [] then [name] else []
  | _ -> []


(* Get error states *)

let rec error_states : aspect_body_decl list -> string list =
  function
  | [] -> []
  | d :: ds -> 
    append (error_states_aspect_body_decl d) (error_states ds)

and error_states_aspect_body_decl : aspect_body_decl -> string list =
  function
  | STATE_DECL(mods,name,ds) -> 
      if (begins_with_accept name) && (just_true_selfloop ds) then [name] else []
  | _ -> []

and begins_with_accept : string -> bool =
  function s ->
    length s >= 6 && "accept" = (sub s 0 6)

and just_true_selfloop : state_body_decl list -> bool =
  function
  | Stay(ANY) :: [] -> true
  | _ -> false


(* Detect true selfloops *)

let rec contains_true_selfloops : state_body_decl list -> bool =
  function
  | [] -> false
  | Stay(ANY) :: ds -> true
  | _ :: ds -> contains_true_selfloops ds


(* Collecting information *)

type final_super = 
  { 
    final : string list;
    error : string list;
    super : aspect_body_decl list
  }

let final_plus_super : aspect_body_decl list -> final_super =
  function ds ->
    {
      final = final_states ds; 
      error = error_states ds; 
      super = super_states ds; 
    }

      
(* Get states *)

let rec get_states_aspect_body_decl_list : aspect_body_decl list -> string list =
  function
  | [] -> []
  | d :: ds -> 
    append (get_states_aspect_body_decl d) (get_states_aspect_body_decl_list ds)

and get_states_aspect_body_decl : aspect_body_decl -> string list =
  function
  | STATE_DECL(mods,name,ds) -> [name]
  | _ -> []


(* Get next and live states *)

let rec live_states : aspect_body_decl list -> string list =
  function
  | [] -> []
  | d :: ds -> 
    append (live_states_aspect_body_decl d) (live_states ds)

and live_states_aspect_body_decl : aspect_body_decl -> string list =
  function
  | STATE_DECL(mods,name,ds) -> 
      if (mem LIVE mods || mem NEXT mods || 
          ((begins_with_accept name) && not (just_true_selfloop ds))) then
        [name]
      else
        []
  | _ -> []


(* Get used events *)

let rec get_used_events : specification -> string list =
  function spec ->
    let events =
      List.concat (map get_used_events_aspect spec)
    in
    cleanup_string_list events

and get_used_events_aspect : aspect -> string list =
  function ASPECT(_,name,ds) ->
    get_used_events_decls ds

and get_used_events_decls : aspect_body_decl list -> string list =
  function ds ->
    let events = get_used_events_aspect_body_decl_list ds in
    cleanup_string_list events

and get_used_events_aspect_body_decl_list : aspect_body_decl list -> string list =
  function
  | [] -> []
  | d :: ds ->
      append (get_used_events_aspect_body_decl d) 
             (get_used_events_aspect_body_decl_list ds);

and get_used_events_aspect_body_decl : aspect_body_decl -> string list =
  function
  | STATE_DECL(modifiers,statename,statebodydecls) ->
      append
        (if mem NEXT modifiers then ["ANY"] else []) 
        (get_used_events_state_body_decl_list statebodydecls)  
  | SUPER_DECL(name,substates,opt_condition,statebodydecls) ->
      append
        (match opt_condition with
         | Some condition -> get_used_events_condition condition
         | None -> []
        )
        (get_used_events_state_body_decl_list statebodydecls)
  | _ -> []

and get_used_events_state_body_decl_list : state_body_decl list -> string list =
  function
  | [] -> []
  | Leave(condition,kind,target) :: ds ->
      append (get_used_events_condition condition)
             (get_used_events_state_body_decl_list ds)
  | Stay(condition) :: ds ->
      append (get_used_events_condition condition)
             (get_used_events_state_body_decl_list ds)

and get_used_events_condition : condition -> string list =
  function
  | ANY -> 
      ["ANY"]
  | CoIDENT(name) -> 
      [name]
  | CoOR(cond1,cond2) -> 
      append (get_used_events_condition cond1) (get_used_events_condition cond2)
  | CoAND(cond1,cond2) ->
      append (get_used_events_condition cond1) (get_used_events_condition cond2)
  | CoNOT(cond) ->
      append
        ["ANY"] (* A negation results in all events to be of interest *)
        (get_used_events_condition cond)


(* Get declared events *)

let rec get_declared_events : specification -> string list =
  function spec ->
    let events =
      List.concat (map get_declared_events_aspect spec)
    in
    cleanup_string_list events
    
and get_declared_events_aspect : aspect -> string list =
  function 
  | ASPECT(_,name,ds) ->
      List.concat (map get_declared_events_aspect_body_decl ds)

and get_declared_events_aspect_body_decl : aspect_body_decl -> string list =
  function 
  | SYMBOL_DECL(name,advicespec,pcexpr) -> [name]
  | ABS_SYMBOL_DECL(name) -> [name]
  | _ -> []


(* Get visible events *)

let rec get_visible_events : specification -> aspect -> string list =
  fun spec aspect ->
    append 
      (get_declared_events_aspect aspect)
      (get_imported_events_aspect spec aspect)

and get_imported_events_aspect : specification -> aspect -> string list =
  fun spec aspect ->
    match aspect with
    | ASPECT(_,name,ds) ->
        List.concat (map (get_imported_events_aspect_body_decl spec) ds)

and get_imported_events_aspect_body_decl : specification -> aspect_body_decl -> string list =
  fun spec decl ->
    match decl with
    | IMPORT_DECL(name) -> get_visible_events spec (get_aspect name spec)
    | _ -> []

(* Get used poincuts *)

let rec get_used_poincuts : aspect -> string list =
  function ASPECT(_,name,ds) ->
    List.concat (map get_used_pointcuts_aspect_body_decl ds)

and get_used_pointcuts_aspect_body_decl : aspect_body_decl -> string list =
  function 
  | POINTCUT_DECL(pcname,pcexpr) ->
      get_used_pointcuts_pcexpr pcexpr        
  | SYMBOL_DECL(syname,advspec,pcexpr) ->
      get_used_pointcuts_pcexpr pcexpr
  | _ -> []
    
and get_used_pointcuts_pcexpr : pointcut_expr -> string list =
  function
  | PCIDENT(str) -> 
      [str]
  | OR(pcexpr1,pcexpr2) -> 
      append
        (get_used_pointcuts_pcexpr pcexpr1)
        (get_used_pointcuts_pcexpr pcexpr2)
  | AND(pcexpr1,pcexpr2) ->
      append
        (get_used_pointcuts_pcexpr pcexpr1)
        (get_used_pointcuts_pcexpr pcexpr2)
  | NOT(pcexpr) -> 
      get_used_pointcuts_pcexpr pcexpr
  | _ -> []


(* Get visible pointcuts *)

let rec get_visible_pointcuts : specification -> aspect -> string list =
  fun spec aspect ->
    match aspect with
    | ASPECT(_,name,ds) -> 
        List.concat (map (get_visible_pointcuts_aspect_body_decl spec) ds)

and get_visible_pointcuts_aspect_body_decl : specification -> aspect_body_decl -> string list =
  fun spec decl ->
    match decl with
    | POINTCUT_DECL(pcname,pcexpr) -> 
        [pcname]
    | IMPORT_DECL(moname) ->
        get_visible_pointcuts spec (get_aspect moname spec)
    | _ -> []


(* Get event map *)

let rec get_eventmap : specification -> eventmapping =
  function spec -> 
    let 
      events = get_declared_events spec 
    in
    number_events events 1;

and number_events : string list -> int -> (string * int) list =
  fun names next ->
    match names with
    | [] -> []
    | name :: names1 -> (name,next) :: number_events names1 (next+1)

    
(************************)
(* Wellformedness Check *)
(************************)

let errors : int ref = ref 0

let msg = Printf.sprintf

let err : string -> string -> unit =
  fun a m ->
    errors := !errors + 1;
    Printf.printf "*** error %d : %s - %s\n" !errors a m

let rec wellformed : specification -> bool =
  function spec ->
    wf_unique_global_names spec [] [];
    foreach spec 
    begin function aspect ->
      wf_aspect aspect spec
    end;
    (!errors = 0)

and wf_unique_global_names : specification -> string list -> string list -> unit =
  fun spec anames enames ->
    match spec with
    | [] -> ()
    | ASPECT(_,this_aname,ds) as aspect :: spec1 ->
        if mem this_aname anames then
          err this_aname (msg "monitor name %s declared more than once" this_aname);
        foreach ds
        begin function 
          | IMPORT_DECL(n) ->
              if not (mem n anames) then
                err this_aname (msg "import of undeclared monitor %s" n) 
          | _ ->  ()
        end;
        let these_enames = get_declared_events_aspect aspect in
        foreach these_enames
        begin function this_ename ->
          if mem this_ename enames then
            err this_aname (msg "event name %s declared more than once" this_ename);
        end;
        wf_unique_global_names 
          spec1 (this_aname :: anames) (these_enames @ enames)
          
and wf_aspect : aspect -> specification -> unit =
  fun aspect spec -> 
    match aspect with
    | ASPECT(modifiers,name,ds) ->
        wf_used_pointcut_names aspect spec;
        wf_used_event_names aspect spec;
        wf_used_state_names aspect;
        wf_state_defs aspect  

and wf_used_pointcut_names : aspect -> specification -> unit =
  fun aspect spec ->
    let visible_names = get_visible_pointcuts spec aspect in
    let used_names = get_used_poincuts aspect in
    foreach used_names
    begin function used_name ->
      if (not (mem used_name visible_names)) then
        err (aspect_name aspect) (msg "undecleared (not visible) poincut %s" used_name)
    end

and wf_used_event_names : aspect -> specification -> unit =
  fun aspect spec ->
    match aspect with
    | ASPECT(modifiers,aname,ds) ->
        if not (mem UNCHECKED modifiers) then
        begin
          let visible_names = get_visible_events spec aspect in
          let used_names = get_used_events_aspect aspect in
          foreach used_names
          begin function used_name ->
            if (not (used_name = "ANY")) && not (mem used_name visible_names) then
              err aname (msg "undecleared (not visible) event %s" used_name)
          end;
          foreach ds
          begin function
          | MACHINE_DECL(subaname,subds) ->
              let used_names = get_used_events_aspect (ASPECT([],subaname,subds)) in
              foreach used_names
              begin function used_name ->
                if (not (used_name = "ANY")) && not (mem used_name visible_names) then
                  err (concat "." [aname;subaname]) 
                      (msg "undecleared (not visible) event %s" used_name)
              end
          | _ -> ()
          end
        end

and wf_used_state_names : aspect -> unit =
  function ASPECT(_,aname,ds) ->
    let visible_states = get_states_aspect_body_decl_list ds in
    foreach ds 
    begin function
     | STATE_DECL(modifiers,statename,ds) ->
         wf_used_state_names_state_body_decls aname statename visible_states ds
     | SUPER_DECL(supername,substates,cond_opt,ds) ->
         foreach substates
         begin function subname ->
           if(not (mem subname visible_states)) then
             err aname (msg "substate %s of superstate %s is not declared" subname supername);
         end;
         wf_used_state_names_state_body_decls aname supername visible_states ds    
     | MACHINE_DECL(subaname,subds) ->
         wf_used_state_names (ASPECT([],concat "." [aname;subaname], subds))
     | _ -> ()
    end

and wf_used_state_names_state_body_decls : string -> string -> string list -> state_body_decl list -> unit =
  fun aspectname sourcestate visible_states decls ->
    foreach decls
    begin function 
    | Leave(cond,trkind,targetstate) ->
        if (not (targetstate = "error") && not (mem targetstate visible_states)) then
          err aspectname (msg "target state %s exiting state %s is not declared" targetstate sourcestate)
    | Stay(cond) -> ()  
    end

and wf_state_defs : aspect -> unit =
  function ASPECT(_,aname,ds) ->
    wf_state_defs_decls ds aname false [] [] []

and wf_state_defs_decls : 
  aspect_body_decl list -> string -> bool -> string list -> string list -> string list -> unit =
  fun ds aname initfound pcs events states ->
    match ds with
    | [] -> ()
    | d :: ds1 ->
        match d with
        | POINTCUT_DECL(pcname,pcexpr) ->
            wf_pcexpr_regexps aname pcexpr;
            if(mem pcname pcs) then
              err aname (msg "pointcut name %s defined more than once" pcname);
            wf_state_defs_decls ds1 aname 
              initfound (pcname::pcs) events states
        | SYMBOL_DECL(syname,advspec,pcexpr) ->
            wf_pcexpr_regexps aname pcexpr;
            if(mem syname events) then
              err aname (msg "event name %s defined more than once" syname);
            wf_state_defs_decls ds1 aname 
              initfound pcs (syname::events) states
        | ABS_SYMBOL_DECL(syname) ->
            if(mem syname events) then
              err aname (msg "event name %s defined more than once" syname);
            wf_state_defs_decls ds1 aname 
              initfound pcs (syname::events) states
        | MACHINE_DECL(subname,subds) -> 
            wf_state_defs_decls subds (concat "." [aname;subname]) false [] [] [];
            wf_state_defs_decls ds1 aname 
              initfound pcs events states
        | STATE_DECL(modifiers,statename,ds) -> 
            let kinds = filter (fun x -> x=ANYTIME||x=ONCE) modifiers in
            if List.length kinds > 1 then
              err aname (msg "ambiguous use of anytime and once in state %s" statename);
            let kinds = filter (fun x -> x=SAFE||x=LIVE||x=NEXT) modifiers in
            if List.length kinds > 1 then
              err aname (msg "ambiguous use of safe, live and next in state %s" statename);
            if statename = "error" then
              err aname (msg "a state cannot be named error");
            if initfound && (mem INITIAL modifiers) then
              err aname (msg "more than one initial state %s" statename); 
            if(mem statename states) then
              err aname (msg "state name %s defined more than once" statename);
            wf_state_defs_decls ds1 aname 
              (initfound || (mem INITIAL modifiers)) pcs events (statename::states)
        | SUPER_DECL(supername,subnames,cond_opt,ds) ->
            wf_state_defs_decls ds1 aname 
              initfound pcs events (supername::states)
        | _ -> ()

and wf_pcexpr_regexps : string -> pointcut_expr -> unit =
  fun aname pcexpr ->
    match pcexpr with
    | CALL(str1,str2) -> 
        wf_filename_regexp aname str1;
        wf_methodname_regexp aname str2;
    | SET(str1,str2) ->
        wf_filename_regexp aname str1;
        wf_variablename_regexp aname str2;
    | WITHIN(str) ->
        wf_filename_regexp aname str;
    | WITHINCODE(str1,str2) ->
        wf_filename_regexp aname str1;
        wf_methodname_regexp aname str2;        
    | OR(pcexpr1,pcexpr2) -> 
        wf_pcexpr_regexps aname pcexpr1;
        wf_pcexpr_regexps aname pcexpr2;
    | AND(pcexpr1,pcexpr2) ->
        wf_pcexpr_regexps aname pcexpr1;
        wf_pcexpr_regexps aname pcexpr2;
    | NOT(pcexpr) -> 
        wf_pcexpr_regexps aname pcexpr
    | _ -> ()

and wf_filename_regexp : string -> string -> unit =
  fun aname filename -> ()

and wf_methodname_regexp : string -> string -> unit =
  fun aname methodname -> 
    if(
        String.contains methodname '/' ||
        String.contains methodname '-' ||
        String.contains methodname '.' 
      )
    then err aname (msg "ill-formed method name pattern %s" methodname)

and wf_variablename_regexp : string -> string -> unit =
  fun aname variablename -> 
    if(
        String.contains variablename '/' ||
        String.contains variablename '-' ||
        String.contains variablename '.' 
      )
    then err aname (msg "ill-formed variable name pattern %s" variablename)

